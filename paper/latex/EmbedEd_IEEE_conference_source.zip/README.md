# IEEE conference LaTeX source with regenerated figures

Upload this ZIP as an Overleaf project and compile main.tex with pdfLaTeX twice.
For local compilation, unzip and run pdflatex main.tex twice from that directory.
Six contributor and affiliation blocks are intentionally blank. Replace each
complete phantom expression with the actual contributor detail.
All required class, table and two mean-confusion-board image files are included.
The separate figure ZIP contains all 37 individual run matrices, 14 per-model
means (primary 3-seed and all-6-seed) and both boards, with full numerical data.
C0 is a single reference, not artificially replicated. Counts replay frozen
NPZ predictions; six legacy JSON count drifts are disclosed in the paper.
No threshold averaging, new training, or ensemble prediction is performed.
IEEEtran.cls is the unmodified supplied June 2024 template class. Dependencies
include Times/Courier, cite, amsmath/amssymb, booktabs, graphicx, hyperref, balance.
No BibTeX is needed. Check the target conference's page limit/copyright rules.
