"""False-negative audit, 50 + 50 (SCOPE P2-9, IMPLEMENTATION_PLAN Phase 2.5) — BLIND.

    python -m scripts.audit_sample make  [--n 50] [--seed 13]
    python -m scripts.audit_sample score

`make` samples n (anchor, mined-negative) pairs from C2 and n from C3 — distinct
anchors, one random negative each — shuffles them, and writes under
ARTIFACTS/audit/:

    audit_pairs.md    the pairs to read (id + both code fragments), NO condition shown
    audit_labels.csv  id,label,note — fill `label` with clone | not_clone | unsure
    audit_key.csv     id -> condition/anchor/negative — do not open until scoring

Ids carry a hash of the sheet's own content: a labels file moved in from
another sheet is refused instead of being silently joined by colliding ids.

`score` joins labels with the key and reports, per condition, the share of
mined "negatives" that are in fact clones (Wilson 95% CI), with `unsure`
counted separately (headline rate counts unsure as not_clone; an upper bound
counts it as clone). Appends a '## False-negative audit' section to
report/measurements.md and writes audit_result.json.

Why blind: the labeller must not know whether a pair came from BM25 or from
the semantic miner — the whole point is to compare the two rates.

RUBRIC (BigCloneBench's own notion of a clone = functional equivalence):
  clone      both fragments implement the same functionality (copy a file,
             MD5 a string, ...), whatever the syntax — Type-1..4 incl. weak T3/T4
  not_clone  different functionality, or one is only a small part of the other
  unsure     cannot tell in about a minute — do not agonise, mark it and move on
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import re
from pathlib import Path

from embeded import settings as S

CONDS = ("C2", "C3")
LABELS = ("clone", "not_clone", "unsure")


def audit_dir():
    override = os.environ.get("EMBEDED_AUDIT_DIR")
    d = Path(override) if override else S.ARTIFACTS / "audit"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _triples(cond):
    rows = [json.loads(l) for l in open(S.artifact(f"triples_{cond}.jsonl"), encoding="utf-8")]
    by_anchor: dict[int, list[int]] = {}
    for r in rows:
        by_anchor.setdefault(r["anchor"], []).append(r["negative"])
    return by_anchor


def sample_pairs(n: int, seed: int, conds=None) -> list[dict]:
    """n pairs per condition, distinct anchors within a condition, one random
    negative per anchor, then a seeded shuffle across conditions."""
    rng = random.Random(seed)
    out = []
    for cond in (conds or CONDS):
        by_anchor = _triples(cond)
        anchors = sorted(by_anchor)
        if len(anchors) < n:
            raise SystemExit(f"{cond}: only {len(anchors)} anchors, cannot sample {n}")
        for a in rng.sample(anchors, n):
            out.append({"condition": cond, "anchor": a, "negative": rng.choice(by_anchor[a])})
    rng.shuffle(out)
    # Sheet-unique ids that stay blind: a hash tag of the sheet's own content.
    # Every sheet used to reuse P001..Pnnn, so a labels file from ANOTHER sheet
    # 'fitted' this one and scored as plausible nonsense; with content-tagged
    # ids a wrong file simply refuses to join. The tag is one-way: the sheet
    # stays blind.
    tag = hashlib.sha256(
        ("|".join(f"{p['condition']}:{p['anchor']}:{p['negative']}" for p in out)
         + f"|{seed}|{len(out)}").encode()).hexdigest()[:8]
    for i, p in enumerate(out, 1):
        p["id"] = f"{tag}-{i:03d}"
    return out


def filled_labels(labels_csv) -> list[str]:
    """ids that already carry a label — i.e. work that must not be overwritten."""
    if not labels_csv.exists():
        return []
    with open(labels_csv, encoding="utf-8") as fh:
        return [r["id"] for r in csv.DictReader(fh)
                if (r.get("label") or "").strip()]


def make(n: int, seed: int, force: bool = False, conds=None) -> dict:
    from embeded.data.prepare_data import load_fragments
    frags = load_fragments()
    d = audit_dir()
    done = filled_labels(d / "audit_labels.csv")
    if done and not force:
        raise SystemExit(
            f"{d / 'audit_labels.csv'} already has {len(done)} label(s) "
            f"({done[0]} ... {done[-1]}) — refusing to overwrite the audit sheet.\n"
            "  Score what you have:      python -m scripts.audit_sample score\n"
            "  Or start a new sample:   python -m scripts.audit_sample make "
            f"--n {n} --seed {seed} --force   (the old labels become meaningless)")
    pairs = sample_pairs(n, seed, conds=conds)

    with open(d / "audit_key.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["id", "condition", "anchor", "negative"])
        w.writeheader()
        for p in pairs:
            w.writerow({k: p[k] for k in w.fieldnames})

    with open(d / "audit_labels.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["id", "label", "note"])
        w.writeheader()
        for p in pairs:
            w.writerow({"id": p["id"], "label": "", "note": ""})

    md = [f"# False-negative audit — {len(pairs)} pairs ({n} per condition, blind)", "",
          f"seed {seed}, version `{S.VERSION}`. For each pair decide whether the two fragments implement the "
          "**same functionality** (BigCloneBench's clone definition). Write `clone`, `not_clone` or `unsure` in "
          "`audit_labels.csv`; do not open `audit_key.csv` until you run `score`.", "",
          "Rubric: `clone` = same functionality whatever the syntax (Type-1..4, incl. weak T3/T4); `not_clone` = "
          "different functionality or one is only a small part of the other; `unsure` = cannot tell in about a minute.", ""]
    for p in pairs:
        md += [f"## {p['id']}", "", "**A**", "", "```java", frags[p["anchor"]].strip(), "```", "",
               "**B**", "", "```java", frags[p["negative"]].strip(), "```", ""]
    (d / "audit_pairs.md").write_text("\n".join(md))
    return {"n_pairs": len(pairs), "per_condition": n, "seed": seed, "dir": str(d)}


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, centre - half), min(1.0, centre + half))


def score_rows(labels: dict[str, str], key: list[dict]) -> dict:
    out = {}
    conds = sorted({r["condition"] for r in key})   # the sheet decides (C4 audits are C4-only)
    for cond in conds:
        ids = [r["id"] for r in key if r["condition"] == cond]
        got = {i: labels.get(i, "").strip().lower() for i in ids}
        bad = sorted(i for i, v in got.items() if v not in LABELS)
        if bad:
            raise SystemExit(f"{cond}: {len(bad)} pair(s) unlabelled or mislabelled "
                             f"(allowed: {', '.join(LABELS)}): {', '.join(bad[:8])}{' ...' if len(bad) > 8 else ''}")
        n = len(ids)
        c = sum(v == "clone" for v in got.values())
        u = sum(v == "unsure" for v in got.values())
        lo, hi = wilson(c, n)
        lo_u, hi_u = wilson(c + u, n)
        out[cond] = {"n": n, "clone": c, "not_clone": n - c - u, "unsure": u,
                     "fn_rate": round(c / n, 3), "fn_rate_ci95": [round(lo, 3), round(hi, 3)],
                     "fn_rate_upper_incl_unsure": round((c + u) / n, 3),
                     "fn_rate_upper_ci95": [round(lo_u, 3), round(hi_u, 3)]}
    return out


def write_section(res: dict) -> None:
    conds_tag = "/".join(c for c in res if not c.startswith("_"))
    ai = res.get('_provenance', {}).get('reviewer_type') == 'ai'
    method = 'AI-reviewed; not independently human-validated' if ai else 'blind; SCOPE P2-9'
    heading = f"## False-negative audit — {conds_tag} ({method})"
    # the heading carries the sheet's conditions so a later C4 score APPENDS its
    # own section instead of overwriting the scored C2/C3 one (regex is tag-anchored)
    lines = [heading, "",
             f"`python -m scripts.audit_sample score` — version `{S.VERSION}`, conditions {conds_tag}. "
             "Share of mined negatives judged to be clones (functional equivalence). Headline counts "
             "`unsure` as not_clone; the upper bound counts it as clone.",
             "", "| condition | n | clone | not_clone | unsure | FN rate [95% CI] | upper bound incl. unsure |",
             "|---|---|---|---|---|---|---|"]
    if ai:
        lines[3:3] = [
            f"Amendment `{res['_provenance']['amendment_id']}`. Reviewer knew the study and "
            "benchmark outcomes; not independent or fully blind. Wilson intervals reflect "
            "sampling uncertainty only, not AI-review accuracy/bias. No inter-rater agreement measured.", ""]
    for cond in (c for c in res if not c.startswith("_")):
        m = res[cond]
        lines.append(f"| {cond} | {m['n']} | {m['clone']} | {m['not_clone']} | {m['unsure']} | "
                     f"**{m['fn_rate']:.0%}** [{m['fn_rate_ci95'][0]:.0%}, {m['fn_rate_ci95'][1]:.0%}] | "
                     f"{m['fn_rate_upper_incl_unsure']:.0%} [{m['fn_rate_upper_ci95'][0]:.0%}, {m['fn_rate_upper_ci95'][1]:.0%}] |")
    lines.append("")
    block = "\n".join(lines)
    S.REPORT_MD.parent.mkdir(parents=True, exist_ok=True)
    if S.REPORT_MD.exists():
        old = S.REPORT_MD.read_text()
        pat = re.compile("## False-negative audit — " + re.escape(conds_tag) + r".*?(?=\n## |\Z)", re.S)
        if pat.search(old):
            old = pat.sub(lambda _m: block + "\n", old)
        else:
            old = old.rstrip("\n") + "\n\n" + block + "\n"
        S.REPORT_MD.write_text(old.rstrip('\n') + '\n')
    else:
        S.REPORT_MD.write_text(("# Measurements\n\n" + block).rstrip('\n') + '\n')
    print(f"wrote {S.REPORT_MD}")


def check_key_matches_triples(key: list[dict]) -> dict:
    """Every (anchor, negative) in the key must still be a mined pair of that
    condition. The sheet is blind and long-lived, the artifacts are not: a
    re-encode on a different GPU can reorder C3's top-k, and then the labels
    describe pairs that no longer exist — scoring them would report a
    false-negative rate for a mining run nobody trained on."""
    out = {}
    conds = sorted({r["condition"] for r in key})   # the sheet decides
    for cond in conds:
        by_anchor = _triples(cond)
        pairs = {(a, x) for a, negs in by_anchor.items() for x in negs}
        want = [(int(r["anchor"]), int(r["negative"]))
                for r in key if r["condition"] == cond]
        missing = [p for p in want if p not in pairs]
        out[cond] = {"n": len(want), "not_in_current_triples": len(missing),
                     "examples": [list(p) for p in missing[:3]]}
    return out


def review_provenance(d: Path, rows: list[dict], conds: set[str]) -> dict:
    """Keep legacy audits unchanged; amended AI sheets require frozen provenance."""
    if not any(r.get('reviewer_type') or r.get('amendment_id') for r in rows):
        return {}
    amendment = 'P4-AI-AUDIT-2026-10-23'
    if (len(conds) != 1 or not conds <= {'C4', 'C5', 'C6'} or len(rows) != 50
            or len({r.get('id') for r in rows}) != 50
            or any(r.get('reviewer_type') != 'ai' or r.get('amendment_id') != amendment
                   or not (r.get('note') or '').strip() for r in rows)):
        raise SystemExit('AI review requires 50 unique labels, a rationale each and amendment attribution')
    root = Path(__file__).resolve().parents[1] / 'report'
    protocol_path = Path(os.environ.get('EMBEDED_AUDIT_PROTOCOL', root / 'phase4_ai_audit_protocol.json'))
    freeze_path = Path(os.environ.get('EMBEDED_AUDIT_FREEZE', root / 'phase4_ai_audit_freeze.json'))
    protocol = json.loads(protocol_path.read_text())
    freeze = json.loads(freeze_path.read_text())
    cond = next(iter(conds))
    sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    labels_sha = sha(d / 'audit_labels.csv')
    if (protocol.get('amendment_id') != amendment or freeze.get('amendment_id') != amendment
            or freeze.get('label_sha256', {}).get(cond) != labels_sha):
        raise SystemExit('AI review differs from frozen labels or amendment')
    sheet_sha = sha(d / 'audit_pairs.md')
    if protocol.get('sheet_sha256', {}).get(f'audit_{cond.lower()}/audit_pairs.md') != sheet_sha:
        raise SystemExit('AI review code sheet differs from frozen input')
    return dict(reviewer_type='ai', amendment_id=amendment,
                independent_human_validation=False, fully_blind=False,
                frozen_utc=freeze['frozen_utc'], label_sha256=labels_sha,
                sheet_sha256=sheet_sha, freeze_sha256=sha(freeze_path),
                protocol_sha256=sha(protocol_path))


def score() -> dict:
    d = audit_dir()
    for name in ("audit_key.csv", "audit_labels.csv"):
        if not (d / name).exists():
            raise SystemExit(f"missing {d / name} — run "
                             "`python -m scripts.audit_sample make` first")
    with open(d / "audit_key.csv", encoding="utf-8") as fh:
        key = list(csv.DictReader(fh))
    drift = check_key_matches_triples(key)
    stale = [c for c, m in drift.items() if m["not_in_current_triples"]]
    if stale:
        detail = "; ".join(f"{c}: {drift[c]['not_in_current_triples']}/{drift[c]['n']} "
                           f"(e.g. anchor {drift[c]['examples'][0][0]} → "
                           f"negative {drift[c]['examples'][0][1]})" for c in stale)
        raise SystemExit(
            "the audit sheet does not match the triples on disk — " + detail + "\n"
            "  The labels were made against a different mining run, so scoring them "
            "would report a rate for pairs nobody trains on.\n"
            "  Either restore the artifacts the sheet was made from "
            "(`python -m scripts.hf_artifacts pull --if-configured`), or re-sample "
            "and re-label (`make ... --force`).")
    print("audit key matches the current triples: "
          + ", ".join(f"{c} {drift[c]['n']}/{drift[c]['n']}" for c in drift))
    with open(d / "audit_labels.csv", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
        labels = {r["id"]: r["label"] for r in rows}
    if len(labels) != len(rows):
        raise SystemExit('Duplicate audit label IDs')
    review = review_provenance(d, rows, {r['condition'] for r in key})
    foreign = sorted(set(labels) - {r["id"] for r in key})
    if foreign:
        raise SystemExit(
            f"{len(foreign)} label row(s) carry id(s) that are not in this sheet's "
            f"key (e.g. {foreign[:5]}): audit_labels.csv belongs to a DIFFERENT audit "
            "sheet. Sheets tag their ids with a hash of their own content precisely "
            "so a wrong file can never silently 'fit' - move the foreign file aside "
            "and label this sheet's own ids (they head the pairs in audit_pairs.md).")
    res = score_rows(labels, key)
    res["_provenance"] = {"key_matches_triples": drift, "version": S.VERSION,
                          "n_labelled": len([v for v in labels.values() if v.strip()]), **review}
    (d / "audit_result.json").write_text(json.dumps(res, indent=2))
    print(json.dumps(res, indent=2))
    write_section(res)
    return res


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("action", choices=("make", "score"))
    ap.add_argument("--n", type=int, default=50, help="pairs per condition")
    ap.add_argument("--seed", type=int, default=S.SEED)
    ap.add_argument("--force", action="store_true",
                    help="make: overwrite an audit sheet that already has labels")
    ap.add_argument("--conditions", default=None,
                    help="make: comma-separated condition filter, e.g. C4 "
                         "(default: every COND with mined triples)")
    a = ap.parse_args(argv)
    if a.action == "make":
        conds = tuple(c.strip().upper() for c in a.conditions.split(",")) \
            if a.conditions else None
        info = make(a.n, a.seed, force=a.force, conds=conds)
        print(json.dumps(info, indent=2))
        print(f"read  {info['dir']}/audit_pairs.md\nfill  {info['dir']}/audit_labels.csv\nthen  python -m scripts.audit_sample score")
    else:
        score()


if __name__ == "__main__":
    main()
