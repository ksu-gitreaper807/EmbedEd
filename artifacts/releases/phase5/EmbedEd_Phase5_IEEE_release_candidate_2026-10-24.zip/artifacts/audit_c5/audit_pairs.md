# False-negative audit — 50 pairs (50 per condition, blind)

seed 13, version `phase01-v8`. For each pair decide whether the two fragments implement the **same functionality** (BigCloneBench's clone definition). Write `clone`, `not_clone` or `unsure` in `audit_labels.csv`; do not open `audit_key.csv` until you run `score`.

Rubric: `clone` = same functionality whatever the syntax (Type-1..4, incl. weak T3/T4); `not_clone` = different functionality or one is only a small part of the other; `unsure` = cannot tell in about a minute.

## 85966eff-001

**A**

```java
private void getRandomGUID(boolean secure) throws NoSuchAlgorithmException {
        MessageDigest md5 = null;
        StringBuffer sbValueBeforeMD5 = new StringBuffer();
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Error: " + e);
            throw e;
        }
        try {
            long time = System.currentTimeMillis();
            long rand = 0;
            if (secure) {
                rand = mySecureRand.nextLong();
            } else {
                rand = myRand.nextLong();
            }
            sbValueBeforeMD5.append(s_id);
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(time));
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(rand));
            valueBeforeMD5 = sbValueBeforeMD5.toString();
            md5.update(valueBeforeMD5.getBytes());
            byte[] array = md5.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            valueAfterMD5 = sb.toString();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
```

**B**

```java
@Override
    public void execute() throws ProcessorExecutionException {
        try {
            if (getSource().getPaths() == null || getSource().getPaths().size() == 0 || getDestination().getPaths() == null || getDestination().getPaths().size() == 0) {
                throw new ProcessorExecutionException("No input and/or output paths specified.");
            }
            String temp_dir_prefix = getDestination().getPath().getParent().toString() + "/bcc_" + getDestination().getPath().getName() + "_";
            SequenceTempDirMgr dirMgr = new SequenceTempDirMgr(temp_dir_prefix, context);
            dirMgr.setSeqNum(0);
            Path tmpDir;
            System.out.println("++++++>" + dirMgr.getSeqNum() + ": Transform input to AdjSetVertex");
            Transformer transformer = new OutAdjVertex2AdjSetVertexTransformer();
            transformer.setConf(context);
            transformer.setSrcPath(getSource().getPath());
            tmpDir = dirMgr.getTempDir();
            transformer.setDestPath(tmpDir);
            transformer.setMapperNum(getMapperNum());
            transformer.setReducerNum(getReducerNum());
            transformer.execute();
            System.out.println("++++++>" + dirMgr.getSeqNum() + ": Transform input to LabeledAdjSetVertex");
            Vertex2LabeledTransformer l_transformer = new Vertex2LabeledTransformer();
            l_transformer.setConf(context);
            l_transformer.setSrcPath(tmpDir);
            tmpDir = dirMgr.getTempDir();
            l_transformer.setDestPath(tmpDir);
            l_transformer.setMapperNum(getMapperNum());
            l_transformer.setReducerNum(getReducerNum());
            l_transformer.setOutputValueClass(LabeledAdjSetVertex.class);
            l_transformer.execute();
            Graph src;
            Graph dest;
            Path path_to_remember = tmpDir;
            System.out.println("++++++>" + dirMgr.getSeqNum() + ": SpanningTreeRootChoose");
            src = new Graph(Graph.defaultGraph());
            src.setPath(tmpDir);
            dest = new Graph(Graph.defaultGraph());
            tmpDir = dirMgr.getTempDir();
            dest.setPath(tmpDir);
            GraphAlgorithm choose_root = new SpanningTreeRootChoose();
            choose_root.setConf(context);
            choose_root.setSource(src);
            choose_root.setDestination(dest);
            choose_root.setMapperNum(getMapperNum());
            choose_root.setReducerNum(getReducerNum());
            choose_root.execute();
            Path the_file = new Path(tmpDir.toString() + "/part-00000");
            FileSystem client = FileSystem.get(context);
            if (!client.exists(the_file)) {
                throw new ProcessorExecutionException("Did not find the chosen vertex in " + the_file.toString());
            }
            FSDataInputStream input_stream = client.open(the_file);
            ByteArrayOutputStream output_stream = new ByteArrayOutputStream();
            IOUtils.copyBytes(input_stream, output_stream, context, false);
            String the_line = output_stream.toString();
            String root_vertex_id = the_line.substring(SpanningTreeRootChoose.SPANNING_TREE_ROOT.length()).trim();
            input_stream.close();
            output_stream.close();
            System.out.println("++++++> Chosen the root of spanning tree = " + root_vertex_id);
            while (true) {
                System.out.println("++++++>" + dirMgr.getSeqNum() + " Generate the spanning tree rooted at : (" + root_vertex_id + ") from " + tmpDir);
                src = new Graph(Graph.defaultGraph());
                src.setPath(path_to_remember);
                tmpDir = dirMgr.getTempDir();
                dest = new Graph(Graph.defaultGraph());
                dest.setPath(tmpDir);
                path_to_remember = tmpDir;
                GraphAlgorithm spanning = new SpanningTreeGenerate();
                spanning.setConf(context);
                spanning.setSource(src);
                spanning.setDestination(dest);
                spanning.setMapperNum(getMapperNum());
                spanning.setReducerNum(getReducerNum());
                spanning.setParameter(ConstantLabels.ROOT_ID, root_vertex_id);
                spanning.execute();
                System.out.println("++++++>" + dirMgr.getSeqNum() + " Test spanning convergence");
                src = new Graph(Graph.defaultGraph());
                src.setPath(tmpDir);
                tmpDir = dirMgr.getTempDir();
                dest = new Graph(Graph.defaultGraph());
                dest.setPath(tmpDir);
                GraphAlgorithm conv_tester = new SpanningConvergenceTest();
                conv_tester.setConf(context);
                conv_tester.setSource(src);
                conv_tester.setDestination(dest);
                conv_tester.setMapperNum(getMapperNum());
                conv_tester.setReducerNum(getReducerNum());
                conv_tester.execute();
                long vertexes_out_of_tree = MRConsoleReader.getMapOutputRecordNum(conv_tester.getFinalStatus());
                System.out.println("++++++> number of vertexes out of the spanning tree = " + vertexes_out_of_tree);
                if (vertexes_out_of_tree == 0) {
                    break;
                }
            }
            System.out.println("++++++> From spanning tree to sets of edges");
            src = new Graph(Graph.defaultGraph());
            src.setPath(path_to_remember);
            tmpDir = dirMgr.getTempDir();
            dest = new Graph(Graph.defaultGraph());
            dest.setPath(tmpDir);
            GraphAlgorithm tree2set = new Tree2EdgeSet();
            tree2set.setConf(context);
            tree2set.setSource(src);
            tree2set.setDestination(dest);
            tree2set.setMapperNum(getMapperNum());
            tree2set.setReducerNum(getReducerNum());
            tree2set.execute();
            long map_input_records_num = -1;
            long map_output_records_num = -2;
            Stack<Path> expanding_stack = new Stack<Path>();
            do {
                System.out.println("++++++>" + dirMgr.getSeqNum() + ": EdgeSetMinorJoin");
                GraphAlgorithm minorjoin = new EdgeSetMinorJoin();
                minorjoin.setConf(context);
                src = new Graph(Graph.defaultGraph());
                src.setPath(tmpDir);
                dest = new Graph(Graph.defaultGraph());
                tmpDir = dirMgr.getTempDir();
                dest.setPath(tmpDir);
                minorjoin.setSource(src);
                minorjoin.setDestination(dest);
                minorjoin.setMapperNum(getMapperNum());
                minorjoin.setReducerNum(getReducerNum());
                minorjoin.execute();
                expanding_stack.push(tmpDir);
                System.out.println("++++++>" + dirMgr.getSeqNum() + ": EdgeSetJoin");
                GraphAlgorithm join = new EdgeSetJoin();
                join.setConf(context);
                src = new Graph(Graph.defaultGraph());
                src.setPath(tmpDir);
                dest = new Graph(Graph.defaultGraph());
                tmpDir = dirMgr.getTempDir();
                dest.setPath(tmpDir);
                join.setSource(src);
                join.setDestination(dest);
                join.setMapperNum(getMapperNum());
                join.setReducerNum(getReducerNum());
                join.execute();
                map_input_records_num = MRConsoleReader.getMapInputRecordNum(join.getFinalStatus());
                map_output_records_num = MRConsoleReader.getMapOutputRecordNum(join.getFinalStatus());
                System.out.println("++++++> map in/out : " + map_input_records_num + "/" + map_output_records_num);
            } while (map_input_records_num != map_output_records_num);
            while (expanding_stack.size() > 0) {
                System.out.println("++++++>" + dirMgr.getSeqNum() + ": EdgeSetExpand");
                GraphAlgorithm expand = new EdgeSetExpand();
                expand.setConf(context);
                src = new Graph(Graph.defaultGraph());
                src.addPath(expanding_stack.pop());
                src.addPath(tmpDir);
                dest = new Graph(Graph.defaultGraph());
                tmpDir = dirMgr.getTempDir();
                dest.setPath(tmpDir);
                expand.setSource(src);
                expand.setDestination(dest);
                expand.setMapperNum(getMapperNum());
                expand.setReducerNum(getReducerNum());
                expand.execute();
                System.out.println("++++++>" + dirMgr.getSeqNum() + ": EdgeSetMinorExpand");
                GraphAlgorithm minorexpand = new EdgeSetMinorExpand();
                minorexpand.setConf(context);
                src = new Graph(Graph.defaultGraph());
                src.setPath(tmpDir);
                dest = new Graph(Graph.defaultGraph());
                tmpDir = dirMgr.getTempDir();
                dest.setPath(tmpDir);
                minorexpand.setSource(src);
                minorexpand.setDestination(dest);
                minorexpand.setMapperNum(getMapperNum());
                minorexpand.setReducerNum(getReducerNum());
                minorexpand.execute();
            }
            System.out.println("++++++>" + dirMgr.getSeqNum() + ": EdgeSetSummarize");
            GraphAlgorithm summarize = new EdgeSetSummarize();
            summarize.setConf(context);
            src = new Graph(Graph.defaultGraph());
            src.setPath(tmpDir);
            dest = new Graph(Graph.defaultGraph());
            dest.setPath(getDestination().getPath());
            summarize.setSource(src);
            summarize.setDestination(dest);
            summarize.setMapperNum(getMapperNum());
            summarize.setReducerNum(getReducerNum());
            summarize.execute();
            dirMgr.deleteAll();
        } catch (IOException e) {
            throw new ProcessorExecutionException(e);
        } catch (IllegalAccessException e) {
            throw new ProcessorExecutionException(e);
        }
    }
```

## 85966eff-002

**A**

```java
private static void main(String[] args) {
        try {
            File f = new File("test.txt");
            if (f.exists()) {
                throw new IOException(f + " already exists.  I don't want to overwrite it.");
            }
            StraightStreamReader in;
            char[] cbuf = new char[0x1000];
            int read;
            int totRead;
            FileOutputStream out = new FileOutputStream(f);
            for (int i = 0x00; i < 0x100; i++) {
                out.write(i);
            }
            out.close();
            in = new StraightStreamReader(new FileInputStream(f));
            for (int i = 0x00; i < 0x100; i++) {
                read = in.read();
                if (read != i) {
                    System.err.println("Error: " + i + " read as " + read);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = in.read(cbuf);
            if (totRead != 0x100) {
                System.err.println("Simple buffered read did not read the full amount: 0x" + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead, 0x100 - totRead)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead + 0x123, 0x100 - totRead)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i + 0x123] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i + 0x123]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead + 0x123, 7)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i + 0x123] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i + 0x123]);
                }
            }
            in.close();
            f.delete();
        } catch (IOException x) {
            System.err.println(x.getMessage());
        }
    }
```

**B**

```java
public static void main(String[] args) {
        Option optHelp = new Option("h", "help", false, "print this message");
        Option optCerts = new Option("c", "cert", true, "use external semicolon separated X.509 certificate files");
        optCerts.setArgName("certificates");
        Option optPasswd = new Option("p", "password", true, "set password for opening PDF");
        optPasswd.setArgName("password");
        Option optExtract = new Option("e", "extract", true, "extract signed PDF revisions to given folder");
        optExtract.setArgName("folder");
        Option optListKs = new Option("lk", "list-keystore-types", false, "list keystore types provided by java");
        Option optListCert = new Option("lc", "list-certificates", false, "list certificate aliases in a KeyStore");
        Option optKsType = new Option("kt", "keystore-type", true, "use keystore type with given name");
        optKsType.setArgName("keystore_type");
        Option optKsFile = new Option("kf", "keystore-file", true, "use given keystore file");
        optKsFile.setArgName("file");
        Option optKsPass = new Option("kp", "keystore-password", true, "password for keystore file (look on -kf option)");
        optKsPass.setArgName("password");
        Option optFailFast = new Option("ff", "fail-fast", true, "flag which sets the Verifier to exit with error code on the first validation failure");
        final Options options = new Options();
        options.addOption(optHelp);
        options.addOption(optCerts);
        options.addOption(optPasswd);
        options.addOption(optExtract);
        options.addOption(optListKs);
        options.addOption(optListCert);
        options.addOption(optKsType);
        options.addOption(optKsFile);
        options.addOption(optKsPass);
        options.addOption(optFailFast);
        CommandLine line = null;
        try {
            CommandLineParser parser = new PosixParser();
            line = parser.parse(options, args);
        } catch (ParseException exp) {
            System.err.println("Illegal command used: " + exp.getMessage());
            System.exit(-1);
        }
        final boolean failFast = line.hasOption("ff");
        final String[] tmpArgs = line.getArgs();
        if (line.hasOption("h") || args == null || args.length == 0) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp(70, "java -jar Verifier.jar [file1.pdf [file2.pdf ...]]", "JSignPdf Verifier is a command line tool for verifying signed PDF documents.", options, null, true);
        } else if (line.hasOption("lk")) {
            for (String tmpKsType : KeyStoreUtils.getKeyStores()) {
                System.out.println(tmpKsType);
            }
        } else if (line.hasOption("lc")) {
            for (String tmpCert : KeyStoreUtils.getCertAliases(line.getOptionValue("kt"), line.getOptionValue("kf"), line.getOptionValue("kp"))) {
                System.out.println(tmpCert);
            }
        } else {
            final VerifierLogic tmpLogic = new VerifierLogic(line.getOptionValue("kt"), line.getOptionValue("kf"), line.getOptionValue("kp"));
            tmpLogic.setFailFast(failFast);
            if (line.hasOption("c")) {
                String tmpCertFiles = line.getOptionValue("c");
                for (String tmpCFile : tmpCertFiles.split(";")) {
                    tmpLogic.addX509CertFile(tmpCFile);
                }
            }
            byte[] tmpPasswd = null;
            if (line.hasOption("p")) {
                tmpPasswd = line.getOptionValue("p").getBytes();
            }
            String tmpExtractDir = null;
            if (line.hasOption("e")) {
                tmpExtractDir = new File(line.getOptionValue("e")).getPath();
            }
            for (String tmpFilePath : tmpArgs) {
                System.out.println("Verifying " + tmpFilePath);
                final File tmpFile = new File(tmpFilePath);
                if (!tmpFile.canRead()) {
                    System.err.println("Couln't read the file. Check the path and permissions.");
                    if (failFast) {
                        System.exit(-1);
                    }
                    continue;
                }
                final VerificationResult tmpResult = tmpLogic.verify(tmpFilePath, tmpPasswd);
                if (tmpResult.getException() != null) {
                    tmpResult.getException().printStackTrace();
                    System.exit(-1);
                } else {
                    System.out.println("Total revisions: " + tmpResult.getTotalRevisions());
                    for (SignatureVerification tmpSigVer : tmpResult.getVerifications()) {
                        System.out.println(tmpSigVer.toString());
                        if (tmpExtractDir != null) {
                            try {
                                File tmpExFile = new File(tmpExtractDir + "/" + tmpFile.getName() + "_" + tmpSigVer.getRevision() + ".pdf");
                                System.out.println("Extracting to " + tmpExFile.getCanonicalPath());
                                FileOutputStream tmpFOS = new FileOutputStream(tmpExFile.getCanonicalPath());
                                InputStream tmpIS = tmpLogic.extractRevision(tmpFilePath, tmpPasswd, tmpSigVer.getName());
                                IOUtils.copy(tmpIS, tmpFOS);
                                tmpIS.close();
                                tmpFOS.close();
                            } catch (IOException ioe) {
                                ioe.printStackTrace();
                            }
                        }
                    }
                    if (failFast && SignatureVerification.isError(tmpResult.getVerificationResultCode())) {
                        System.exit(tmpResult.getVerificationResultCode());
                    }
                }
            }
        }
    }
```

## 85966eff-003

**A**

```java
public static void main(String[] args) throws IOException {
        String uri = "hdfs://localhost:8020/user/leeing/maxtemp/sample.txt";
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(URI.create(uri), conf);
        FSDataInputStream in = null;
        try {
            in = fs.open(new Path(uri));
            IOUtils.copyBytes(in, System.out, 8192, false);
            System.out.println("\n");
            in.seek(0);
            IOUtils.copyBytes(in, System.out, 8192, false);
        } finally {
            IOUtils.closeStream(in);
        }
    }
```

**B**

```java
private ExamModel(URL urlQuestions) throws IOException, DataCoherencyException {
        BufferedReader in = new BufferedReader(new InputStreamReader(urlQuestions.openStream()));
        String line;
        questions = new ArrayList<Question>();
        questionsMap = new HashMap<String, Question>();
        in = new BufferedReader(new InputStreamReader(urlQuestions.openStream(), "UTF-8"));
        int questionNumber = 0;
        Question question;
        String questText = "";
        String hash = "";
        int lookingFor = ExamModel.READING_HASH;
        while ((line = in.readLine()) != null) {
            switch(lookingFor) {
                case ExamModel.READING_HASH:
                    if (line.length() == 0 || line.trim().length() == 0) continue;
                    hash = line;
                    questionNumber++;
                    lookingFor = ExamModel.READING_QUESTION;
                    break;
                case ExamModel.READING_QUESTION:
                    if (line.equals("--")) {
                        question = new Question(questionNumber, hash, questText);
                        questions.add(question);
                        questionsMap.put(question.getHash(), question);
                        questText = "";
                        hash = null;
                        lookingFor = ExamModel.READING_HASH;
                    } else {
                        questText = questText.concat(line + Constants.nl);
                    }
                    break;
                default:
                    throw new DataCoherencyException("Neočekávaný konec souboru!");
            }
        }
        questions.trimToSize();
        in.close();
    }
```

## 85966eff-004

**A**

```java
private String fetchHTML(String s) {
        String str;
        StringBuffer sb = new StringBuffer();
        try {
            URL url = new URL(s);
            InputStream is = url.openStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            while ((str = br.readLine()) != null) {
                sb.append(str);
            }
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
        return sb.toString();
    }
```

**B**

```java
public static String MD5(String text) throws ProducteevSignatureException {
        try {
            MessageDigest md;
            md = MessageDigest.getInstance(ALGORITHM);
            byte[] md5hash;
            md.update(text.getBytes("utf-8"), 0, text.length());
            md5hash = md.digest();
            return convertToHex(md5hash);
        } catch (NoSuchAlgorithmException nsae) {
            throw new ProducteevSignatureException("No such algorithm : " + ALGORITHM, nsae);
        } catch (UnsupportedEncodingException e) {
            throw new ProducteevSignatureException("No such algorithm : " + ALGORITHM, e);
        }
    }
```

## 85966eff-005

**A**

```java
public static void copy(String srcFileName, String destFileName) throws IOException {
        if (srcFileName == null) {
            throw new IllegalArgumentException("srcFileName is null");
        }
        if (destFileName == null) {
            throw new IllegalArgumentException("destFileName is null");
        }
        FileChannel src = null;
        FileChannel dest = null;
        try {
            src = new FileInputStream(srcFileName).getChannel();
            dest = new FileOutputStream(destFileName).getChannel();
            long n = src.size();
            MappedByteBuffer buf = src.map(FileChannel.MapMode.READ_ONLY, 0, n);
            dest.write(buf);
        } finally {
            if (dest != null) {
                try {
                    dest.close();
                } catch (IOException e1) {
                }
            }
            if (src != null) {
                try {
                    src.close();
                } catch (IOException e1) {
                }
            }
        }
    }
```

**B**

```java
private static void executeDBPatchFile() throws Exception {
        Connection con = null;
        PreparedStatement pre_stmt = null;
        ResultSet rs = null;
        try {
            InputStream is = null;
            URL url = new URL("http://www.hdd-player.de/umc/UMC-DB-Update-Script.sql");
            is = url.openStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:database/umc.db", "", "");
            double dbVersion = -1;
            pre_stmt = con.prepareStatement("SELECT * FROM DB_VERSION WHERE ID_MODUL = 0");
            rs = pre_stmt.executeQuery();
            if (rs.next()) {
                dbVersion = rs.getDouble("VERSION");
            }
            String line = "";
            con.setAutoCommit(false);
            boolean collectSQL = false;
            ArrayList<String> sqls = new ArrayList<String>();
            double patchVersion = 0;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("[")) {
                    Pattern p = Pattern.compile("\\[.*\\]");
                    Matcher m = p.matcher(line);
                    m.find();
                    String value = m.group();
                    value = value.substring(1, value.length() - 1);
                    patchVersion = Double.parseDouble(value);
                }
                if (patchVersion == dbVersion + 1) collectSQL = true;
                if (collectSQL) {
                    if (!line.equals("") && !line.startsWith("[") && !line.startsWith("--") && !line.contains("--")) {
                        if (line.endsWith(";")) line = line.substring(0, line.length() - 1);
                        sqls.add(line);
                    }
                }
            }
            if (pre_stmt != null) pre_stmt.close();
            if (rs != null) rs.close();
            for (String sql : sqls) {
                log.debug("Führe SQL aus Patch Datei aus: " + sql);
                pre_stmt = con.prepareStatement(sql);
                pre_stmt.execute();
            }
            if (patchVersion > 0) {
                log.debug("aktualisiere Versionsnummer in DB");
                if (pre_stmt != null) pre_stmt.close();
                if (rs != null) rs.close();
                pre_stmt = con.prepareStatement("UPDATE DB_VERSION SET VERSION = ? WHERE ID_MODUL = 0");
                pre_stmt.setDouble(1, patchVersion);
                pre_stmt.execute();
            }
            con.commit();
        } catch (MalformedURLException exc) {
            log.error(exc.toString());
            throw new Exception("SQL Patch Datei konnte nicht online gefunden werden", exc);
        } catch (IOException exc) {
            log.error(exc.toString());
            throw new Exception("SQL Patch Datei konnte nicht gelesen werden", exc);
        } catch (Throwable exc) {
            log.error("Fehler bei Ausführung der SQL Patch Datei", exc);
            try {
                con.rollback();
            } catch (SQLException exc1) {
            }
            throw new Exception("SQL Patch Datei konnte nicht ausgeführt werden", exc);
        } finally {
            try {
                if (pre_stmt != null) pre_stmt.close();
                if (con != null) con.close();
            } catch (SQLException exc2) {
                log.error("Fehler bei Ausführung von SQL Patch Datei", exc2);
            }
        }
    }
```

## 85966eff-006

**A**

```java
private String generateCode(String seed) {
        try {
            Security.addProvider(new FNVProvider());
            MessageDigest digest = MessageDigest.getInstance("FNV-1a");
            digest.update((seed + UUID.randomUUID().toString()).getBytes());
            byte[] hash1 = digest.digest();
            String sHash1 = "m" + (new String(LibraryBase64.encode(hash1))).replaceAll("=", "").replaceAll("-", "_");
            return sHash1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
```

**B**

```java
@Test
    public void testTrainingQuickprop() throws IOException {
        File temp = File.createTempFile("fannj_", ".tmp");
        temp.deleteOnExit();
        IOUtils.copy(this.getClass().getResourceAsStream("xor.data"), new FileOutputStream(temp));
        List<Layer> layers = new ArrayList<Layer>();
        layers.add(Layer.create(2));
        layers.add(Layer.create(3, ActivationFunction.FANN_SIGMOID_SYMMETRIC));
        layers.add(Layer.create(1, ActivationFunction.FANN_SIGMOID_SYMMETRIC));
        Fann fann = new Fann(layers);
        Trainer trainer = new Trainer(fann);
        trainer.setTrainingAlgorithm(TrainingAlgorithm.FANN_TRAIN_QUICKPROP);
        float desiredError = .001f;
        float mse = trainer.train(temp.getPath(), 500000, 1000, desiredError);
        assertTrue("" + mse, mse <= desiredError);
    }
```

## 85966eff-007

**A**

```java
private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new IOException("Destination '" + destFile + "' exists but is a directory");
        }
        FileInputStream input = new FileInputStream(srcFile);
        try {
            FileOutputStream output = new FileOutputStream(destFile);
            try {
                IOUtils.copy(input, output);
            } finally {
                IOUtils.closeQuietly(output);
            }
        } finally {
            IOUtils.closeQuietly(input);
        }
        if (srcFile.length() != destFile.length()) {
            throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "'");
        }
        if (preserveFileDate) {
            destFile.setLastModified(srcFile.lastModified());
        }
    }
```

**B**

```java
@Override
    public TDSScene loadScene(URL url) throws IOException, IncorrectFormatException, ParsingErrorException {
        boolean baseURLWasNull = setBaseURLFromModelURL(url);
        TDSScene scene = loadScene(url.openStream());
        if (baseURLWasNull) {
            popBaseURL();
        }
        return (scene);
    }
```

## 85966eff-008

**A**

```java
private String convert(InputStream input, String encoding) throws Exception {
        Process p = Runtime.getRuntime().exec("tidy -q -f /dev/null -wrap 0 --output-xml yes --doctype omit --force-output true --new-empty-tags  " + emptyTags + " --quote-nbsp no -utf8");
        Thread t = new CopyThread(input, p.getOutputStream());
        t.start();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        IOUtils.copy(p.getInputStream(), output);
        p.waitFor();
        t.join();
        return output.toString();
    }
```

**B**

```java
public static boolean insereLicao(final Connection con, Licao lic, Autor aut, Descricao desc) {
        try {
            con.setAutoCommit(false);
            Statement smt = con.createStatement();
            if (aut.getCodAutor() == 0) {
                GeraID.gerarCodAutor(con, aut);
                smt.executeUpdate("INSERT INTO autor VALUES(" + aut.getCodAutor() + ",'" + aut.getNome() + "','" + aut.getEmail() + "')");
            }
            GeraID.gerarCodDescricao(con, desc);
            GeraID.gerarCodLicao(con, lic);
            String titulo = lic.getTitulo().replaceAll("['\"]", "");
            String coment = lic.getComentario().replaceAll("[']", "\"");
            String texto = desc.getTexto().replaceAll("[']", "\"");
            smt.executeUpdate("INSERT INTO descricao VALUES(" + desc.getCodDesc() + ",'" + texto + "')");
            smt.executeUpdate("INSERT INTO licao VALUES(" + lic.getCodigo() + ",'" + titulo + "','" + coment + "'," + desc.getCodDesc() + ")");
            smt.executeUpdate("INSERT INTO lic_aut VALUES(" + lic.getCodigo() + "," + aut.getCodAutor() + ")");
            con.commit();
            return (true);
        } catch (SQLException e) {
            try {
                JOptionPane.showMessageDialog(null, "Rolling back transaction", "LICAO: Database error", JOptionPane.ERROR_MESSAGE);
                con.rollback();
            } catch (SQLException e1) {
                System.err.print(e1.getSQLState());
            }
            return (false);
        } finally {
            try {
                con.setAutoCommit(true);
            } catch (SQLException e2) {
                System.err.print(e2.getSQLState());
            }
        }
    }
```

## 85966eff-009

**A**

```java
private void documentFileChooserActionPerformed(java.awt.event.ActionEvent evt) {
        if (evt.getActionCommand().equals(JFileChooser.APPROVE_SELECTION)) {
            File selectedFile = documentFileChooser.getSelectedFile();
            File collectionCopyFile;
            String newDocumentName = selectedFile.getName();
            Document newDocument = new Document(newDocumentName);
            if (activeCollection.containsDocument(newDocument)) {
                int matchingFilenameDistinguisher = 1;
                StringBuilder distinguisherReplacer = new StringBuilder();
                newDocumentName = newDocumentName.concat("(" + matchingFilenameDistinguisher + ")");
                newDocument.setDocumentName(newDocumentName);
                while (activeCollection.containsDocument(newDocument)) {
                    matchingFilenameDistinguisher++;
                    newDocumentName = distinguisherReplacer.replace(newDocumentName.length() - 2, newDocumentName.length() - 1, new Integer(matchingFilenameDistinguisher).toString()).toString();
                    newDocument.setDocumentName(newDocumentName);
                }
            }
            Scanner tokenizer = null;
            FileChannel fileSource = null;
            FileChannel collectionDestination = null;
            HashMap<String, Integer> termHashMap = new HashMap<String, Integer>();
            Index collectionIndex = activeCollection.getIndex();
            int documentTermMaxFrequency = 0;
            int currentTermFrequency;
            try {
                tokenizer = new Scanner(new BufferedReader(new FileReader(selectedFile)));
                tokenizer.useDelimiter(Pattern.compile("\\p{Space}|\\p{Punct}|\\p{Cntrl}"));
                String nextToken;
                while (tokenizer.hasNext()) {
                    nextToken = tokenizer.next().toLowerCase();
                    if (!nextToken.isEmpty()) if (termHashMap.containsKey(nextToken)) termHashMap.put(nextToken, termHashMap.get(nextToken) + 1); else termHashMap.put(nextToken, 1);
                }
                Term newTerm;
                for (String term : termHashMap.keySet()) {
                    newTerm = new Term(term);
                    if (!collectionIndex.termExists(newTerm)) collectionIndex.addTerm(newTerm);
                    currentTermFrequency = termHashMap.get(term);
                    if (currentTermFrequency > documentTermMaxFrequency) documentTermMaxFrequency = currentTermFrequency;
                    collectionIndex.addOccurence(newTerm, newDocument, currentTermFrequency);
                }
                activeCollection.addDocument(newDocument);
                String userHome = System.getProperty("user.home");
                String fileSeparator = System.getProperty("file.separator");
                collectionCopyFile = new File(userHome + fileSeparator + "Infrared" + fileSeparator + activeCollection.getDocumentCollectionName() + fileSeparator + newDocumentName);
                collectionCopyFile.createNewFile();
                fileSource = new FileInputStream(selectedFile).getChannel();
                collectionDestination = new FileOutputStream(collectionCopyFile).getChannel();
                collectionDestination.transferFrom(fileSource, 0, fileSource.size());
            } catch (FileNotFoundException e) {
                System.err.println(e.getMessage() + " This error should never occur! The file was just selected!");
                return;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "An I/O error occured during file transfer!", "File transfer I/O error", JOptionPane.WARNING_MESSAGE);
                return;
            } finally {
                try {
                    if (tokenizer != null) tokenizer.close();
                    if (fileSource != null) fileSource.close();
                    if (collectionDestination != null) collectionDestination.close();
                } catch (IOException e) {
                    System.err.println(e.getMessage());
                }
            }
            processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        } else if (evt.getActionCommand().equalsIgnoreCase(JFileChooser.CANCEL_SELECTION)) processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
```

**B**

```java
public static boolean downloadFile(String url, String destination) throws Exception {
        BufferedInputStream bi = null;
        BufferedOutputStream bo = null;
        File destfile;
        java.net.URL fileurl;
        fileurl = new java.net.URL(url);
        bi = new BufferedInputStream(fileurl.openStream());
        destfile = new File(destination);
        if (!destfile.createNewFile()) {
            destfile.delete();
            destfile.createNewFile();
        }
        bo = new BufferedOutputStream(new FileOutputStream(destfile));
        int readedbyte;
        while ((readedbyte = bi.read()) != -1) {
            bo.write(readedbyte);
        }
        bi.close();
        bo.close();
        return true;
    }
```

## 85966eff-010

**A**

```java
public ClientDTO changePassword(String pMail, String pMdp) {
        Client vClientBean = null;
        ClientDTO vClientDTO = null;
        vClientBean = mClientDao.getClient(pMail);
        if (vClientBean != null) {
            MessageDigest vMd5Instance;
            try {
                vMd5Instance = MessageDigest.getInstance("MD5");
                vMd5Instance.reset();
                vMd5Instance.update(pMdp.getBytes());
                byte[] vDigest = vMd5Instance.digest();
                BigInteger vBigInt = new BigInteger(1, vDigest);
                String vHashPassword = vBigInt.toString(16);
                vClientBean.setMdp(vHashPassword);
                vClientDTO = BeanToDTO.getInstance().createClientDTO(vClientBean);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        return vClientDTO;
    }
```

**B**

```java
public static void main(String[] args) {
        Stopwatch.start("");
        HtmlParser parser = new HtmlParser();
        try {
            Stopwatch.printTimeReset("", "> ParserDelegator");
            ParserDelegator del = new ParserDelegator();
            Stopwatch.printTimeReset("", "> url");
            URL url = new URL(args[0]);
            Stopwatch.printTimeReset("", "> openStrem");
            InputStream is = url.openStream();
            Stopwatch.printTimeReset("", "< parse");
            del.parse(new InputStreamReader(is), parser, true);
            Stopwatch.printTimeReset("", "< parse");
        } catch (Throwable t) {
            t.printStackTrace();
        }
        Stopwatch.printTimeReset("", "> traversal");
        TreeTraversal.traverse(parser.startTag, "eachChild", new Function() {

            String lastPath = null;

            public void apply(Object obj) {
                if (obj instanceof String) {
                    System.out.print(lastPath + ":");
                    System.out.println(obj);
                    return;
                }
                Tag t = (Tag) obj;
                lastPath = Utils.tagPath(t);
                System.out.println(lastPath);
            }
        });
        Stopwatch.printTimeReset("", "< traversal");
    }
```

## 85966eff-011

**A**

```java
public static boolean copy(File source, File target) {
        try {
            if (!source.exists()) return false;
            target.getParentFile().mkdirs();
            InputStream input = new FileInputStream(source);
            OutputStream output = new FileOutputStream(target);
            byte[] buf = new byte[1024];
            int len;
            while ((len = input.read(buf)) > 0) output.write(buf, 0, len);
            input.close();
            output.close();
            return true;
        } catch (Exception exc) {
            exc.printStackTrace();
            return false;
        }
    }
```

**B**

```java
public void compressImage(InputStream input, String output, DjatokaEncodeParam params) throws DjatokaException {
        if (params == null) params = new DjatokaEncodeParam();
        File inputFile;
        try {
            inputFile = File.createTempFile("tmp", ".tif");
            inputFile.deleteOnExit();
            IOUtils.copyStream(input, new FileOutputStream(inputFile));
            if (params.getLevels() == 0) {
                ImageRecord dim = ImageRecordUtils.getImageDimensions(inputFile.getAbsolutePath());
                params.setLevels(ImageProcessingUtils.getLevelCount(dim.getWidth(), dim.getHeight()));
                dim = null;
            }
        } catch (IOException e) {
            logger.error(e, e);
            throw new DjatokaException(e);
        }
        compressImage(inputFile.getAbsolutePath(), output, params);
        if (inputFile != null) inputFile.delete();
    }
```

## 85966eff-012

**A**

```java
@Test
    public void testWrite() throws Exception {
        MrstkXmlFileReader reader = new MrstkXmlFileReader();
        reader.setFileName("..//data//MrstkXML//prototype3.xml");
        reader.read();
        SpectrumArray sp = reader.getOutput();
        File tmp = File.createTempFile("mrstktest", ".xml");
        System.out.println("Writing temp file: " + tmp.getAbsolutePath());
        MrstkXmlFileWriter writer = new MrstkXmlFileWriter(sp);
        writer.setFile(tmp);
        writer.write();
        MrstkXmlFileReader reader2 = new MrstkXmlFileReader();
        reader2.setFileName(writer.getFile().getAbsolutePath());
        reader2.read();
        SpectrumArray sp2 = reader2.getOutput();
        assertTrue(sp.equals(sp2));
    }
```

**B**

```java
private void addAuditDatastream() throws ObjectIntegrityException, StreamIOException {
        if (m_obj.getAuditRecords().size() == 0) {
            return;
        }
        String dsId = m_pid.toURI() + "/AUDIT";
        String dsvId = dsId + "/" + DateUtility.convertDateToString(m_obj.getCreateDate());
        Entry dsEntry = m_feed.addEntry();
        dsEntry.setId(dsId);
        dsEntry.setTitle("AUDIT");
        dsEntry.setUpdated(m_obj.getCreateDate());
        dsEntry.addCategory(MODEL.STATE.uri, "A", null);
        dsEntry.addCategory(MODEL.CONTROL_GROUP.uri, "X", null);
        dsEntry.addCategory(MODEL.VERSIONABLE.uri, "false", null);
        dsEntry.addLink(dsvId, Link.REL_ALTERNATE);
        Entry dsvEntry = m_feed.addEntry();
        dsvEntry.setId(dsvId);
        dsvEntry.setTitle("AUDIT.0");
        dsvEntry.setUpdated(m_obj.getCreateDate());
        ThreadHelper.addInReplyTo(dsvEntry, m_pid.toURI() + "/AUDIT");
        dsvEntry.addCategory(MODEL.FORMAT_URI.uri, AUDIT1_0.uri, null);
        dsvEntry.addCategory(MODEL.LABEL.uri, "Audit Trail for this object", null);
        if (m_format.equals(ATOM_ZIP1_1)) {
            String name = "AUDIT.0.xml";
            try {
                m_zout.putNextEntry(new ZipEntry(name));
                Reader r = new StringReader(DOTranslationUtility.getAuditTrail(m_obj));
                IOUtils.copy(r, m_zout, m_encoding);
                m_zout.closeEntry();
                r.close();
            } catch (IOException e) {
                throw new StreamIOException(e.getMessage(), e);
            }
            IRI iri = new IRI(name);
            dsvEntry.setSummary("AUDIT.0");
            dsvEntry.setContent(iri, "text/xml");
        } else {
            dsvEntry.setContent(DOTranslationUtility.getAuditTrail(m_obj), "text/xml");
        }
    }
```

## 85966eff-013

**A**

```java
private void getRandomGUID(boolean secure) {
        MessageDigest md5 = null;
        StringBuffer sbValueBeforeMD5 = new StringBuffer();
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            logger.debug("Random GUID error: " + e.getMessage());
        }
        try {
            long time = System.currentTimeMillis();
            long rand = 0;
            if (secure) {
                rand = mySecureRand.nextLong();
            } else {
                rand = myRand.nextLong();
            }
            sbValueBeforeMD5.append(s_id);
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(time));
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(rand));
            valueBeforeMD5 = sbValueBeforeMD5.toString();
            md5.update(valueBeforeMD5.getBytes());
            byte[] array = md5.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            valueAfterMD5 = sb.toString();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
```

**B**

```java
public static void copyFile(File from, File to) throws IOException {
        FileInputStream in = new FileInputStream(from);
        FileOutputStream out = new FileOutputStream(to);
        int c;
        while ((c = in.read()) != -1) out.write(c);
        in.close();
        out.close();
    }
```

## 85966eff-014

**A**

```java
public static void main(String[] args) {
        try {
            FileReader reader = new FileReader(args[0]);
            FileWriter writer = new FileWriter(args[1]);
            html2xhtml(reader, writer);
            writer.close();
            reader.close();
        } catch (Exception e) {
            freemind.main.Resources.getInstance().logException(e);
        }
    }
```

**B**

```java
protected void createDb() {
        File rootFolder = new File(dbFolderPath);
        if (!rootFolder.exists()) {
            rootFolder.mkdirs();
        }
        openConnection();
        try {
            Statement stat = connection.createStatement();
            ResourceBundle bundle = ResourceBundle.getBundle("uTaggerDb");
            for (String key : bundle.keySet()) {
                stat.executeUpdate(bundle.getString(key));
            }
            commit();
        } catch (SQLException e) {
            LOG.warn(e);
            rollback();
        }
    }
```

## 85966eff-015

**A**

```java
public int process(ProcessorContext context) throws InterruptedException, ProcessorException {
        logger.info("JAISaveTask:process");
        final RenderedOp im = (RenderedOp) context.get("RenderedOp");
        final String path = "s3://s3.amazonaws.com/rssfetch/" + (new Guid());
        final PNGEncodeParam.RGB encPar = new PNGEncodeParam.RGB();
        encPar.setTransparentRGB(new int[] { 0, 0, 0 });
        File tmpFile = null;
        try {
            tmpFile = File.createTempFile("thmb", ".png");
            OutputStream out = new FileOutputStream(tmpFile);
            final ParameterBlock pb = (new ParameterBlock()).addSource(im).add(out).add("png").add(encPar);
            JAI.create("encode", pb, null);
            out.flush();
            out.close();
            FileInputStream in = new FileInputStream(tmpFile);
            final XFile xfile = new XFile(path);
            final XFileOutputStream xout = new XFileOutputStream(xfile);
            final com.luzan.common.nfs.s3.XFileExtensionAccessor xfa = ((com.luzan.common.nfs.s3.XFileExtensionAccessor) xfile.getExtensionAccessor());
            if (xfa != null) {
                xfa.setMimeType("image/png");
                xfa.setContentLength(tmpFile.length());
            }
            IOUtils.copy(in, xout);
            xout.flush();
            xout.close();
            in.close();
            context.put("outputPath", path);
        } catch (IOException e) {
            logger.error(e);
            throw new ProcessorException(e);
        } catch (Throwable e) {
            logger.error(e);
            throw new ProcessorException(e);
        } finally {
            if (tmpFile != null && tmpFile.exists()) {
                tmpFile.delete();
            }
        }
        return TaskState.STATE_MO_START + TaskState.STATE_ENCODE;
    }
```

**B**

```java
private void unzipResource(final String resourceName, final File targetDirectory) throws IOException {
        final URL resource = this.getClass().getResource(resourceName);
        assertNotNull("Expected '" + resourceName + "' not found.", resource);
        assertTrue(targetDirectory.isAbsolute());
        FileUtils.deleteDirectory(targetDirectory);
        assertTrue(targetDirectory.mkdirs());
        ZipInputStream in = null;
        boolean suppressExceptionOnClose = true;
        try {
            in = new ZipInputStream(resource.openStream());
            ZipEntry e;
            while ((e = in.getNextEntry()) != null) {
                if (e.isDirectory()) {
                    continue;
                }
                final File dest = new File(targetDirectory, e.getName());
                assertTrue(dest.isAbsolute());
                OutputStream out = null;
                try {
                    out = FileUtils.openOutputStream(dest);
                    IOUtils.copy(in, out);
                    suppressExceptionOnClose = false;
                } finally {
                    try {
                        if (out != null) {
                            out.close();
                        }
                        suppressExceptionOnClose = true;
                    } catch (final IOException ex) {
                        if (!suppressExceptionOnClose) {
                            throw ex;
                        }
                    }
                }
                in.closeEntry();
            }
            suppressExceptionOnClose = false;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (final IOException e) {
                if (!suppressExceptionOnClose) {
                    throw e;
                }
            }
        }
    }
```

## 85966eff-016

**A**

```java
@SuppressWarnings("finally")
  private void compress(File src) throws IOException
  {
    if (this.switches.contains(Switch.test))
      return;

    checkSourceFile(src);
    if (src.getPath().endsWith(".bz2"))
    {
      this.log.println("WARNING: skipping file because it already has .bz2 suffix:").println(src);
      return;
    }

    final File dst = new File(src.getPath() + ".bz2").getAbsoluteFile();
    if (!checkDestFile(dst))
      return;

    FileChannel       inChannel   = null;
    FileChannel       outChannel  = null;
    FileOutputStream  fileOut     = null;
    BZip2OutputStream bzOut       = null;
    FileLock          inLock      = null;
    FileLock          outLock     = null;

    try
    {
      inChannel = new FileInputStream(src).getChannel();
      final long inSize = inChannel.size();
      inLock = inChannel.tryLock(0, inSize, true);
      if (inLock == null)
        throw error("source file locked by another process: " + src);

      fileOut     = new FileOutputStream(dst);
      outChannel  = fileOut.getChannel();
      bzOut       = new BZip2OutputStream(
        new BufferedXOutputStream(fileOut, 8192),
        Math.min(
          (this.blockSize == -1) ? BZip2OutputStream.MAX_BLOCK_SIZE : this.blockSize,
          BZip2OutputStream.chooseBlockSize(inSize)
        )
      );

      outLock = outChannel.tryLock();
      if (outLock == null)
        throw error("destination file locked by another process: " + dst);

      final boolean showProgress = this.switches.contains(Switch.showProgress);
      long pos = 0;
      int progress = 0;

      if (showProgress || this.verbose)
      {
        this.log.print("source: " + src).print(": size=").println(inSize);
        this.log.println("target: " + dst);
      }

      while (true)
      {
        final long maxStep = showProgress ? Math.max(8192, (inSize - pos) / MAX_PROGRESS) : (inSize - pos);
        if (maxStep <= 0)
        {
          if (showProgress)
          {
            for (int i = progress; i < MAX_PROGRESS; i++)
              this.log.print('#');
            this.log.println(" done");
          }
          break;
        }
        else
        {
          final long step = inChannel.transferTo(pos, maxStep, bzOut);
          if ((step == 0) && (inChannel.size() != inSize))
            throw error("file " + src + " has been modified concurrently by another process");

          pos += step;
          if (showProgress)
          {
            final double  p           = (double) pos / (double) inSize;
            final int     newProgress = (int) (MAX_PROGRESS * p);
            for (int i = progress; i < newProgress; i++)
              this.log.print('#');
            progress = newProgress;
          }
        }
      }

      inLock.release();
      inChannel.close();
      bzOut.closeInstance();
      final long outSize = outChannel.position();
      outChannel.truncate(outSize);
      outLock.release();
      fileOut.close();

      if (this.verbose)
      {
        final double ratio = (inSize == 0) ? (outSize * 100) : ((double) outSize / (double) inSize);
        this.log.print("raw size: ").print(inSize)
          .print("; compressed size: ").print(outSize)
          .print("; compression ratio: ").print(ratio).println('%');
      }

      if (!this.switches.contains(Switch.keep))
      {
        if (!src.delete())
          throw error("unable to delete sourcefile: " + src);
      }
    }
    catch (final IOException ex)
    {
      IO.tryClose(inChannel);
      IO.tryClose(bzOut);
      IO.tryClose(fileOut);
      IO.tryRelease(inLock);
      IO.tryRelease(outLock);
      try
      {
        this.log.println();
      }
      finally
      {
        throw ex;
      }
    }
  }
```

**B**

```java
public Document getSdlDomResource(String aResourceName) throws SdlException {
        InputStream in = null;
        try {
            URL url = getDeploymentContext().getResourceURL(aResourceName);
            if (url == null) {
                return null;
            } else {
                in = url.openStream();
                return getSdlParser().loadSdlDocument(in, null);
            }
        } catch (Throwable t) {
            logger.error("Error: unable to load: " + aResourceName + " from " + getDeploymentContext().getDeploymentLocation());
            throw new SdlDeploymentException(MessageFormat.format("unable to load: {0} from {1}", new Object[] { aResourceName, getDeploymentContext().getDeploymentLocation() }), t);
        } finally {
            SdlCloser.close(in);
        }
    }
```

## 85966eff-017

**A**

```java
private void getImage(String filename) throws MalformedURLException, IOException, SAXException, FileNotFoundException {
        String url = Constants.STRATEGICDOMINATION_URL + "/images/gameimages/" + filename;
        WebRequest req = new GetMethodWebRequest(url);
        WebResponse response = wc.getResponse(req);
        File file = new File("etc/images/" + filename);
        FileOutputStream outputStream = new FileOutputStream(file);
        IOUtils.copy(response.getInputStream(), outputStream);
    }
```

**B**

```java
public boolean check(String credentials) throws IOException {
            if (credentials == null) return true;
            try {
                MessageDigest md = MessageDigest.getInstance("MD5");
                md.reset();
                md.update(method.getBytes("ISO-8859-1"));
                md.update((byte) ':');
                md.update(uri.getBytes("ISO-8859-1"));
                byte[] ha2 = md.digest();
                md.update(credentials.getBytes("ISO-8859-1"));
                md.update((byte) ':');
                md.update(nonce.getBytes("ISO-8859-1"));
                md.update((byte) ':');
                md.update(MessageDigester.byteArrayToHex(ha2).getBytes("ISO-8859-1"));
                byte[] digest = md.digest();
                return (MessageDigester.byteArrayToHex(digest).equalsIgnoreCase(response));
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("MD5 not supported");
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException("Encoding not supported");
            }
        }
```

## 85966eff-018

**A**

```java
protected boolean update(String sql, int requiredRows, int maxRows) throws SQLException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("executing " + sql + "...");
        }
        Connection connection = null;
        boolean oldAutoCommit = true;
        try {
            connection = dataSource.getConnection();
            connection.clearWarnings();
            oldAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(sql);
            if (requiredRows != -1 && rowsAffected < requiredRows) {
                LOG.warn("(" + rowsAffected + ") less than " + requiredRows + " rows affected, rolling back...");
                connection.rollback();
                return false;
            }
            if (maxRows != -1 && rowsAffected > maxRows) {
                LOG.warn("(" + rowsAffected + ") more than " + maxRows + " rows affected, rolling back...");
                connection.rollback();
                return false;
            }
            connection.commit();
            return true;
        } catch (SQLException e) {
            LOG.error("Unable to update database using: " + sql, e);
            throw e;
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(oldAutoCommit);
                    connection.close();
                }
            } catch (SQLException e) {
                LOG.error("Unable to close connection: " + e, e);
            }
        }
    }
```

**B**

```java
private int resourceToString(String aFile, StringBuffer aBuffer) {
        int cols = 0;
        URL url = getClass().getResource(aFile);
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String line = "";
            do {
                line = in.readLine();
                if (line != null) {
                    if (line.length() > cols) cols = line.length();
                    aBuffer.append(line);
                    aBuffer.append('\n');
                }
            } while (line != null);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cols;
    }
```

## 85966eff-019

**A**

```java
protected void checkWeavingJar() throws IOException {
        OutputStream out = null;
        try {
            final File weaving = new File(getWeavingPath());
            if (!weaving.exists()) {
                new File(getWeavingFolder()).mkdir();
                weaving.createNewFile();
                final Path src = new Path("weaving/openfrwk-weaving.jar");
                final InputStream in = FileLocator.openStream(getBundle(), src, false);
                out = new FileOutputStream(getWeavingPath(), true);
                IOUtils.copy(in, out);
                Logger.log(Logger.INFO, "Put weaving jar at location " + weaving);
            } else {
                Logger.getLog().info("File openfrwk-weaving.jar already exists at " + weaving);
            }
        } catch (final SecurityException e) {
            Logger.log(Logger.ERROR, "[SECURITY EXCEPTION] Not enough privilegies to create " + "folder and copy NexOpen weaving jar at location " + getWeavingFolder());
            Logger.logException(e);
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }
    }
```

**B**

```java
private int getCountFromUrl(String url) {
        HttpGet request = new HttpGet(url);
        try {
            HttpResponse response = httpClient.execute(request);
            int status = response.getStatusLine().getStatusCode();
            if (status != HttpStatus.SC_OK) {
                ByteArrayOutputStream ostream = new ByteArrayOutputStream();
                response.getEntity().writeTo(ostream);
                Log.e(TAG, ostream.toString());
            } else {
                InputStream content = response.getEntity().getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(content), 10);
                String count = reader.readLine();
                content.close();
                return Integer.parseInt(count);
            }
        } catch (IOException e) {
            Log.e(TAG, Log.getStackTraceString(e));
        }
        return -1;
    }
```

## 85966eff-020

**A**

```java
public Image storeImage(String title, String pathToImage, Map<String, Object> additionalProperties) {
        File collectionFolder = ProjectManager.getInstance().getFolder(PropertyHandler.getInstance().getProperty("_default_collection_name"));
        File imageFile = new File(pathToImage);
        String filename = "";
        String format = "";
        File copiedImageFile;
        while (true) {
            filename = "image" + UUID.randomUUID().hashCode();
            if (!DbEntryProvider.INSTANCE.idExists(filename)) {
                Path path = new Path(pathToImage);
                format = path.getFileExtension();
                copiedImageFile = new File(collectionFolder.getAbsolutePath() + File.separator + filename + "." + format);
                if (!copiedImageFile.exists()) break;
            }
        }
        try {
            copiedImageFile.createNewFile();
        } catch (IOException e1) {
            ExceptionHandlingService.INSTANCE.handleException(e1);
            return null;
        }
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(imageFile), 4096);
            out = new BufferedOutputStream(new FileOutputStream(copiedImageFile), 4096);
            int c;
            while ((c = in.read()) != -1) out.write(c);
            in.close();
            out.close();
        } catch (FileNotFoundException e) {
            ExceptionHandlingService.INSTANCE.handleException(e);
            return null;
        } catch (IOException e) {
            ExceptionHandlingService.INSTANCE.handleException(e);
            return null;
        }
        Image image = new ImageImpl();
        image.setId(filename);
        image.setFormat(format);
        image.setEntryDate(new Date());
        image.setTitle(title);
        image.setAdditionalProperties(additionalProperties);
        boolean success = DbEntryProvider.INSTANCE.storeNewImage(image);
        if (success) return image;
        return null;
    }
```

**B**

```java
public void setTypeRefs(Connection conn) {
        log.traceln("\tProcessing " + table + " references..");
        try {
            String query = " select distinct c.id, c.qualifiedname from " + table + ", CLASSTYPE c " + " where " + table + "." + reffield + " is null and " + table + "." + classnamefield + " = c.qualifiedname";
            PreparedStatement pstmt = conn.prepareStatement(query);
            long start = new Date().getTime();
            ResultSet rset = pstmt.executeQuery();
            long queryTime = new Date().getTime() - start;
            log.debug("query time: " + queryTime + " ms");
            String update = "update " + table + " set " + reffield + "=? where " + classnamefield + "=? and " + reffield + " is null";
            PreparedStatement pstmt2 = conn.prepareStatement(update);
            int n = 0;
            start = new Date().getTime();
            while (rset.next()) {
                n++;
                pstmt2.setInt(1, rset.getInt(1));
                pstmt2.setString(2, rset.getString(2));
                pstmt2.executeUpdate();
            }
            queryTime = new Date().getTime() - start;
            log.debug("total update time: " + queryTime + " ms");
            log.debug("number of times through loop: " + n);
            if (n > 0) log.debug("avg update time: " + (queryTime / n) + " ms");
            pstmt2.close();
            rset.close();
            pstmt.close();
            conn.commit();
            log.verbose("Updated (committed) " + table + " references");
        } catch (SQLException ex) {
            log.error("Internal Reference Update Failed!");
            DBUtils.logSQLException(ex);
            log.error("Rolling back..");
            try {
                conn.rollback();
            } catch (SQLException inner_ex) {
                log.error("rollback failed!");
            }
        }
    }
```

## 85966eff-021

**A**

```java
private void fileCopy(final File src, final File dest) throws IOException {
        final FileChannel srcChannel = new FileInputStream(src).getChannel();
        final FileChannel dstChannel = new FileOutputStream(dest).getChannel();
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
        srcChannel.close();
        dstChannel.close();
    }
```

**B**

```java
public static String SHA1(String string) throws XLWrapException {
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-1");
        } catch (NoSuchAlgorithmException e) {
            throw new XLWrapException("SHA-1 message digest is not available.");
        }
        byte[] data = new byte[40];
        md.update(string.getBytes());
        data = md.digest();
        StringBuffer buf = new StringBuffer();
        for (int i = 0; i < data.length; i++) {
            int halfbyte = (data[i] >>> 4) & 0x0F;
            int two_halfs = 0;
            do {
                if ((0 <= halfbyte) && (halfbyte <= 9)) buf.append((char) ('0' + halfbyte)); else buf.append((char) ('a' + (halfbyte - 10)));
                halfbyte = data[i] & 0x0F;
            } while (two_halfs++ < 1);
        }
        return buf.toString();
    }
```

## 85966eff-022

**A**

```java
private static void copy(File source, File dest) throws FileNotFoundException, IOException {
        FileInputStream input = new FileInputStream(source);
        FileOutputStream output = new FileOutputStream(dest);
        System.out.println("Copying " + source + " to " + dest);
        IOUtils.copy(input, output);
        output.close();
        input.close();
        dest.setLastModified(source.lastModified());
    }
```

**B**

```java
public static ArrayList<String> remoteCall(Map<String, String> dataDict) {
        ArrayList<String> result = new ArrayList<String>();
        String encodedData = "";
        for (String key : dataDict.keySet()) {
            String encodedSegment = "";
            String value = dataDict.get(key);
            if (value == null) continue;
            try {
                encodedSegment = key + "=" + URLEncoder.encode(value, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            if (encodedData.length() > 0) {
                encodedData += "&";
            }
            encodedData += encodedSegment;
        }
        try {
            URL url = new URL(baseURL + encodedData);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                result.add(line);
                System.out.println("GOT: " + line);
            }
            reader.close();
            result.remove(0);
            if (result.size() != 0) {
                if (!result.get(result.size() - 1).equals("DONE")) {
                    result.clear();
                } else {
                    result.remove(result.size() - 1);
                }
            }
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
        return result;
    }
```

## 85966eff-023

**A**

```java
public void downloadFile(OutputStream os, int fileId) throws IOException, SQLException {
        Connection conn = null;
        try {
            conn = ds.getConnection();
            Guard.checkConnectionNotNull(conn);
            PreparedStatement ps = conn.prepareStatement("select * from FILE_BODIES where file_id=?");
            ps.setInt(1, fileId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new FileNotFoundException("File with id=" + fileId + " not found!");
            }
            Blob blob = rs.getBlob("data");
            InputStream is = blob.getBinaryStream();
            IOUtils.copyLarge(is, os);
        } finally {
            JdbcDaoHelper.safeClose(conn, log);
        }
    }
```

**B**

```java
public void test(TestHarness harness) {
        harness.checkPoint("TestOfMD4");
        try {
            Security.addProvider(new JarsyncProvider());
            algorithm = MessageDigest.getInstance("BrokenMD4", "JARSYNC");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.provider");
            throw new Error(x);
        }
        try {
            for (int i = 0; i < 64; i++) algorithm.update((byte) 'a');
            byte[] md = algorithm.digest();
            String exp = "755cd64425f260e356f5303ee82a2d5f";
            harness.check(exp.equals(Util.toHexString(md)), "testSixtyFourA");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.provider");
        }
        try {
            harness.verbose("NOTE: This test may take a while.");
            for (int i = 0; i < 536870913; i++) algorithm.update((byte) 'a');
            byte[] md = algorithm.digest();
            String exp = "b6cea9f528a85963f7529a9e3a2153db";
            harness.check(exp.equals(Util.toHexString(md)), "test536870913A");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.provider");
        }
        try {
            byte[] md = algorithm.digest("a".getBytes());
            String exp = "bde52cb31de33e46245e05fbdbd6fb24";
            harness.check(exp.equals(Util.toHexString(md)), "testA");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testA");
        }
        try {
            byte[] md = algorithm.digest("abc".getBytes());
            String exp = "a448017aaf21d8525fc10ae87aa6729d";
            harness.check(exp.equals(Util.toHexString(md)), "testABC");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testABC");
        }
        try {
            byte[] md = algorithm.digest("message digest".getBytes());
            String exp = "d9130a8164549fe818874806e1c7014b";
            harness.check(exp.equals(Util.toHexString(md)), "testMessageDigest");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testMessageDigest");
        }
        try {
            byte[] md = algorithm.digest("abcdefghijklmnopqrstuvwxyz".getBytes());
            String exp = "d79e1c308aa5bbcdeea8ed63df412da9";
            harness.check(exp.equals(Util.toHexString(md)), "testAlphabet");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testAlphabet");
        }
        try {
            byte[] md = algorithm.digest("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".getBytes());
            String exp = "043f8582f241db351ce627e153e7f0e4";
            harness.check(exp.equals(Util.toHexString(md)), "testAsciiSubset");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testAsciiSubset");
        }
        try {
            byte[] md = algorithm.digest("12345678901234567890123456789012345678901234567890123456789012345678901234567890".getBytes());
            String exp = "e33b4ddc9c38f2199c3e7b164fcc0536";
            harness.check(exp.equals(Util.toHexString(md)), "testEightyNumerics");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testEightyNumerics");
        }
        try {
            algorithm.update("a".getBytes(), 0, 1);
            clone = (MessageDigest) algorithm.clone();
            byte[] md = algorithm.digest();
            String exp = "bde52cb31de33e46245e05fbdbd6fb24";
            harness.check(exp.equals(Util.toHexString(md)), "testCloning #1");
            clone.update("bc".getBytes(), 0, 2);
            md = clone.digest();
            exp = "a448017aaf21d8525fc10ae87aa6729d";
            harness.check(exp.equals(Util.toHexString(md)), "testCloning #2");
        } catch (Exception x) {
            harness.debug(x);
            harness.fail("TestOfMD4.testCloning");
        }
    }
```

## 85966eff-024

**A**

```java
public static void copyFile(File destFile, File src) throws IOException {
        File destDir = destFile.getParentFile();
        File tempFile = new File(destFile + "_tmp");
        destDir.mkdirs();
        InputStream is = new FileInputStream(src);
        try {
            FileOutputStream os = new FileOutputStream(tempFile);
            try {
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) > 0) os.write(buf, 0, len);
            } finally {
                os.close();
            }
        } finally {
            is.close();
        }
        destFile.delete();
        if (!tempFile.renameTo(destFile)) throw new IOException("Unable to rename " + tempFile + " to " + destFile);
    }
```

**B**

```java
protected InputStream callApiMethod(String apiUrl, String xmlContent, String contentType, String method, int expected) {
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection request = (HttpURLConnection) url.openConnection();
            if (ApplicationConstants.CONNECT_TIMEOUT > -1) {
                request.setConnectTimeout(ApplicationConstants.CONNECT_TIMEOUT);
            }
            if (ApplicationConstants.READ_TIMEOUT > -1) {
                request.setReadTimeout(ApplicationConstants.READ_TIMEOUT);
            }
            for (String headerName : requestHeaders.keySet()) {
                request.setRequestProperty(headerName, requestHeaders.get(headerName));
            }
            request.setRequestMethod(method);
            request.setDoOutput(true);
            if (contentType != null) {
                request.setRequestProperty("Content-Type", contentType);
            }
            if (xmlContent != null) {
                PrintStream out = new PrintStream(new BufferedOutputStream(request.getOutputStream()));
                out.print(xmlContent);
                out.flush();
                out.close();
            }
            request.connect();
            if (request.getResponseCode() != expected) {
                throw new BingMapsException(convertStreamToString(request.getErrorStream()));
            } else {
                return getWrappedInputStream(request.getInputStream(), GZIP_ENCODING.equalsIgnoreCase(request.getContentEncoding()));
            }
        } catch (IOException e) {
            throw new BingMapsException(e);
        }
    }
```

## 85966eff-025

**A**

```java
private String getTextResponse(String address) throws Exception {
        URL url = new URL(address);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setUseCaches(false);
        BufferedReader in = null;
        try {
            con.connect();
            assertEquals(HttpURLConnection.HTTP_OK, con.getResponseCode());
            in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                builder.append(inputLine);
            }
            return builder.toString();
        } finally {
            if (in != null) {
                in.close();
            }
            con.disconnect();
        }
    }
```

**B**

```java
private void newGame() {
        List scenarios = getScenarioChoices();
        ScenarioChoice scenarioChoice = (ScenarioChoice) JOptionPane.showInputDialog(this, "Choose a Scenario", "Choose a Scenario", JOptionPane.PLAIN_MESSAGE, null, scenarios.toArray(), scenarios.get(0));
        if (scenarioChoice == null) {
            return;
        }
        Object obj;
        try {
            obj = scamsoft.util.Toolkit.loadClass(scenarioChoice.className, null);
        } catch (ClassNotFoundException e) {
            handleNetworkException(e);
            return;
        } catch (InstantiationException e) {
            handleNetworkException(e);
            return;
        } catch (InvocationTargetException e) {
            handleNetworkException(e);
            return;
        } catch (IllegalArgumentException e) {
            handleNetworkException(e);
            return;
        } catch (IllegalAccessException e) {
            handleNetworkException(e);
            return;
        }
        if (obj == null || !(obj instanceof Scenario)) {
            return;
        }
        Scenario scenario = (Scenario) obj;
        String[] variations = scenario.getVariations();
        int chosenvariation = 0;
        if (variations.length > 1) {
            String[] variationsChoice = new String[variations.length + 1];
            System.arraycopy(variations, 0, variationsChoice, 0, variations.length);
            variationsChoice[variationsChoice.length - 1] = "Cancel";
            chosenvariation = JOptionPane.showOptionDialog(this, "Choose a Variation", "Choose Variation", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, variationsChoice, variationsChoice[0]);
            if (chosenvariation == JOptionPane.CLOSED_OPTION || chosenvariation == variationsChoice.length - 1) {
                return;
            }
        }
        String path = scenarioChoice.filePrefix + chosenvariation + ".sav";
        URL url = this.getClass().getClassLoader().getResource(path);
        try {
            loadGame(url.openStream());
        } catch (IOException e) {
            handleNetworkException(e);
        }
    }
```

## 85966eff-026

**A**

```java
public void xtest1() throws Exception {
        InputStream input = new FileInputStream("C:/Documentos/j931_01.pdf");
        InputStream tmp = new ITextManager().cut(input, 3, 8);
        FileOutputStream output = new FileOutputStream("C:/temp/split.pdf");
        IOUtils.copy(tmp, output);
        input.close();
        tmp.close();
        output.close();
    }
```

**B**

```java
private String getPlayerName(String id) throws UnsupportedEncodingException, IOException {
        String result = "";
        Map<String, String> players = (Map<String, String>) sc.getAttribute("players");
        if (players.containsKey(id)) {
            result = players.get(id);
            System.out.println("skip name:" + result);
        } else {
            String palyerURL = "http://goal.2010worldcup.163.com/player/" + id + ".html";
            URL url = new URL(palyerURL);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream(), "utf-8"));
            String line = null;
            String nameFrom = "英文名:";
            String nameTo = "</dd>";
            while ((line = reader.readLine()) != null) {
                if (line.indexOf(nameFrom) != -1) {
                    result = line.substring(line.indexOf(nameFrom) + nameFrom.length(), line.indexOf(nameTo));
                    break;
                }
            }
            reader.close();
            players.put(id, result);
        }
        return result;
    }
```

## 85966eff-027

**A**

```java
private void exportJar(File root, List<File> list, Manifest manifest) throws Exception {
        JarOutputStream jarOut = null;
        FileInputStream fin = null;
        try {
            jarOut = new JarOutputStream(new FileOutputStream(jarFile), manifest);
            for (int i = 0; i < list.size(); i++) {
                String filename = list.get(i).getAbsolutePath();
                filename = filename.substring(root.getAbsolutePath().length() + 1);
                fin = new FileInputStream(list.get(i));
                JarEntry entry = new JarEntry(filename.replace('\\', '/'));
                jarOut.putNextEntry(entry);
                byte[] buf = new byte[4096];
                int read;
                while ((read = fin.read(buf)) != -1) {
                    jarOut.write(buf, 0, read);
                }
                jarOut.closeEntry();
                jarOut.flush();
            }
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (Exception e) {
                    ExceptionOperation.operate(e);
                }
            }
            if (jarOut != null) {
                try {
                    jarOut.close();
                } catch (Exception e) {
                }
            }
        }
    }
```

**B**

```java
private String fetchCompareContent() throws IOException {
        URL url = new URL(compareTo);
        StringWriter sw = new StringWriter();
        IOUtils.copy(url.openStream(), sw);
        return sw.getBuffer().toString();
    }
```

## 85966eff-028

**A**

```java
private static String doGetForSessionKey(String authCode) throws Exception {
        String sessionKey = "";
        HttpClient hc = new DefaultHttpClient();
        HttpGet hg = new HttpGet(Common.TEST_SESSION_HOST + Common.TEST_SESSION_PARAM + authCode);
        HttpResponse hr = hc.execute(hg);
        BufferedReader br = new BufferedReader(new InputStreamReader(hr.getEntity().getContent()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        String result = sb.toString();
        Log.i("sessionKeyMessages", result);
        Map<String, String> map = Util.handleURLParameters(result);
        sessionKey = map.get(Common.TOP_SESSION);
        String topParameters = map.get(Common.TOP_PARAMETERS);
        String decTopParameters = Util.decodeBase64(topParameters);
        Log.i("base64", decTopParameters);
        map = Util.handleURLParameters(decTopParameters);
        Log.i("nick", map.get(Common.VISITOR_NICK));
        CachePool.put(Common.VISITOR_NICK, map.get(Common.VISITOR_NICK));
        return sessionKey;
    }
```

**B**

```java
public void delUser(User user) throws SQLException, IOException, ClassNotFoundException {
        String dbUserID;
        String stockSymbol;
        Statement stmt = con.createStatement();
        try {
            con.setAutoCommit(false);
            dbUserID = user.getUserID();
            if (getUser(dbUserID) != null) {
                ResultSet rs1 = stmt.executeQuery("SELECT userID, symbol " + "FROM UserStocks WHERE userID = '" + dbUserID + "'");
                while (rs1.next()) {
                    try {
                        stockSymbol = rs1.getString("symbol");
                        delUserStocks(dbUserID, stockSymbol);
                    } catch (SQLException ex) {
                        throw new SQLException("Deletion of user stock holding failed: " + ex.getMessage());
                    }
                }
                try {
                    stmt.executeUpdate("DELETE FROM Users WHERE " + "userID = '" + dbUserID + "'");
                } catch (SQLException ex) {
                    throw new SQLException("User deletion failed: " + ex.getMessage());
                }
            } else throw new IOException("User not found in database - cannot delete.");
            try {
                con.commit();
            } catch (SQLException ex) {
                throw new SQLException("Transaction commit failed: " + ex.getMessage());
            }
        } catch (SQLException ex) {
            try {
                con.rollback();
            } catch (SQLException sqx) {
                throw new SQLException("Transaction failed then rollback failed: " + sqx.getMessage());
            }
            throw new SQLException("Transaction failed; was rolled back: " + ex.getMessage());
        }
        stmt.close();
    }
```

## 85966eff-029

**A**

```java
public Transaction() throws Exception {
        Connection Conn = null;
        Statement Stmt = null;
        try {
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            Conn = DriverManager.getConnection(DBUrl);
            Conn.setAutoCommit(true);
            Stmt = Conn.createStatement();
            try {
                Stmt.executeUpdate("DROP TABLE trans_test");
            } catch (SQLException sqlEx) {
            }
            Stmt.executeUpdate("CREATE TABLE trans_test (id int not null primary key, decdata double) type=BDB");
            Conn.setAutoCommit(false);
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (1, 21.0)");
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (2, 23.485115)");
            Conn.rollback();
            System.out.println("Roll Ok");
            ResultSet RS = Stmt.executeQuery("SELECT * from trans_test");
            if (!RS.next()) {
                System.out.println("Ok");
            } else {
                System.out.println("Rollback failed");
            }
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (2, 23.485115)");
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (1, 21.485115)");
            Conn.commit();
            RS = Stmt.executeQuery("SELECT * from trans_test where id=2");
            if (RS.next()) {
                System.out.println(RS.getDouble(2));
                System.out.println("Ok");
            } else {
                System.out.println("Rollback failed");
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (Stmt != null) {
                try {
                    Stmt.close();
                } catch (SQLException SQLEx) {
                }
            }
            if (Conn != null) {
                try {
                    Conn.close();
                } catch (SQLException SQLEx) {
                }
            }
        }
    }
```

**B**

```java
public LOCKSSDaemonStatusTableTO getDataFromDaemonStatusTable() throws HttpResponseException {
        LOCKSSDaemonStatusTableXmlStreamParser ldstxp = null;
        LOCKSSDaemonStatusTableTO ldstTO = null;
        HttpEntity entity = null;
        HttpGet httpget = null;
        xstream.setMode(XStream.NO_REFERENCES);
        xstream.alias("HttpClientDAO", HttpClientDAO.class);
        try {
            httpget = new HttpGet(dataUrl);
            logger.log(Level.INFO, "executing request {0}", httpget.getURI());
            HttpResponse resp = httpClient.execute(httpget);
            int statusCode = resp.getStatusLine().getStatusCode();
            if (statusCode != HttpStatus.SC_OK) {
                logger.log(Level.WARNING, "response to the request is not OK: skip this IP: status code={0}", statusCode);
                httpget.abort();
                ldstTO = new LOCKSSDaemonStatusTableTO();
                ldstTO.setBoxHttpStatusOK(false);
                return ldstTO;
            }
            entity = resp.getEntity();
            InputStream is = entity.getContent();
            ldstxp = new LOCKSSDaemonStatusTableXmlStreamParser();
            ldstxp.read(new BufferedInputStream(is));
            ldstTO = ldstxp.getLOCKSSDaemonStatusTableTO();
            ldstTO.setIpAddress(this.ip);
            logger.log(Level.INFO, "After parsing [{0}] table", this.tableId);
            logger.log(Level.FINEST, "After parsing {0}: contents of ldstTO:\n{1}", new Object[] { this.tableId, ldstTO });
            if (ldstTO.hasIncompleteRows) {
                logger.log(Level.WARNING, "!!!!!!!!! incomplete rows are found for {0}", tableId);
                if (ldstTO.getTableData() != null && ldstTO.getTableData().size() > 0) {
                    logger.log(Level.FINE, "incomplete rows: table(map) data dump =[\n{0}\n]", xstream.toXML(ldstTO.getTableData()));
                }
            } else {
                logger.log(Level.INFO, "All rows are complete for {0}", tableId);
            }
        } catch (ConnectTimeoutException ce) {
            logger.log(Level.WARNING, "ConnectTimeoutException occurred", ce);
            ldstTO = new LOCKSSDaemonStatusTableTO();
            ldstTO.setBoxHttpStatusOK(false);
            if (httpget != null) {
                httpget.abort();
            }
            return ldstTO;
        } catch (SocketTimeoutException se) {
            logger.log(Level.WARNING, "SocketTimeoutException occurred", se);
            ldstTO = new LOCKSSDaemonStatusTableTO();
            ldstTO.setBoxHttpStatusOK(false);
            if (httpget != null) {
                httpget.abort();
            }
            return ldstTO;
        } catch (ClientProtocolException pe) {
            logger.log(Level.SEVERE, "The protocol was not http; https is suspected", pe);
            ldstTO = new LOCKSSDaemonStatusTableTO();
            ldstTO.setBoxHttpStatusOK(false);
            ldstTO.setHttpProtocol(false);
            if (httpget != null) {
                httpget.abort();
            }
            return ldstTO;
        } catch (IOException ex) {
            logger.log(Level.SEVERE, "IO exception occurs", ex);
            ldstTO = new LOCKSSDaemonStatusTableTO();
            ldstTO.setBoxHttpStatusOK(false);
            if (httpget != null) {
                httpget.abort();
            }
            return ldstTO;
        } finally {
            if (entity != null) {
                try {
                    EntityUtils.consume(entity);
                } catch (IOException ex) {
                    logger.log(Level.SEVERE, "io exception when entity was to be" + "consumed", ex);
                }
            }
        }
        return ldstTO;
    }
```

## 85966eff-030

**A**

```java
public void testCodingCompletedFromFile() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        WritableByteChannel channel = newChannel(baos);
        HttpParams params = new BasicHttpParams();
        SessionOutputBuffer outbuf = new SessionOutputBufferImpl(1024, 128, params);
        HttpTransportMetricsImpl metrics = new HttpTransportMetricsImpl();
        LengthDelimitedEncoder encoder = new LengthDelimitedEncoder(channel, outbuf, metrics, 5);
        encoder.write(wrap("stuff"));
        File tmpFile = File.createTempFile("testFile", "txt");
        FileOutputStream fout = new FileOutputStream(tmpFile);
        OutputStreamWriter wrtout = new OutputStreamWriter(fout);
        wrtout.write("more stuff");
        wrtout.flush();
        wrtout.close();
        try {
            FileChannel fchannel = new FileInputStream(tmpFile).getChannel();
            encoder.transfer(fchannel, 0, 10);
            fail("IllegalStateException should have been thrown");
        } catch (IllegalStateException ex) {
        } finally {
            tmpFile.delete();
        }
    }
```

**B**

```java
@Override
    public HttpResponse execute() throws IOException {
        if (this.method == HttpMethod.GET) {
            String url = this.toString();
            if (url.length() > this.cutoff) {
                if (log.isLoggable(Level.FINER)) log.finer("URL length " + url.length() + " too long, converting GET to POST: " + url);
                String rebase = this.baseURL + "?method=GET";
                return this.execute(HttpMethod.POST, rebase);
            }
        }
        return super.execute();
    }
```

## 85966eff-031

**A**

```java
private void loadServers() {
        try {
            URL url = new URL(VirtualDeckConfig.SERVERS_URL);
            cmbServer.addItem("Local");
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String str;
            if (in.readLine().equals("[list]")) {
                while ((str = in.readLine()) != null) {
                    String[] host_line = str.split(";");
                    Host h = new Host();
                    h.setIp(host_line[0]);
                    h.setPort(Integer.parseInt(host_line[1]));
                    h.setName(host_line[2]);
                    getServers().add(h);
                    cmbServer.addItem(h.getName());
                }
            }
            in.close();
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
    }
```

**B**

```java
public long copyDirAllFilesToDirectoryRecursive(String baseDirStr, String destDirStr, boolean copyOutputsRtIDsDirs) throws Exception {
        long plussQuotaSize = 0;
        if (baseDirStr.endsWith(sep)) {
            baseDirStr = baseDirStr.substring(0, baseDirStr.length() - 1);
        }
        if (destDirStr.endsWith(sep)) {
            destDirStr = destDirStr.substring(0, destDirStr.length() - 1);
        }
        FileUtils.getInstance().createDirectory(destDirStr);
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        byte dataBuff[] = new byte[bufferSize];
        File baseDir = new File(baseDirStr);
        baseDir.mkdirs();
        if (!baseDir.exists()) {
            createDirectory(baseDirStr);
        }
        if ((baseDir.exists()) && (baseDir.isDirectory())) {
            String[] entryList = baseDir.list();
            if (entryList.length > 0) {
                for (int pos = 0; pos < entryList.length; pos++) {
                    String entryName = entryList[pos];
                    String oldPathFileName = baseDirStr + sep + entryName;
                    File entryFile = new File(oldPathFileName);
                    if (entryFile.isFile()) {
                        String newPathFileName = destDirStr + sep + entryName;
                        File newFile = new File(newPathFileName);
                        if (newFile.exists()) {
                            plussQuotaSize -= newFile.length();
                            newFile.delete();
                        }
                        in = new BufferedInputStream(new FileInputStream(oldPathFileName), bufferSize);
                        out = new BufferedOutputStream(new FileOutputStream(newPathFileName), bufferSize);
                        int readLen;
                        while ((readLen = in.read(dataBuff)) > 0) {
                            out.write(dataBuff, 0, readLen);
                            plussQuotaSize += readLen;
                        }
                        out.flush();
                        in.close();
                        out.close();
                    }
                    if (entryFile.isDirectory()) {
                        boolean enableCopyDir = false;
                        if (copyOutputsRtIDsDirs) {
                            enableCopyDir = true;
                        } else {
                            if (entryFile.getParentFile().getName().equals("outputs")) {
                                enableCopyDir = false;
                            } else {
                                enableCopyDir = true;
                            }
                        }
                        if (enableCopyDir) {
                            plussQuotaSize += this.copyDirAllFilesToDirectoryRecursive(baseDirStr + sep + entryName, destDirStr + sep + entryName, copyOutputsRtIDsDirs);
                        }
                    }
                }
            }
        } else {
            throw new Exception("Base dir not exist ! baseDirStr = (" + baseDirStr + ")");
        }
        return plussQuotaSize;
    }
```

## 85966eff-032

**A**

```java
@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String contentId = req.getParameter(CONTENT_ID);
        String contentType = req.getParameter(CONTENT_TYPE);
        if (contentId == null || contentType == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Content id or content type not specified");
            return;
        }
        try {
            switch(ContentType.valueOf(contentType)) {
                case IMAGE:
                    resp.setContentType("image/jpeg");
                    break;
                case AUDIO:
                    resp.setContentType("audio/mp3");
                    break;
                case VIDEO:
                    resp.setContentType("video/mpeg");
                    break;
                default:
                    throw new IllegalStateException("Invalid content type specified");
            }
        } catch (IllegalArgumentException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid content type specified");
            return;
        }
        String baseUrl = this.getServletContext().getInitParameter(BASE_URL);
        URL url = new URL(baseUrl + "/" + contentType.toLowerCase() + "/" + contentId);
        URLConnection conn = url.openConnection();
        resp.setContentLength(conn.getContentLength());
        IOUtils.copy(conn.getInputStream(), resp.getOutputStream());
    }
```

**B**

```java
public synchronized List<AnidbSearchResult> getAnimeTitles() throws Exception {
        URL url = new URL("http", host, "/api/animetitles.dat.gz");
        ResultCache cache = getCache();
        @SuppressWarnings("unchecked") List<AnidbSearchResult> anime = (List) cache.getSearchResult(null, Locale.ROOT);
        if (anime != null) {
            return anime;
        }
        Pattern pattern = Pattern.compile("^(?!#)(\\d+)[|](\\d)[|]([\\w-]+)[|](.+)$");
        Map<Integer, String> primaryTitleMap = new HashMap<Integer, String>();
        Map<Integer, Map<String, String>> officialTitleMap = new HashMap<Integer, Map<String, String>>();
        Map<Integer, Map<String, String>> synonymsTitleMap = new HashMap<Integer, Map<String, String>>();
        Scanner scanner = new Scanner(new GZIPInputStream(url.openStream()), "UTF-8");
        try {
            while (scanner.hasNextLine()) {
                Matcher matcher = pattern.matcher(scanner.nextLine());
                if (matcher.matches()) {
                    int aid = Integer.parseInt(matcher.group(1));
                    String type = matcher.group(2);
                    String language = matcher.group(3);
                    String title = matcher.group(4);
                    if (type.equals("1")) {
                        primaryTitleMap.put(aid, title);
                    } else if (type.equals("2") || type.equals("4")) {
                        Map<Integer, Map<String, String>> titleMap = (type.equals("4") ? officialTitleMap : synonymsTitleMap);
                        Map<String, String> languageTitleMap = titleMap.get(aid);
                        if (languageTitleMap == null) {
                            languageTitleMap = new HashMap<String, String>();
                            titleMap.put(aid, languageTitleMap);
                        }
                        languageTitleMap.put(language, title);
                    }
                }
            }
        } finally {
            scanner.close();
        }
        anime = new ArrayList<AnidbSearchResult>(primaryTitleMap.size());
        for (Entry<Integer, String> entry : primaryTitleMap.entrySet()) {
            Map<String, String> localizedTitles = new HashMap<String, String>();
            if (synonymsTitleMap.containsKey(entry.getKey())) {
                localizedTitles.putAll(synonymsTitleMap.get(entry.getKey()));
            }
            if (officialTitleMap.containsKey(entry.getKey())) {
                localizedTitles.putAll(officialTitleMap.get(entry.getKey()));
            }
            anime.add(new AnidbSearchResult(entry.getKey(), entry.getValue(), localizedTitles));
        }
        return cache.putSearchResult(null, Locale.ROOT, anime);
    }
```

## 85966eff-033

**A**

```java
public static void main(String[] args) throws NoSuchAlgorithmException {
        String password = "root";
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.update(password.getBytes());
        final byte[] digest = messageDigest.digest();
        final StringBuilder buf = new StringBuilder(digest.length * 2);
        for (int j = 0; j < digest.length; j++) {
            buf.append(HEX_DIGITS[(digest[j] >> 4) & 0x0f]);
            buf.append(HEX_DIGITS[digest[j] & 0x0f]);
        }
        String pwd = buf.toString();
        System.out.println(pwd);
    }
```

**B**

```java
private void collectImageFile(@NotNull final Progress progress, @NotNull final File collectedDirectory) throws IOException {
        final File file = new File(collectedDirectory, ActionBuilderUtils.getString(ACTION_BUILDER, "configSource.image.name"));
        final FileOutputStream fos = new FileOutputStream(file);
        try {
            final FileChannel outChannel = fos.getChannel();
            try {
                final int numOfFaceObjects = faceObjects.size();
                progress.setLabel(ActionBuilderUtils.getString(ACTION_BUILDER, "archCollectImages"), numOfFaceObjects);
                final ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
                final Charset charset = Charset.forName("ISO-8859-1");
                int i = 0;
                for (final FaceObject faceObject : faceObjects) {
                    final String face = faceObject.getFaceName();
                    final String path = archFaceProvider.getFilename(face);
                    try {
                        final FileInputStream fin = new FileInputStream(path);
                        try {
                            final FileChannel inChannel = fin.getChannel();
                            final long imageSize = inChannel.size();
                            byteBuffer.clear();
                            byteBuffer.put(("IMAGE " + (faceObjects.isIncludeFaceNumbers() ? i + " " : "") + imageSize + " " + face + "\n").getBytes(charset));
                            byteBuffer.flip();
                            outChannel.write(byteBuffer);
                            inChannel.transferTo(0L, imageSize, outChannel);
                        } finally {
                            fin.close();
                        }
                    } catch (final FileNotFoundException ignored) {
                        ACTION_BUILDER.showMessageDialog(progress.getParentComponent(), "archCollectErrorFileNotFound", path);
                        return;
                    } catch (final IOException e) {
                        ACTION_BUILDER.showMessageDialog(progress.getParentComponent(), "archCollectErrorIOException", path, e);
                        return;
                    }
                    if (i++ % 100 == 0) {
                        progress.setValue(i);
                    }
                }
                progress.setValue(faceObjects.size());
            } finally {
                outChannel.close();
            }
        } finally {
            fos.close();
        }
    }
```

## 85966eff-034

**A**

```java
private void checkRoundtrip(byte[] content) throws Exception {
        InputStream in = new ByteArrayInputStream(content);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        CodecUtil.encodeQuotedPrintableBinary(in, out);
        in = new QuotedPrintableInputStream(new ByteArrayInputStream(out.toByteArray()));
        out = new ByteArrayOutputStream();
        IOUtils.copy(in, out);
        assertEquals(content, out.toByteArray());
    }
```

**B**

```java
public int sftp_connect(HttpServletRequest request) {
        Map<String, Object> setting = (Map<String, Object>) request.getAttribute("globalSetting");
        int ftpssl = Common.intval(setting.get("ftpssl") + "");
        String ftphost = setting.get("ftphost") + "";
        int ftpport = Common.intval(setting.get("ftpport") + "");
        String ftpuser = setting.get("ftpuser") + "";
        String ftppassword = setting.get("ftppassword") + "";
        int ftppasv = Common.intval(setting.get("ftppasv") + "");
        String ftpdir = setting.get("ftpdir") + "";
        int ftptimeout = Common.intval(setting.get("ftptimeout") + "");
        if (ftpssl > 0) {
            try {
                fc = new FTPSClient();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
                return JC_FTPClientException;
            }
        } else {
            fc = new FTPClient();
        }
        try {
            fc.setConnectTimeout(20000);
            InetAddress inetAddress = InetAddress.getByName(ftphost);
            fc.connect(inetAddress, ftpport);
            if (fc.login(ftpuser, ftppassword)) {
                if (ftppasv > 0) {
                    fc.pasv();
                }
                if (ftptimeout > 0) {
                    fc.setDataTimeout(ftptimeout);
                }
                if (fc.changeWorkingDirectory(ftpdir)) {
                    return JC_FTPClientYES;
                } else {
                    FileHelper.writeLog(request, "FTP", "CHDIR " + ftpdir + " ERROR.");
                    try {
                        fc.disconnect();
                        fc = null;
                    } catch (Exception e1) {
                    }
                    return JC_FTPClientNO;
                }
            } else {
                FileHelper.writeLog(request, "FTP", "530 NOT LOGGED IN.");
                try {
                    fc.disconnect();
                    fc = null;
                } catch (Exception e1) {
                }
                return JC_FTPClientNO;
            }
        } catch (Exception e) {
            FileHelper.writeLog(request, "FTP", "COULDN'T CONNECT TO " + ftphost + ":" + ftpport + ".");
            e.printStackTrace();
            if (fc != null) {
                try {
                    fc.disconnect();
                    fc = null;
                } catch (Exception e1) {
                }
            }
            return JC_FTPClientException;
        }
    }
```

## 85966eff-035

**A**

```java
public String doAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - start");
        }
        t_information_EditMap editMap = new t_information_EditMap();
        try {
            t_information_Form vo = null;
            vo = (t_information_Form) form;
            vo.setCompany(vo.getCounty());
            if ("����".equals(vo.getInfo_type())) {
                vo.setInfo_level(null);
                vo.setAlert_level(null);
            }
            String str_postFIX = "";
            int i_p = 0;
            editMap.add(vo);
            try {
                logger.info("���͹�˾�鱨��");
                String[] mobiles = request.getParameterValues("mobiles");
                vo.setMobiles(mobiles);
                SMSService.inforAlert(vo);
            } catch (Exception e) {
                logger.error("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)", e);
            }
            String filename = vo.getFile().getFileName();
            if (null != filename && !"".equals(filename)) {
                FormFile file = vo.getFile();
                String realpath = getServlet().getServletContext().getRealPath("/");
                realpath = realpath.replaceAll("\\\\", "/");
                String inforId = vo.getId();
                String rootFilePath = getServlet().getServletContext().getRealPath(request.getContextPath());
                rootFilePath = (new StringBuilder(String.valueOf(rootFilePath))).append(UploadFileOne.strPath).toString();
                String strAppend = (new StringBuilder(String.valueOf(UUIDGenerator.nextHex()))).append(UploadFileOne.getFileType(file)).toString();
                if (file.getFileSize() != 0) {
                    file.getInputStream();
                    String name = file.getFileName();
                    i_p = file.getFileName().lastIndexOf(".");
                    str_postFIX = file.getFileName().substring(i_p, file.getFileName().length());
                    String fullPath = realpath + "attach/" + strAppend + str_postFIX;
                    t_attach attach = new t_attach();
                    attach.setAttach_fullname(fullPath);
                    attach.setAttach_name(name);
                    attach.setInfor_id(Integer.parseInt(inforId));
                    attach.setInsert_day(new Date());
                    attach.setUpdate_day(new Date());
                    t_attach_EditMap attachEdit = new t_attach_EditMap();
                    attachEdit.add(attach);
                    File sysfile = new File(fullPath);
                    if (!sysfile.exists()) {
                        sysfile.createNewFile();
                    }
                    java.io.OutputStream out = new FileOutputStream(sysfile);
                    org.apache.commons.io.IOUtils.copy(file.getInputStream(), out);
                    out.close();
                }
            }
        } catch (HibernateException e) {
            logger.error("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)", e);
            ActionErrors errors = new ActionErrors();
            errors.add("org.apache.struts.action.GLOBAL_ERROR", new ActionError("error.database.save", e.toString()));
            saveErrors(request, errors);
            e.printStackTrace();
            request.setAttribute("t_information_Form", form);
            if (logger.isDebugEnabled()) {
                logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - end");
            }
            return "addpage";
        }
        if (logger.isDebugEnabled()) {
            logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - end");
        }
        return "aftersave";
    }
```

**B**

```java
public static ArrayList<AnalyzeDefinition> read(ArrayList<String> supportedCommands, File analyzeCommands, String programAnalyzeCommands) throws ErrorMessage {
        if (analyzeCommands != null) {
            try {
                Reader fileReader = new FileReader(analyzeCommands);
                BufferedReader reader = new BufferedReader(fileReader);
                return readConfig(reader, analyzeCommands.getName(), null);
            } catch (FileNotFoundException e) {
                throw new ErrorMessage("File \"" + analyzeCommands + "\" not found");
            }
        } else if (programAnalyzeCommands != null) {
            Reader stringReader = new StringReader(programAnalyzeCommands);
            BufferedReader reader = new BufferedReader(stringReader);
            return readConfig(reader, "program response to gogui-analyze_commands", null);
        } else {
            String resource = "net/sf/gogui/gui/analyze-commands";
            URL url = ClassLoader.getSystemClassLoader().getResource(resource);
            if (url == null) return new ArrayList<AnalyzeDefinition>();
            try {
                InputStream inputStream = url.openStream();
                Reader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader reader = new BufferedReader(inputStreamReader);
                return readConfig(reader, "builtin default commands", supportedCommands);
            } catch (IOException e) {
                throw new ErrorMessage(e.getMessage());
            }
        }
    }
```

## 85966eff-036

**A**

```java
private void sendFile(File file, HttpServletResponse response) throws IOException {
        response.setContentLength((int) file.length());
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            IOUtils.copy(inputStream, response.getOutputStream());
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
    }
```

**B**

```java
private JeeObserverServerContext(JeeObserverServerContextProperties properties) throws DatabaseException, ServerException {
        super();
        try {
            final MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(("JE" + System.currentTimeMillis()).getBytes());
            final BigInteger hash = new BigInteger(1, md5.digest());
            this.sessionId = hash.toString(16).toUpperCase();
        } catch (final Exception e) {
            this.sessionId = "JE" + System.currentTimeMillis();
            JeeObserverServerContext.logger.log(Level.WARNING, "JeeObserver Server session ID MD5 error: {0}", this.sessionId);
            JeeObserverServerContext.logger.log(Level.FINEST, e.getMessage(), e);
        }
        try {
            @SuppressWarnings("unchecked") final Class<DatabaseHandler> databaseHandlerClass = (Class<DatabaseHandler>) Class.forName(properties.getDatabaseHandler());
            final Constructor<DatabaseHandler> handlerConstructor = databaseHandlerClass.getConstructor(new Class<?>[] { String.class, String.class, String.class, String.class, String.class, Integer.class });
            this.databaseHandler = handlerConstructor.newInstance(new Object[] { properties.getDatabaseDriver(), properties.getDatabaseUrl(), properties.getDatabaseUser(), properties.getDatabasePassword(), properties.getDatabaseSchema(), new Integer(properties.getDatabaseConnectionPoolSize()) });
        } catch (final Exception e) {
            throw new ServerException("Database handler loading exception.", e);
        }
        this.databaseHandlerTimer = new Timer(JeeObserverServerContext.DATABASE_HANDLER_TASK_NAME, true);
        this.server = new JeeObserverServer(properties.getServerPort());
        this.enabled = true;
        this.properties = properties;
        this.startTimestamp = new Date();
        try {
            this.ip = InetAddress.getLocalHost().getHostAddress();
        } catch (final UnknownHostException e) {
            JeeObserverServerContext.logger.log(Level.SEVERE, e.getMessage(), e);
        }
        this.operatingSystemName = System.getProperty("os.name");
        this.operatingSystemVersion = System.getProperty("os.version");
        this.operatingSystemArchitecture = System.getProperty("os.arch");
        this.javaVersion = System.getProperty("java.version");
        this.javaVendor = System.getProperty("java.vendor");
    }
```

## 85966eff-037

**A**

```java
public void putFile(CompoundName file, FileInputStream fileInput) throws IOException {
        File fullDir = new File(REMOTE_BASE_DIR.getCanonicalPath());
        for (int i = 0; i < file.size() - 1; i++) fullDir = new File(fullDir, file.get(i));
        fullDir.mkdirs();
        File outputFile = new File(fullDir, file.get(file.size() - 1));
        FileOutputStream outStream = new FileOutputStream(outputFile);
        for (int byteIn = fileInput.read(); byteIn != -1; byteIn = fileInput.read()) outStream.write(byteIn);
        fileInput.close();
        outStream.close();
    }
```

**B**

```java
public HashCash(String cash) throws NoSuchAlgorithmException {
        myToken = cash;
        String[] parts = cash.split(":");
        myVersion = Integer.parseInt(parts[0]);
        if (myVersion < 0 || myVersion > 1) throw new IllegalArgumentException("Only supported versions are 0 and 1");
        if ((myVersion == 0 && parts.length != 6) || (myVersion == 1 && parts.length != 7)) throw new IllegalArgumentException("Improperly formed HashCash");
        try {
            int index = 1;
            if (myVersion == 1) myValue = Integer.parseInt(parts[index++]); else myValue = 0;
            SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormatString);
            Calendar tempCal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            tempCal.setTime(dateFormat.parse(parts[index++]));
            myResource = parts[index++];
            myExtensions = deserializeExtensions(parts[index++]);
            MessageDigest md = MessageDigest.getInstance("SHA1");
            md.update(cash.getBytes());
            byte[] tempBytes = md.digest();
            int tempValue = numberOfLeadingZeros(tempBytes);
            if (myVersion == 0) myValue = tempValue; else if (myVersion == 1) myValue = (tempValue > myValue ? myValue : tempValue);
        } catch (java.text.ParseException ex) {
            throw new IllegalArgumentException("Improperly formed HashCash", ex);
        }
    }
```

## 85966eff-038

**A**

```java
private void copyFile(File sourceFile, File targetFile) {
        beNice();
        dispatchEvent(SynchronizationEventType.FileCopy, sourceFile, targetFile);
        File temporaryFile = new File(targetFile.getPath().concat(".jnstemp"));
        while (temporaryFile.exists()) {
            try {
                beNice();
                temporaryFile.delete();
                beNice();
            } catch (Exception ex) {
            }
        }
        try {
            if (targetFile.exists()) {
                targetFile.delete();
            }
            FileInputStream fis = new FileInputStream(sourceFile);
            FileOutputStream fos = new FileOutputStream(temporaryFile);
            byte[] buffer = new byte[204800];
            int readBytes = 0;
            int counter = 0;
            while ((readBytes = fis.read(buffer)) != -1) {
                counter++;
                updateStatus("... processing fragment " + String.valueOf(counter));
                fos.write(buffer, 0, readBytes);
            }
            fis.close();
            fos.close();
            temporaryFile.renameTo(targetFile);
            temporaryFile.setLastModified(sourceFile.lastModified());
            targetFile.setLastModified(sourceFile.lastModified());
        } catch (IOException e) {
            Exception dispatchedException = new Exception("ERROR: Copy File( " + sourceFile.getPath() + ", " + targetFile.getPath() + " )");
            dispatchEvent(dispatchedException, sourceFile, targetFile);
        }
        dispatchEvent(SynchronizationEventType.FileCopyDone, sourceFile, targetFile);
    }
```

**B**

```java
private void serveCGI(TinyCGI script) throws IOException, TinyWebThreadException {
            parseHTTPHeaders();
            OutputStream cgiOut = null;
            File tempFile = null;
            try {
                if (script == null) sendError(500, "Internal Error", "Couldn't load script.");
                if (script instanceof TinyCGIHighVolume) {
                    tempFile = File.createTempFile("cgi", null);
                    cgiOut = new FileOutputStream(tempFile);
                } else {
                    cgiOut = new ByteArrayOutputStream();
                }
                script.service(inputStream, cgiOut, env);
            } catch (Exception cgie) {
                this.exceptionEncountered = cgie;
                if (tempFile != null) tempFile.delete();
                if (clientSocket == null) {
                    return;
                } else if (cgie instanceof TinyCGIException) {
                    TinyCGIException tce = (TinyCGIException) cgie;
                    sendError(tce.getStatus(), tce.getTitle(), tce.getText(), tce.getOtherHeaders());
                } else {
                    StringWriter w = new StringWriter();
                    cgie.printStackTrace(new PrintWriter(w));
                    sendError(500, "CGI Error", "Error running script: " + "<PRE>" + w.toString() + "</PRE>");
                }
            } finally {
                if (script != null) doneWithScript(script);
            }
            InputStream cgiResults = null;
            long totalSize = 0;
            if (tempFile == null) {
                byte[] results = ((ByteArrayOutputStream) cgiOut).toByteArray();
                totalSize = results.length;
                cgiResults = new ByteArrayInputStream(results);
            } else {
                cgiOut.close();
                totalSize = tempFile.length();
                cgiResults = new FileInputStream(tempFile);
            }
            String contentType = null, statusString = "OK", line, header;
            StringBuffer otherHeaders = new StringBuffer();
            StringBuffer text = new StringBuffer();
            int status = 200;
            int headerLength = 0;
            while (true) {
                line = readLine(cgiResults, true);
                headerLength += line.length();
                if (line.charAt(0) == '\r' || line.charAt(0) == '\n') break;
                header = parseHeader(line, text);
                if (header.toUpperCase().equals("STATUS")) {
                    statusString = text.toString();
                    status = Integer.parseInt(statusString.substring(0, 3));
                    statusString = statusString.substring(4);
                } else if (header.toUpperCase().equals("CONTENT-TYPE")) contentType = text.toString(); else {
                    if (header.toUpperCase().equals("LOCATION")) status = 302;
                    otherHeaders.append(header).append(": ").append(text.toString()).append(CRLF);
                }
            }
            sendHeaders(status, statusString, contentType, totalSize - headerLength, -1, otherHeaders.toString());
            byte[] buf = new byte[2048];
            int bytesRead;
            while ((bytesRead = cgiResults.read(buf)) != -1) outputStream.write(buf, 0, bytesRead);
            outputStream.flush();
            try {
                cgiResults.close();
                if (tempFile != null) tempFile.delete();
            } catch (IOException ioe) {
            }
        }
```

## 85966eff-039

**A**

```java
public static void copyFile(File src, File dest, boolean preserveFileDate) throws IOException {
        if (src.exists() && src.isDirectory()) {
            throw new IOException("source file exists but is a directory");
        }
        if (dest.exists() && dest.isDirectory()) {
            dest = new File(dest, src.getName());
        }
        if (!dest.exists()) {
            dest.createNewFile();
        }
        FileChannel srcCH = null;
        FileChannel destCH = null;
        try {
            srcCH = new FileInputStream(src).getChannel();
            destCH = new FileOutputStream(dest).getChannel();
            destCH.transferFrom(srcCH, 0, srcCH.size());
        } finally {
            closeQuietly(srcCH);
            closeQuietly(destCH);
        }
        if (src.length() != dest.length()) {
            throw new IOException("Failed to copy full contents from '" + src + "' to '" + dest + "'");
        }
        if (preserveFileDate) {
            dest.setLastModified(src.lastModified());
        }
    }
```

**B**

```java
public IContentExtension[] getContentExtensions(String locale) {
        if (RemoteHelp.isEnabled()) {
            List contributions = new ArrayList();
            PreferenceFileHandler handler = new PreferenceFileHandler();
            String isEnabled[] = handler.isEnabled();
            for (int ic = 0; ic < handler.getTotalRemoteInfocenters(); ic++) {
                if (isEnabled[ic].equalsIgnoreCase("true")) {
                    InputStream in = null;
                    try {
                        URL url = RemoteHelp.getURL(ic, PATH_EXTENSIONS);
                        in = url.openStream();
                        if (reader == null) {
                            reader = new DocumentReader();
                        }
                        UAElement element = reader.read(in);
                        IContentExtension[] children = (IContentExtension[]) element.getChildren(IContentExtension.class);
                        for (int contrib = 0; contrib < children.length; contrib++) {
                            contributions.add(children[contrib]);
                        }
                    } catch (IOException e) {
                        String msg = "I/O error while trying to contact the remote help server";
                        HelpBasePlugin.logError(msg, e);
                    } catch (Throwable t) {
                        String msg = "Internal error while reading topic extensions from remote server";
                        HelpBasePlugin.logError(msg, t);
                    } finally {
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException e) {
                            }
                        }
                    }
                }
            }
            return (IContentExtension[]) contributions.toArray(new IContentExtension[contributions.size()]);
        }
        return new IContentExtension[0];
    }
```

## 85966eff-040

**A**

```java
PackageFileImpl(PackageDirectoryImpl dir, String name, InputStream data) throws IOException {
        this.dir = dir;
        this.name = name;
        this.updates = dir.getUpdates();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        IOUtils.copy(data, stream);
        updates.setNewData(getFullName(), stream.toByteArray());
        stream.close();
    }
```

**B**

```java
public static String postRequest(String url, String content) throws IOException {
        InputStream is = null;
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        String result = null;
        try {
            Object obj = openConnection(url, content, "POST", "text/xml");
            if (obj instanceof InputStream) {
                is = (InputStream) obj;
            } else {
                return "Cannot open a connection with " + url + " : " + obj.toString();
            }
            int c = is.read();
            while (c != -1) {
                buf.write(c);
                c = is.read();
            }
            result = new String(buf.toByteArray());
        } finally {
            if (is != null) {
                is.close();
            }
            if (buf != null) {
                buf.close();
            }
        }
        return result;
    }
```

## 85966eff-041

**A**

```java
public void getZipFiles(String filename) {
        try {
            String destinationname = "c:\\mods\\peu\\";
            byte[] buf = new byte[1024];
            ZipInputStream zipinputstream = null;
            ZipEntry zipentry;
            zipinputstream = new ZipInputStream(new FileInputStream(filename));
            zipentry = zipinputstream.getNextEntry();
            while (zipentry != null) {
                String entryName = zipentry.getName();
                System.out.println("entryname " + entryName);
                int n;
                FileOutputStream fileoutputstream;
                File newFile = new File(entryName);
                String directory = newFile.getParent();
                if (directory == null) {
                    if (newFile.isDirectory()) break;
                }
                fileoutputstream = new FileOutputStream(destinationname + entryName);
                while ((n = zipinputstream.read(buf, 0, 1024)) > -1) fileoutputstream.write(buf, 0, n);
                fileoutputstream.close();
                zipinputstream.closeEntry();
                zipentry = zipinputstream.getNextEntry();
            }
            zipinputstream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
```

**B**

```java
private Element getXmlFromGeoNetwork(String urlIn, Session userSession) throws FailedActionException {
        Element results = null;
        try {
            URL url = new URL(urlIn);
            URLConnection conn = url.openConnection();
            conn.setConnectTimeout(1000);
            String cookie = (String) userSession.getAttribute("usercookie.object");
            if (cookie != null) conn.setRequestProperty("Cookie", cookie);
            BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
            try {
                results = Xml.loadStream(in);
            } finally {
                in.close();
            }
        } catch (Exception e) {
            throw new FailedActionException(FailedActionReason.SYSTEM_ERROR);
        }
        return results;
    }
```

## 85966eff-042

**A**

```java
public static String md5Encode16(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes("utf-8"));
            byte b[] = md.digest();
            int i;
            StringBuilder buf = new StringBuilder("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) i += 256;
                if (i < 16) buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString().substring(8, 24);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e);
        }
    }
```

**B**

```java
public static void copy(File from_file, File to_file) throws IOException {
        if (!from_file.exists()) {
            throw new IOException("FileCopy: no such source file: " + from_file.getPath());
        }
        if (!from_file.isFile()) {
            throw new IOException("FileCopy: can't copy directory: " + from_file.getPath());
        }
        if (!from_file.canRead()) {
            throw new IOException("FileCopy: source file is unreadable: " + from_file.getPath());
        }
        if (to_file.isDirectory()) {
            to_file = new File(to_file, from_file.getName());
        }
        if (to_file.exists()) {
            if (!to_file.canWrite()) {
                throw new IOException("FileCopy: destination file is unwriteable: " + to_file.getPath());
            }
            int choice = JOptionPane.showConfirmDialog(null, "Overwrite existing file " + to_file.getPath(), "File Exists", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (choice != JOptionPane.YES_OPTION) {
                throw new IOException("FileCopy: existing file was not overwritten.");
            }
        } else {
            String parent = to_file.getParent();
            if (parent == null) {
                parent = Globals.getDefaultPath();
            }
            File dir = new File(parent);
            if (!dir.exists()) {
                throw new IOException("FileCopy: destination directory doesn't exist: " + parent);
            }
            if (dir.isFile()) {
                throw new IOException("FileCopy: destination is not a directory: " + parent);
            }
            if (!dir.canWrite()) {
                throw new IOException("FileCopy: destination directory is unwriteable: " + parent);
            }
        }
        FileInputStream from = null;
        FileOutputStream to = null;
        try {
            from = new FileInputStream(from_file);
            to = new FileOutputStream(to_file);
            byte[] buffer = new byte[4096];
            int bytes_read;
            while ((bytes_read = from.read(buffer)) != -1) {
                to.write(buffer, 0, bytes_read);
            }
        } finally {
            if (from != null) {
                try {
                    from.close();
                } catch (IOException e) {
                }
            }
            if (to != null) {
                try {
                    to.close();
                } catch (IOException e) {
                }
            }
        }
    }
```

## 85966eff-043

**A**

```java
public ChatClient registerPlayer(int playerId, String playerLogin) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.reset();
        md.update(playerLogin.getBytes("UTF-8"), 0, playerLogin.length());
        byte[] accountToken = md.digest();
        byte[] token = generateToken(accountToken);
        ChatClient chatClient = new ChatClient(playerId, token);
        players.put(playerId, chatClient);
        return chatClient;
    }
```

**B**

```java
protected URLConnection openConnection(URL url) throws IOException {
        URLStreamHandler handler = factory.findAuthorizedURLStreamHandler(protocol);
        if (handler != null) {
            try {
                return (URLConnection) openConnectionMethod.invoke(handler, new Object[] { url });
            } catch (Exception e) {
                factory.adaptor.getFrameworkLog().log(new FrameworkLogEntry(MultiplexingURLStreamHandler.class.getName(), "openConnection", FrameworkLogEntry.ERROR, e, null));
                throw new RuntimeException(e.getMessage());
            }
        }
        throw new MalformedURLException();
    }
```

## 85966eff-044

**A**

```java
public boolean refresh() {
        try {
            synchronized (text) {
                stream = (new URL(url)).openStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                String line;
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
                text = sb.toString();
            }
            price = 0;
            date = null;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (stream != null) try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
```

**B**

```java
protected String getCitations(String ticket, String query) throws IOException {
        String urlQuery;
        try {
            urlQuery = "http://www.jstor.org/search/BasicResults?hp=" + MAX_CITATIONS + "&si=1&gw=jtx&jtxsi=1&jcpsi=1&artsi=1&Query=" + URLEncoder.encode(query, "UTF-8") + "&wc=on&citationAction=saveAll";
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        URL url = new URL(urlQuery);
        URLConnection conn = url.openConnection();
        conn.setRequestProperty("Cookie", ticket);
        return getCookie(COOKIE_CITATIONS, conn);
    }
```

## 85966eff-045

**A**

```java
public String getCipherString(String source) throws CadenaNoCifradaException {
        String encryptedSource = null;
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-1");
            byte[] sha1hash = new byte[40];
            md.update(source.getBytes(encoding), 0, source.length());
            sha1hash = md.digest();
            encryptedSource = convertToHex(sha1hash);
        } catch (Exception e) {
            throw new CadenaNoCifradaException(e);
        }
        return encryptedSource;
    }
```

**B**

```java
public static void testAutoIncrement() {
        final int count = 3;
        final Object lock = new Object();
        for (int i = 0; i < count; i++) {
            new Thread(new Runnable() {

                @Override
                public void run() {
                    while (true) {
                        StringBuilder buffer = new StringBuilder(128);
                        buffer.append("insert into DOMAIN (                         ").append(LS);
                        buffer.append("    DOMAIN_ID, TOP_DOMAIN_ID, DOMAIN_HREF,   ").append(LS);
                        buffer.append("    DOMAIN_RANK, DOMAIN_TYPE, DOMAIN_STATUS, ").append(LS);
                        buffer.append("    DOMAIN_ICO_CREATED, DOMAIN_CDATE         ").append(LS);
                        buffer.append(") values (                   ").append(LS);
                        buffer.append("    null ,null, ?,").append(LS);
                        buffer.append("    1, 2, 1,                 ").append(LS);
                        buffer.append("    0, now()                 ").append(LS);
                        buffer.append(")                            ").append(LS);
                        String sqlInsert = buffer.toString();
                        boolean isAutoCommit = false;
                        int i = 0;
                        Connection conn = null;
                        PreparedStatement pstmt = null;
                        ResultSet rs = null;
                        try {
                            conn = ConnHelper.getConnection();
                            conn.setAutoCommit(isAutoCommit);
                            pstmt = conn.prepareStatement(sqlInsert);
                            for (i = 0; i < 10; i++) {
                                String lock = "" + ((int) (Math.random() * 100000000)) % 100;
                                pstmt.setString(1, lock);
                                pstmt.executeUpdate();
                            }
                            if (!isAutoCommit) conn.commit();
                            rs = pstmt.executeQuery("select max(DOMAIN_ID) from DOMAIN");
                            if (rs.next()) {
                                String str = System.currentTimeMillis() + " " + rs.getLong(1);
                            }
                        } catch (Exception e) {
                            try {
                                if (!isAutoCommit) conn.rollback();
                            } catch (SQLException ex) {
                                ex.printStackTrace(System.out);
                            }
                            String msg = System.currentTimeMillis() + " " + Thread.currentThread().getName() + " - " + i + " " + e.getMessage() + LS;
                            FileIO.writeToFile("D:/DEAD_LOCK.txt", msg, true, "GBK");
                        } finally {
                            ConnHelper.close(conn, pstmt, rs);
                        }
                    }
                }
            }).start();
        }
    }
```

## 85966eff-046

**A**

```java
public static void copyFile(String source, String dest) throws IOException {
        FileChannel in = null, out = null;
        try {
            in = new FileInputStream(new File(source)).getChannel();
            out = new FileOutputStream(new File(dest)).getChannel();
            in.transferTo(0, in.size(), out);
        } finally {
            if (in != null) in.close();
            if (out != null) out.close();
        }
    }
```

**B**

```java
public static String move_files(String sessionid, String keys, String absolutePathForTheDestinationTag) {
        String resultJsonString = "some problem existed inside the create_new_tag() function if you see this string";
        try {
            Log.d("current running function name:", "move_files");
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("https://mt0-app.cloud.cm/rpc/json");
            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
            nameValuePairs.add(new BasicNameValuePair("c", "Storage"));
            nameValuePairs.add(new BasicNameValuePair("m", "move_file"));
            nameValuePairs.add(new BasicNameValuePair("absolute_new_parent_tag", absolutePathForTheDestinationTag));
            nameValuePairs.add(new BasicNameValuePair("keys", keys));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            httppost.setHeader("Cookie", "PHPSESSID=" + sessionid);
            HttpResponse response = httpclient.execute(httppost);
            resultJsonString = EntityUtils.toString(response.getEntity());
            Log.d("jsonStringReturned:", resultJsonString);
            return resultJsonString;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultJsonString;
    }
```

## 85966eff-047

**A**

```java
public void run() {
            try {
                File outDir = new File(outDirTextField.getText());
                if (!outDir.exists()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "The chosen directory does not exist!", "Directory Not Found Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                if (!outDir.isDirectory()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "The chosen file is not a directory!", "Not a Directory Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                if (!outDir.canWrite()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "Cannot write to the chosen directory!", "Directory Not Writeable Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                File archiveDir = new File("foo.bar").getAbsoluteFile().getParentFile();
                URL baseUrl = UnpackWizard.class.getClassLoader().getResource(UnpackWizard.class.getName().replaceAll("\\.", "/") + ".class");
                if (baseUrl.getProtocol().equals("jar")) {
                    String jarPath = baseUrl.getPath();
                    jarPath = jarPath.substring(0, jarPath.indexOf('!'));
                    if (jarPath.startsWith("file:")) {
                        try {
                            archiveDir = new File(new URI(jarPath)).getAbsoluteFile().getParentFile();
                        } catch (URISyntaxException e1) {
                            e1.printStackTrace(System.err);
                        }
                    }
                }
                SortedMap<Integer, String> inputFileNames = new TreeMap<Integer, String>();
                for (Entry<Object, Object> anEntry : indexProperties.entrySet()) {
                    String key = anEntry.getKey().toString();
                    if (key.startsWith("archive file ")) {
                        inputFileNames.put(Integer.parseInt(key.substring("archive file ".length())), anEntry.getValue().toString());
                    }
                }
                byte[] buff = new byte[64 * 1024];
                try {
                    long bytesToWrite = 0;
                    long bytesReported = 0;
                    long bytesWritten = 0;
                    for (String aFileName : inputFileNames.values()) {
                        File aFile = new File(archiveDir, aFileName);
                        if (aFile.exists()) {
                            if (aFile.isFile()) {
                                bytesToWrite += aFile.length();
                            } else {
                                final File wrongFile = aFile;
                                SwingUtilities.invokeLater(new Runnable() {

                                    public void run() {
                                        JOptionPane.showMessageDialog(UnpackWizard.this, "File \"" + wrongFile.getAbsolutePath() + "\" is not a standard file!", "Non Standard File Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                });
                                return;
                            }
                        } else {
                            final File wrongFile = aFile;
                            SwingUtilities.invokeLater(new Runnable() {

                                public void run() {
                                    JOptionPane.showMessageDialog(UnpackWizard.this, "File \"" + wrongFile.getAbsolutePath() + "\" does not exist!", "File Not Found Error", JOptionPane.ERROR_MESSAGE);
                                }
                            });
                            return;
                        }
                    }
                    MultiFileInputStream mfis = new MultiFileInputStream(archiveDir, inputFileNames.values().toArray(new String[inputFileNames.size()]));
                    TarArchiveInputStream tis = new TarArchiveInputStream(new BufferedInputStream(mfis));
                    TarArchiveEntry tarEntry = tis.getNextTarEntry();
                    while (tarEntry != null) {
                        File outFile = new File(outDir.getAbsolutePath() + "/" + tarEntry.getName());
                        if (outFile.exists()) {
                            final File wrongFile = outFile;
                            SwingUtilities.invokeLater(new Runnable() {

                                public void run() {
                                    JOptionPane.showMessageDialog(UnpackWizard.this, "Was about to write out file \"" + wrongFile.getAbsolutePath() + "\" but it already " + "exists.\nPlease [re]move existing files out of the way " + "and try again.", "File Not Found Error", JOptionPane.ERROR_MESSAGE);
                                }
                            });
                            return;
                        }
                        if (tarEntry.isDirectory()) {
                            outFile.getAbsoluteFile().mkdirs();
                        } else {
                            outFile.getAbsoluteFile().getParentFile().mkdirs();
                            OutputStream os = new BufferedOutputStream(new FileOutputStream(outFile));
                            int len = tis.read(buff, 0, buff.length);
                            while (len != -1) {
                                os.write(buff, 0, len);
                                bytesWritten += len;
                                if (bytesWritten - bytesReported > (10 * 1024 * 1024)) {
                                    bytesReported = bytesWritten;
                                    final int progress = (int) (bytesReported * 100 / bytesToWrite);
                                    SwingUtilities.invokeLater(new Runnable() {

                                        @Override
                                        public void run() {
                                            progressBar.setValue(progress);
                                        }
                                    });
                                }
                                len = tis.read(buff, 0, buff.length);
                            }
                            os.close();
                        }
                        tarEntry = tis.getNextTarEntry();
                    }
                    long expectedCrc = 0;
                    try {
                        expectedCrc = Long.parseLong(indexProperties.getProperty("CRC32", "0"));
                    } catch (NumberFormatException e) {
                        System.err.println("Error while obtaining the expected CRC");
                        e.printStackTrace(System.err);
                    }
                    if (mfis.getCRC() == expectedCrc) {
                        SwingUtilities.invokeLater(new Runnable() {

                            @Override
                            public void run() {
                                progressBar.setValue(0);
                                JOptionPane.showMessageDialog(UnpackWizard.this, "Extraction completed successfully!", "Done!", JOptionPane.INFORMATION_MESSAGE);
                            }
                        });
                        return;
                    } else {
                        System.err.println("CRC Error: was expecting " + expectedCrc + " but got " + mfis.getCRC());
                        SwingUtilities.invokeLater(new Runnable() {

                            public void run() {
                                progressBar.setValue(0);
                                JOptionPane.showMessageDialog(UnpackWizard.this, "CRC Error: the data extracted does not have the expected CRC!\n" + "You should probably delete the extracted files, as they are " + "likely to be invalid.", "CRC Error", JOptionPane.ERROR_MESSAGE);
                            }
                        });
                        return;
                    }
                } catch (final IOException e) {
                    e.printStackTrace(System.err);
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            progressBar.setValue(0);
                            JOptionPane.showMessageDialog(UnpackWizard.this, "Input/Output Error: " + e.getLocalizedMessage(), "Input/Output Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
            } finally {
                SwingUtilities.invokeLater(new Runnable() {

                    public void run() {
                        progressBar.setValue(0);
                        setEnabled(true);
                    }
                });
            }
        }
```

**B**

```java
public static void gunzip() throws Exception {
        System.out.println("gunzip()");
        GZIPInputStream zipin = new GZIPInputStream(new FileInputStream("/zip/myzip.gz"));
        byte buffer[] = new byte[BLOCKSIZE];
        FileOutputStream out = new FileOutputStream("/zip/covers");
        for (int length; (length = zipin.read(buffer, 0, BLOCKSIZE)) != -1; ) out.write(buffer, 0, length);
        out.close();
        zipin.close();
    }
```

## 85966eff-048

**A**

```java
public static Checksum checksum(File file, Checksum checksum) throws IOException {
        if (file.isDirectory()) {
            throw new IllegalArgumentException("Checksums can't be computed on directories");
        }
        InputStream in = null;
        try {
            in = new CheckedInputStream(new FileInputStream(file), checksum);
            IOUtils.copy(in, new OutputStream() {

                @Override
                public void write(byte[] b, int off, int len) {
                }

                @Override
                public void write(int b) {
                }

                @Override
                public void write(byte[] b) throws IOException {
                }
            });
        } finally {
            IOUtils.closeQuietly(in);
        }
        return checksum;
    }
```

**B**

```java
public void parseFile(String dataurl, URL documentBase) {
        DataInputStream in;
        if (_debug > 2) System.out.println("PlotBox: parseFile(" + dataurl + " " + documentBase + ") _dataurl = " + _dataurl + " " + _documentBase);
        if (dataurl == null || dataurl.length() == 0) {
            in = new DataInputStream(System.in);
        } else {
            try {
                URL url;
                if (documentBase == null && _documentBase != null) {
                    documentBase = _documentBase;
                }
                if (documentBase == null) {
                    url = new URL(_dataurl);
                } else {
                    try {
                        url = new URL(documentBase, dataurl);
                    } catch (NullPointerException e) {
                        url = new URL(_dataurl);
                    }
                }
                in = new DataInputStream(url.openStream());
            } catch (MalformedURLException e) {
                try {
                    in = new DataInputStream(new FileInputStream(dataurl));
                } catch (FileNotFoundException me) {
                    _errorMsg = new String[2];
                    _errorMsg[0] = "File not found: " + dataurl;
                    _errorMsg[1] = me.getMessage();
                    return;
                } catch (SecurityException me) {
                    _errorMsg = new String[2];
                    _errorMsg[0] = "Security Exception: " + dataurl;
                    _errorMsg[1] = me.getMessage();
                    return;
                }
            } catch (IOException ioe) {
                _errorMsg = new String[2];
                _errorMsg[0] = "Failure opening URL: " + dataurl;
                _errorMsg[1] = ioe.getMessage();
                return;
            }
        }
        _newFile();
        try {
            if (_binary) {
                _parseBinaryStream(in);
            } else {
                String line = in.readLine();
                while (line != null) {
                    _parseLine(line);
                    line = in.readLine();
                }
            }
        } catch (MalformedURLException e) {
            _errorMsg = new String[2];
            _errorMsg[0] = "Malformed URL: " + dataurl;
            _errorMsg[1] = e.getMessage();
            return;
        } catch (IOException e) {
            _errorMsg = new String[2];
            _errorMsg[0] = "Failure reading data: " + dataurl;
            _errorMsg[1] = e.getMessage();
        } catch (PlotDataException e) {
            _errorMsg = new String[2];
            _errorMsg[0] = "Incorrectly formatted plot data in " + dataurl;
            _errorMsg[1] = e.getMessage();
        } finally {
            try {
                in.close();
            } catch (IOException me) {
            }
        }
    }
```

## 85966eff-049

**A**

```java
public static File copyFile(String path) {
        File src = new File(path);
        File dest = new File(src.getName());
        try {
            if (!dest.exists()) {
                dest.createNewFile();
            }
            FileChannel source = new FileInputStream(src).getChannel();
            FileChannel destination = new FileOutputStream(dest).getChannel();
            destination.transferFrom(source, 0, source.size());
            source.close();
            destination.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }
```

**B**

```java
private void load() throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        try {
            conn = FidoDataSource.getConnection();
            conn.setAutoCommit(false);
            stmt = conn.createStatement();
            ClearData.clearTables(stmt);
            stmt.executeUpdate("insert into Objects (ObjectId, Description) values (100, 'Person')");
            stmt.executeUpdate("insert into Objects (ObjectId, Description) values (101, 'john')");
            stmt.executeUpdate("insert into Objects (ObjectId, Description) values (200, 'Dog')");
            stmt.executeQuery("select setval('objects_objectid_seq', 1000)");
            stmt.executeUpdate("insert into ClassLinkTypes (LinkName, LinkType) values ('hasa', 2)");
            stmt.executeUpdate("insert into ObjectLinks (ObjectId, LinkName, LinkToObject) values (100, 'isa', 1)");
            stmt.executeUpdate("insert into ObjectLinks (ObjectId, LinkName, LinkToObject) values (101, 'instance', 100)");
            stmt.executeUpdate("insert into ObjectLinks (ObjectId, LinkName, LinkToObject) values (200, 'isa', 1)");
            stmt.executeUpdate("insert into Dictionary (Word, SenseNumber, GrammarString, ObjectId) values ('LEFT-WALL', '1', 'AV+', 1)");
            stmt.executeUpdate("insert into Dictionary (Word, SenseNumber, GrammarString, ObjectId) values ('john', '1', 'S+ | DO-', 1)");
            stmt.executeUpdate("insert into Dictionary (Word, SenseNumber, GrammarString, ObjectId) values ('a', '1', 'D+', 1)");
            stmt.executeUpdate("insert into Dictionary (Word, SenseNumber, GrammarString, ObjectId) values ('dog', '1', '[D-] & (S+ | DO-)', 200)");
            stmt.executeUpdate("insert into Dictionary (Word, SenseNumber, GrammarString, ObjectId) values ('have', '1', 'S- & AV- & DO+', 1)");
            stmt.executeUpdate("insert into LanguageMorphologies (LanguageName, MorphologyTag, Rank, Root, Surface, Used) values " + "                                 ('English', 'third singular', 1, 'have', 'has', TRUE)");
            stmt.executeUpdate("insert into GrammarLinks (LinkName, LinkType) values ('S', 1)");
            stmt.executeUpdate("insert into GrammarLinks (LinkName, LinkType) values ('DO', 3)");
            stmt.executeUpdate("insert into GrammarLinks (LinkName, LinkType) values ('AV', 7)");
            stmt.executeUpdate("insert into GrammarLinks (LinkName, LinkType) values ('D', 10)");
            stmt.executeUpdate("insert into Articles (ArticleName, Dereference) values ('a', 2)");
            stmt.executeUpdate("insert into FrameSlots (SlotName) values ('actor')");
            stmt.executeUpdate("insert into FrameSlots (SlotName) values ('object')");
            stmt.executeUpdate("insert into Verbs (VerbName, Type, SubjectSlot, IndirectObjectSlot, PredicateNounSlot) values ('have', 1, 'actor', '', 'object')");
            stmt.executeQuery("select setval('instructions_instructionid_seq', 1)");
            stmt.executeUpdate("insert into Instructions (Type, ExecuteString, FrameSlot, Operator, LinkName, ObjectId, AttributeName) " + "values (3, 'link %actor hasa %object', null, 0, null, null, null)");
            stmt.executeQuery("select setval('transactions_transactionid_seq', 1)");
            stmt.executeUpdate("insert into Transactions (InstructionId, Description) values (2, 'have - link')");
            stmt.executeQuery("select setval('verbtransactions_verbid_seq', 1)");
            stmt.executeUpdate("insert into VerbTransactions (VerbString, MoodType, TransactionId) values ('have', 1, 2)");
            stmt.executeUpdate("insert into VerbConstraints (VerbId, FrameSlot, ObjectId) values (2, 'actor', 1)");
            stmt.executeUpdate("insert into VerbConstraints (VerbId, FrameSlot, ObjectId) values (2, 'object', 1)");
            stmt.executeUpdate("insert into ProperNouns (Noun, SenseNumber, ObjectId) values ('john', 1, 101)");
            stmt.executeUpdate("update SystemProperties set value = 'Tutorial 1 Data' where name = 'DB Data Version'");
            conn.commit();
        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }
```

## 85966eff-050

**A**

```java
public static void copyFile(File in, File out) {
        try {
            FileChannel sourceChannel = new FileInputStream(in).getChannel();
            FileChannel destinationChannel = new FileOutputStream(out).getChannel();
            sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
            sourceChannel.close();
            destinationChannel.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

**B**

```java
public void readData(RowSetInternal caller) throws SQLException {
        Connection con = null;
        try {
            CachedRowSet crs = (CachedRowSet) caller;
            if (crs.getPageSize() == 0 && crs.size() > 0) {
                crs.close();
            }
            writerCalls = 0;
            userCon = false;
            con = this.connect(caller);
            if (con == null || crs.getCommand() == null) throw new SQLException(resBundle.handleGetObject("crsreader.connecterr").toString());
            try {
                con.setTransactionIsolation(crs.getTransactionIsolation());
            } catch (Exception ex) {
                ;
            }
            PreparedStatement pstmt = con.prepareStatement(crs.getCommand());
            decodeParams(caller.getParams(), pstmt);
            try {
                pstmt.setMaxRows(crs.getMaxRows());
                pstmt.setMaxFieldSize(crs.getMaxFieldSize());
                pstmt.setEscapeProcessing(crs.getEscapeProcessing());
                pstmt.setQueryTimeout(crs.getQueryTimeout());
            } catch (Exception ex) {
                throw new SQLException(ex.getMessage());
            }
            if (crs.getCommand().toLowerCase().indexOf("select") != -1) {
                ResultSet rs = pstmt.executeQuery();
                if (crs.getPageSize() == 0) {
                    crs.populate(rs);
                } else {
                    pstmt = con.prepareStatement(crs.getCommand(), ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    decodeParams(caller.getParams(), pstmt);
                    try {
                        pstmt.setMaxRows(crs.getMaxRows());
                        pstmt.setMaxFieldSize(crs.getMaxFieldSize());
                        pstmt.setEscapeProcessing(crs.getEscapeProcessing());
                        pstmt.setQueryTimeout(crs.getQueryTimeout());
                    } catch (Exception ex) {
                        throw new SQLException(ex.getMessage());
                    }
                    rs = pstmt.executeQuery();
                    crs.populate(rs, startPosition);
                }
                rs.close();
            } else {
                pstmt.executeUpdate();
            }
            pstmt.close();
            try {
                con.commit();
            } catch (SQLException ex) {
                ;
            }
            if (getCloseConnection() == true) con.close();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            try {
                if (con != null && getCloseConnection() == true) {
                    try {
                        if (!con.getAutoCommit()) {
                            con.rollback();
                        }
                    } catch (Exception dummy) {
                    }
                    con.close();
                    con = null;
                }
            } catch (SQLException e) {
            }
        }
    }
```
