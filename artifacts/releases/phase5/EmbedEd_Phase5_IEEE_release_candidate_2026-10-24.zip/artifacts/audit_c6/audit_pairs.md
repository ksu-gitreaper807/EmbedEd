# False-negative audit — 50 pairs (50 per condition, blind)

seed 13, version `phase01-v8`. For each pair decide whether the two fragments implement the **same functionality** (BigCloneBench's clone definition). Write `clone`, `not_clone` or `unsure` in `audit_labels.csv`; do not open `audit_key.csv` until you run `score`.

Rubric: `clone` = same functionality whatever the syntax (Type-1..4, incl. weak T3/T4); `not_clone` = different functionality or one is only a small part of the other; `unsure` = cannot tell in about a minute.

## 64fd35c5-001

**A**

```java
private void getRandomGUID(boolean secure) throws NoSuchAlgorithmException {
        MessageDigest md5 = null;
        StringBuffer sbValueBeforeMD5 = new StringBuffer();
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Error: " + e);
            throw e;
        }
        try {
            long time = System.currentTimeMillis();
            long rand = 0;
            if (secure) {
                rand = mySecureRand.nextLong();
            } else {
                rand = myRand.nextLong();
            }
            sbValueBeforeMD5.append(s_id);
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(time));
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(rand));
            valueBeforeMD5 = sbValueBeforeMD5.toString();
            md5.update(valueBeforeMD5.getBytes());
            byte[] array = md5.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            valueAfterMD5 = sb.toString();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
```

**B**

```java
private List<String> getRobots(String beginURL, String contextRoot) {
        List<String> vtRobots = new ArrayList<String>();
        BufferedReader bfReader = null;
        try {
            URL urlx = new URL(beginURL + "/" + contextRoot + "/" + "robots.txt");
            URLConnection urlConn = urlx.openConnection();
            urlConn.setUseCaches(false);
            bfReader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            String sxLine = "";
            while ((sxLine = bfReader.readLine()) != null) {
                if (sxLine.startsWith("Disallow:")) {
                    vtRobots.add(sxLine.substring(10));
                }
            }
        } catch (Exception e) {
            PetstoreUtil.getLogger().log(Level.SEVERE, "Exception" + e);
            vtRobots = null;
        } finally {
            try {
                if (bfReader != null) {
                    bfReader.close();
                }
            } catch (Exception ee) {
            }
        }
        return vtRobots;
    }
```

## 64fd35c5-002

**A**

```java
private static void main(String[] args) {
        try {
            File f = new File("test.txt");
            if (f.exists()) {
                throw new IOException(f + " already exists.  I don't want to overwrite it.");
            }
            StraightStreamReader in;
            char[] cbuf = new char[0x1000];
            int read;
            int totRead;
            FileOutputStream out = new FileOutputStream(f);
            for (int i = 0x00; i < 0x100; i++) {
                out.write(i);
            }
            out.close();
            in = new StraightStreamReader(new FileInputStream(f));
            for (int i = 0x00; i < 0x100; i++) {
                read = in.read();
                if (read != i) {
                    System.err.println("Error: " + i + " read as " + read);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = in.read(cbuf);
            if (totRead != 0x100) {
                System.err.println("Simple buffered read did not read the full amount: 0x" + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead, 0x100 - totRead)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead + 0x123, 0x100 - totRead)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i + 0x123] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i + 0x123]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead + 0x123, 7)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i + 0x123] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i + 0x123]);
                }
            }
            in.close();
            f.delete();
        } catch (IOException x) {
            System.err.println(x.getMessage());
        }
    }
```

**B**

```java
private boolean copy_to_file_io(File src, File dst) throws IOException {
        InputStream is = null;
        OutputStream os = null;
        try {
            is = new FileInputStream(src);
            is = new BufferedInputStream(is);
            os = new FileOutputStream(dst);
            os = new BufferedOutputStream(os);
            byte buffer[] = new byte[1024 * 64];
            int read;
            while ((read = is.read(buffer)) > 0) {
                os.write(buffer, 0, read);
            }
            return true;
        } finally {
            try {
                if (is != null) is.close();
            } catch (IOException e) {
                Debug.debug(e);
            }
            try {
                if (os != null) os.close();
            } catch (IOException e) {
                Debug.debug(e);
            }
        }
    }
```

## 64fd35c5-003

**A**

```java
public static void main(String[] args) throws IOException {
        String uri = "hdfs://localhost:8020/user/leeing/maxtemp/sample.txt";
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(URI.create(uri), conf);
        FSDataInputStream in = null;
        try {
            in = fs.open(new Path(uri));
            IOUtils.copyBytes(in, System.out, 8192, false);
            System.out.println("\n");
            in.seek(0);
            IOUtils.copyBytes(in, System.out, 8192, false);
        } finally {
            IOUtils.closeStream(in);
        }
    }
```

**B**

```java
public static void createZipFromDataset(String localResourceId, File dataset, File metadata) {
        CommunicationLogger.warning("System entered ZipFactory");
        try {
            String tmpDir = System.getProperty("java.io.tmpdir");
            String outFilename = tmpDir + "/" + localResourceId + ".zip";
            CommunicationLogger.warning("File name: " + outFilename);
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));
            byte[] buf = new byte[1024];
            FileInputStream in = new FileInputStream(dataset);
            out.putNextEntry(new ZipEntry(dataset.getName()));
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in = new FileInputStream(metadata);
            out.putNextEntry(new ZipEntry(metadata.getName()));
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            out.closeEntry();
            in.close();
            out.close();
        } catch (IOException e) {
            System.out.println("IO EXCEPTION: " + e.getMessage());
        }
    }
```

## 64fd35c5-004

**A**

```java
private String fetchHTML(String s) {
        String str;
        StringBuffer sb = new StringBuffer();
        try {
            URL url = new URL(s);
            InputStream is = url.openStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            while ((str = br.readLine()) != null) {
                sb.append(str);
            }
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
        return sb.toString();
    }
```

**B**

```java
public static boolean getFile(String s, String name) {
        try {
            File f = new File("D:\\buttons\\data\\sounds\\" + name);
            URL url = new URL(s);
            URLConnection conn = url.openConnection();
            BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
            int ch;
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(f));
            while ((ch = bis.read()) != -1) {
                bos.write(ch);
            }
            System.out.println("wrote audio url: " + s + " \nto file " + f);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
```

## 64fd35c5-005

**A**

```java
public static void copy(String srcFileName, String destFileName) throws IOException {
        if (srcFileName == null) {
            throw new IllegalArgumentException("srcFileName is null");
        }
        if (destFileName == null) {
            throw new IllegalArgumentException("destFileName is null");
        }
        FileChannel src = null;
        FileChannel dest = null;
        try {
            src = new FileInputStream(srcFileName).getChannel();
            dest = new FileOutputStream(destFileName).getChannel();
            long n = src.size();
            MappedByteBuffer buf = src.map(FileChannel.MapMode.READ_ONLY, 0, n);
            dest.write(buf);
        } finally {
            if (dest != null) {
                try {
                    dest.close();
                } catch (IOException e1) {
                }
            }
            if (src != null) {
                try {
                    src.close();
                } catch (IOException e1) {
                }
            }
        }
    }
```

**B**

```java
private boolean copyFile(File inFile, File outFile) {
        BufferedReader reader = null;
        BufferedWriter writer = null;
        try {
            reader = new BufferedReader(new FileReader(inFile));
            writer = new BufferedWriter(new FileWriter(outFile));
            while (reader.ready()) {
                writer.write(reader.read());
            }
            writer.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                    return false;
                }
            }
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException ex) {
                    return false;
                }
            }
        }
        return true;
    }
```

## 64fd35c5-006

**A**

```java
private String generateCode(String seed) {
        try {
            Security.addProvider(new FNVProvider());
            MessageDigest digest = MessageDigest.getInstance("FNV-1a");
            digest.update((seed + UUID.randomUUID().toString()).getBytes());
            byte[] hash1 = digest.digest();
            String sHash1 = "m" + (new String(LibraryBase64.encode(hash1))).replaceAll("=", "").replaceAll("-", "_");
            return sHash1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
```

**B**

```java
public static String hashPassword(String password) {
        String hashStr = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(password.getBytes(Charset.defaultCharset()));
            BigInteger hash = new BigInteger(1, md5.digest());
            hashStr = hash.toString(16);
        } catch (NoSuchAlgorithmException e) {
            return password;
        }
        StringBuilder buffer = new StringBuilder(hashStr);
        while (buffer.length() < 32) {
            buffer.insert(0, '0');
        }
        return buffer.toString();
    }
```

## 64fd35c5-007

**A**

```java
private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new IOException("Destination '" + destFile + "' exists but is a directory");
        }
        FileInputStream input = new FileInputStream(srcFile);
        try {
            FileOutputStream output = new FileOutputStream(destFile);
            try {
                IOUtils.copy(input, output);
            } finally {
                IOUtils.closeQuietly(output);
            }
        } finally {
            IOUtils.closeQuietly(input);
        }
        if (srcFile.length() != destFile.length()) {
            throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "'");
        }
        if (preserveFileDate) {
            destFile.setLastModified(srcFile.lastModified());
        }
    }
```

**B**

```java
public static File copyFile(File file) {
        File src = file;
        File dest = new File(src.getName());
        try {
            if (!dest.exists()) {
                dest.createNewFile();
            }
            FileChannel source = new FileInputStream(src).getChannel();
            FileChannel destination = new FileOutputStream(dest).getChannel();
            destination.transferFrom(source, 0, source.size());
            source.close();
            destination.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }
```

## 64fd35c5-008

**A**

```java
private String convert(InputStream input, String encoding) throws Exception {
        Process p = Runtime.getRuntime().exec("tidy -q -f /dev/null -wrap 0 --output-xml yes --doctype omit --force-output true --new-empty-tags  " + emptyTags + " --quote-nbsp no -utf8");
        Thread t = new CopyThread(input, p.getOutputStream());
        t.start();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        IOUtils.copy(p.getInputStream(), output);
        p.waitFor();
        t.join();
        return output.toString();
    }
```

**B**

```java
public static String ReadURLStringAndWrite(URL url, String str) throws Exception {
        String stringToReverse = URLEncoder.encode(str, "UTF-8");
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);
        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
        out.write(stringToReverse);
        out.close();
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String decodedString;
        String back = "";
        while ((decodedString = in.readLine()) != null) {
            back += decodedString + "\n";
        }
        in.close();
        return back;
    }
```

## 64fd35c5-009

**A**

```java
private void documentFileChooserActionPerformed(java.awt.event.ActionEvent evt) {
        if (evt.getActionCommand().equals(JFileChooser.APPROVE_SELECTION)) {
            File selectedFile = documentFileChooser.getSelectedFile();
            File collectionCopyFile;
            String newDocumentName = selectedFile.getName();
            Document newDocument = new Document(newDocumentName);
            if (activeCollection.containsDocument(newDocument)) {
                int matchingFilenameDistinguisher = 1;
                StringBuilder distinguisherReplacer = new StringBuilder();
                newDocumentName = newDocumentName.concat("(" + matchingFilenameDistinguisher + ")");
                newDocument.setDocumentName(newDocumentName);
                while (activeCollection.containsDocument(newDocument)) {
                    matchingFilenameDistinguisher++;
                    newDocumentName = distinguisherReplacer.replace(newDocumentName.length() - 2, newDocumentName.length() - 1, new Integer(matchingFilenameDistinguisher).toString()).toString();
                    newDocument.setDocumentName(newDocumentName);
                }
            }
            Scanner tokenizer = null;
            FileChannel fileSource = null;
            FileChannel collectionDestination = null;
            HashMap<String, Integer> termHashMap = new HashMap<String, Integer>();
            Index collectionIndex = activeCollection.getIndex();
            int documentTermMaxFrequency = 0;
            int currentTermFrequency;
            try {
                tokenizer = new Scanner(new BufferedReader(new FileReader(selectedFile)));
                tokenizer.useDelimiter(Pattern.compile("\\p{Space}|\\p{Punct}|\\p{Cntrl}"));
                String nextToken;
                while (tokenizer.hasNext()) {
                    nextToken = tokenizer.next().toLowerCase();
                    if (!nextToken.isEmpty()) if (termHashMap.containsKey(nextToken)) termHashMap.put(nextToken, termHashMap.get(nextToken) + 1); else termHashMap.put(nextToken, 1);
                }
                Term newTerm;
                for (String term : termHashMap.keySet()) {
                    newTerm = new Term(term);
                    if (!collectionIndex.termExists(newTerm)) collectionIndex.addTerm(newTerm);
                    currentTermFrequency = termHashMap.get(term);
                    if (currentTermFrequency > documentTermMaxFrequency) documentTermMaxFrequency = currentTermFrequency;
                    collectionIndex.addOccurence(newTerm, newDocument, currentTermFrequency);
                }
                activeCollection.addDocument(newDocument);
                String userHome = System.getProperty("user.home");
                String fileSeparator = System.getProperty("file.separator");
                collectionCopyFile = new File(userHome + fileSeparator + "Infrared" + fileSeparator + activeCollection.getDocumentCollectionName() + fileSeparator + newDocumentName);
                collectionCopyFile.createNewFile();
                fileSource = new FileInputStream(selectedFile).getChannel();
                collectionDestination = new FileOutputStream(collectionCopyFile).getChannel();
                collectionDestination.transferFrom(fileSource, 0, fileSource.size());
            } catch (FileNotFoundException e) {
                System.err.println(e.getMessage() + " This error should never occur! The file was just selected!");
                return;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "An I/O error occured during file transfer!", "File transfer I/O error", JOptionPane.WARNING_MESSAGE);
                return;
            } finally {
                try {
                    if (tokenizer != null) tokenizer.close();
                    if (fileSource != null) fileSource.close();
                    if (collectionDestination != null) collectionDestination.close();
                } catch (IOException e) {
                    System.err.println(e.getMessage());
                }
            }
            processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        } else if (evt.getActionCommand().equalsIgnoreCase(JFileChooser.CANCEL_SELECTION)) processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
```

**B**

```java
public MapInfo loadLocalMapData(String fileName) {
        MapInfo info = mapCacheLocal.get(fileName);
        if (info != null && info.getContent() == null) {
            try {
                BufferedReader bufferedreader;
                URL fetchUrl = new URL(localMapContextUrl, fileName);
                URLConnection urlconnection = fetchUrl.openConnection();
                if (urlconnection.getContentEncoding() != null) {
                    bufferedreader = new BufferedReader(new InputStreamReader(urlconnection.getInputStream(), urlconnection.getContentEncoding()));
                } else {
                    bufferedreader = new BufferedReader(new InputStreamReader(urlconnection.getInputStream(), "utf-8"));
                }
                String line;
                StringBuilder mapContent = new StringBuilder();
                while ((line = bufferedreader.readLine()) != null) {
                    mapContent.append(line);
                    mapContent.append("\n");
                }
                info.setContent(mapContent.toString());
                GameMapImplementation gameMap = GameMapImplementation.createFromMapInfo(info);
            } catch (IOException _ex) {
                System.err.println("HexTD::readFile:: Can't read from " + fileName);
            }
        }
        return info;
    }
```

## 64fd35c5-010

**A**

```java
public ClientDTO changePassword(String pMail, String pMdp) {
        Client vClientBean = null;
        ClientDTO vClientDTO = null;
        vClientBean = mClientDao.getClient(pMail);
        if (vClientBean != null) {
            MessageDigest vMd5Instance;
            try {
                vMd5Instance = MessageDigest.getInstance("MD5");
                vMd5Instance.reset();
                vMd5Instance.update(pMdp.getBytes());
                byte[] vDigest = vMd5Instance.digest();
                BigInteger vBigInt = new BigInteger(1, vDigest);
                String vHashPassword = vBigInt.toString(16);
                vClientBean.setMdp(vHashPassword);
                vClientDTO = BeanToDTO.getInstance().createClientDTO(vClientBean);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        return vClientDTO;
    }
```

**B**

```java
private boolean saveNodeData(NodeInfo info) {
        boolean rCode = false;
        String query = mServer + "save.php" + ("?id=" + info.getId());
        try {
            URL url = new URL(query);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            String contentType = info.getMIMEType().toString();
            byte[] body = info.getData();
            conn.setAllowUserInteraction(false);
            conn.setRequestMethod("PUT");
            if (contentType.equals("")) {
                contentType = "application/octet-stream";
            }
            System.out.println("contentType: " + contentType);
            conn.setRequestProperty("Content-Type", contentType);
            setCredentials(conn);
            conn.setDoOutput(true);
            conn.getOutputStream().write(body);
            rCode = saveNode(info, conn);
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.toString());
        }
        return rCode;
    }
```

## 64fd35c5-011

**A**

```java
public static boolean copy(File source, File target) {
        try {
            if (!source.exists()) return false;
            target.getParentFile().mkdirs();
            InputStream input = new FileInputStream(source);
            OutputStream output = new FileOutputStream(target);
            byte[] buf = new byte[1024];
            int len;
            while ((len = input.read(buf)) > 0) output.write(buf, 0, len);
            input.close();
            output.close();
            return true;
        } catch (Exception exc) {
            exc.printStackTrace();
            return false;
        }
    }
```

**B**

```java
private boolean copy(File in, File out) {
        try {
            FileInputStream fis = new FileInputStream(in);
            FileOutputStream fos = new FileOutputStream(out);
            FileChannel readableChannel = fis.getChannel();
            FileChannel writableChannel = fos.getChannel();
            writableChannel.truncate(0);
            writableChannel.transferFrom(readableChannel, 0, readableChannel.size());
            fis.close();
            fos.close();
            return true;
        } catch (IOException ioe) {
            System.out.println("Copy Error: IOException during copy\r\n" + ioe.getMessage());
            return false;
        }
    }
```

## 64fd35c5-012

**A**

```java
@Test
    public void testWrite() throws Exception {
        MrstkXmlFileReader reader = new MrstkXmlFileReader();
        reader.setFileName("..//data//MrstkXML//prototype3.xml");
        reader.read();
        SpectrumArray sp = reader.getOutput();
        File tmp = File.createTempFile("mrstktest", ".xml");
        System.out.println("Writing temp file: " + tmp.getAbsolutePath());
        MrstkXmlFileWriter writer = new MrstkXmlFileWriter(sp);
        writer.setFile(tmp);
        writer.write();
        MrstkXmlFileReader reader2 = new MrstkXmlFileReader();
        reader2.setFileName(writer.getFile().getAbsolutePath());
        reader2.read();
        SpectrumArray sp2 = reader2.getOutput();
        assertTrue(sp.equals(sp2));
    }
```

**B**

```java
public static void main(String[] args) throws Exception {
        URL url = new URL("http://www.sohu.com");
        InputStream is = url.openStream();
        InputStreamReader isr = new InputStreamReader(is, Charset.forName("GB18030"));
        FileOutputStream fos = new FileOutputStream("gen/sohu2.html");
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        char[] b = new char[2048];
        int temp;
        while (-1 != (temp = isr.read(b, 0, b.length))) {
            osw.write(b);
        }
        osw.close();
        BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
        String line = null;
    }
```

## 64fd35c5-013

**A**

```java
private void getRandomGUID(boolean secure) {
        MessageDigest md5 = null;
        StringBuffer sbValueBeforeMD5 = new StringBuffer();
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            logger.debug("Random GUID error: " + e.getMessage());
        }
        try {
            long time = System.currentTimeMillis();
            long rand = 0;
            if (secure) {
                rand = mySecureRand.nextLong();
            } else {
                rand = myRand.nextLong();
            }
            sbValueBeforeMD5.append(s_id);
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(time));
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(rand));
            valueBeforeMD5 = sbValueBeforeMD5.toString();
            md5.update(valueBeforeMD5.getBytes());
            byte[] array = md5.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            valueAfterMD5 = sb.toString();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
```

**B**

```java
public static byte[] expandPasswordToKey(String password, int keyLen, byte[] salt) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            int digLen = md5.getDigestLength();
            byte[] mdBuf = new byte[digLen];
            byte[] key = new byte[keyLen];
            int cnt = 0;
            while (cnt < keyLen) {
                if (cnt > 0) {
                    md5.update(mdBuf);
                }
                md5.update(password.getBytes());
                md5.update(salt);
                md5.digest(mdBuf, 0, digLen);
                int n = ((digLen > (keyLen - cnt)) ? keyLen - cnt : digLen);
                System.arraycopy(mdBuf, 0, key, cnt, n);
                cnt += n;
            }
            return key;
        } catch (Exception e) {
            throw new Error("Error in SSH2KeyPairFile.expandPasswordToKey: " + e);
        }
    }
```

## 64fd35c5-014

**A**

```java
public static void main(String[] args) {
        try {
            FileReader reader = new FileReader(args[0]);
            FileWriter writer = new FileWriter(args[1]);
            html2xhtml(reader, writer);
            writer.close();
            reader.close();
        } catch (Exception e) {
            freemind.main.Resources.getInstance().logException(e);
        }
    }
```

**B**

```java
private void writeInputStreamToFile(InputStream stream, File file) {
        try {
            FileOutputStream fOut = new FileOutputStream(file);
            IOUtils.copy(stream, fOut);
            fOut.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

## 64fd35c5-015

**A**

```java
public int process(ProcessorContext context) throws InterruptedException, ProcessorException {
        logger.info("JAISaveTask:process");
        final RenderedOp im = (RenderedOp) context.get("RenderedOp");
        final String path = "s3://s3.amazonaws.com/rssfetch/" + (new Guid());
        final PNGEncodeParam.RGB encPar = new PNGEncodeParam.RGB();
        encPar.setTransparentRGB(new int[] { 0, 0, 0 });
        File tmpFile = null;
        try {
            tmpFile = File.createTempFile("thmb", ".png");
            OutputStream out = new FileOutputStream(tmpFile);
            final ParameterBlock pb = (new ParameterBlock()).addSource(im).add(out).add("png").add(encPar);
            JAI.create("encode", pb, null);
            out.flush();
            out.close();
            FileInputStream in = new FileInputStream(tmpFile);
            final XFile xfile = new XFile(path);
            final XFileOutputStream xout = new XFileOutputStream(xfile);
            final com.luzan.common.nfs.s3.XFileExtensionAccessor xfa = ((com.luzan.common.nfs.s3.XFileExtensionAccessor) xfile.getExtensionAccessor());
            if (xfa != null) {
                xfa.setMimeType("image/png");
                xfa.setContentLength(tmpFile.length());
            }
            IOUtils.copy(in, xout);
            xout.flush();
            xout.close();
            in.close();
            context.put("outputPath", path);
        } catch (IOException e) {
            logger.error(e);
            throw new ProcessorException(e);
        } catch (Throwable e) {
            logger.error(e);
            throw new ProcessorException(e);
        } finally {
            if (tmpFile != null && tmpFile.exists()) {
                tmpFile.delete();
            }
        }
        return TaskState.STATE_MO_START + TaskState.STATE_ENCODE;
    }
```

**B**

```java
public static void createZipFromDataset(String localResourceId, File dataset, File metadata) {
        CommunicationLogger.warning("System entered ZipFactory");
        try {
            String tmpDir = System.getProperty("java.io.tmpdir");
            String outFilename = tmpDir + "/" + localResourceId + ".zip";
            CommunicationLogger.warning("File name: " + outFilename);
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));
            byte[] buf = new byte[1024];
            FileInputStream in = new FileInputStream(dataset);
            out.putNextEntry(new ZipEntry(dataset.getName()));
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in = new FileInputStream(metadata);
            out.putNextEntry(new ZipEntry(metadata.getName()));
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            out.closeEntry();
            in.close();
            out.close();
        } catch (IOException e) {
            System.out.println("IO EXCEPTION: " + e.getMessage());
        }
    }
```

## 64fd35c5-016

**A**

```java
@SuppressWarnings("finally")
  private void compress(File src) throws IOException
  {
    if (this.switches.contains(Switch.test))
      return;

    checkSourceFile(src);
    if (src.getPath().endsWith(".bz2"))
    {
      this.log.println("WARNING: skipping file because it already has .bz2 suffix:").println(src);
      return;
    }

    final File dst = new File(src.getPath() + ".bz2").getAbsoluteFile();
    if (!checkDestFile(dst))
      return;

    FileChannel       inChannel   = null;
    FileChannel       outChannel  = null;
    FileOutputStream  fileOut     = null;
    BZip2OutputStream bzOut       = null;
    FileLock          inLock      = null;
    FileLock          outLock     = null;

    try
    {
      inChannel = new FileInputStream(src).getChannel();
      final long inSize = inChannel.size();
      inLock = inChannel.tryLock(0, inSize, true);
      if (inLock == null)
        throw error("source file locked by another process: " + src);

      fileOut     = new FileOutputStream(dst);
      outChannel  = fileOut.getChannel();
      bzOut       = new BZip2OutputStream(
        new BufferedXOutputStream(fileOut, 8192),
        Math.min(
          (this.blockSize == -1) ? BZip2OutputStream.MAX_BLOCK_SIZE : this.blockSize,
          BZip2OutputStream.chooseBlockSize(inSize)
        )
      );

      outLock = outChannel.tryLock();
      if (outLock == null)
        throw error("destination file locked by another process: " + dst);

      final boolean showProgress = this.switches.contains(Switch.showProgress);
      long pos = 0;
      int progress = 0;

      if (showProgress || this.verbose)
      {
        this.log.print("source: " + src).print(": size=").println(inSize);
        this.log.println("target: " + dst);
      }

      while (true)
      {
        final long maxStep = showProgress ? Math.max(8192, (inSize - pos) / MAX_PROGRESS) : (inSize - pos);
        if (maxStep <= 0)
        {
          if (showProgress)
          {
            for (int i = progress; i < MAX_PROGRESS; i++)
              this.log.print('#');
            this.log.println(" done");
          }
          break;
        }
        else
        {
          final long step = inChannel.transferTo(pos, maxStep, bzOut);
          if ((step == 0) && (inChannel.size() != inSize))
            throw error("file " + src + " has been modified concurrently by another process");

          pos += step;
          if (showProgress)
          {
            final double  p           = (double) pos / (double) inSize;
            final int     newProgress = (int) (MAX_PROGRESS * p);
            for (int i = progress; i < newProgress; i++)
              this.log.print('#');
            progress = newProgress;
          }
        }
      }

      inLock.release();
      inChannel.close();
      bzOut.closeInstance();
      final long outSize = outChannel.position();
      outChannel.truncate(outSize);
      outLock.release();
      fileOut.close();

      if (this.verbose)
      {
        final double ratio = (inSize == 0) ? (outSize * 100) : ((double) outSize / (double) inSize);
        this.log.print("raw size: ").print(inSize)
          .print("; compressed size: ").print(outSize)
          .print("; compression ratio: ").print(ratio).println('%');
      }

      if (!this.switches.contains(Switch.keep))
      {
        if (!src.delete())
          throw error("unable to delete sourcefile: " + src);
      }
    }
    catch (final IOException ex)
    {
      IO.tryClose(inChannel);
      IO.tryClose(bzOut);
      IO.tryClose(fileOut);
      IO.tryRelease(inLock);
      IO.tryRelease(outLock);
      try
      {
        this.log.println();
      }
      finally
      {
        throw ex;
      }
    }
  }
```

**B**

```java
public static synchronized void repartition(File[] sourceFiles, File targetDirectory, String prefix, long maxUnitBases, long maxUnitEntries) throws Exception {
        if (!targetDirectory.exists()) {
            if (!targetDirectory.mkdirs()) throw new Exception("Could not create directory " + targetDirectory.getAbsolutePath());
        }
        File tmpFile = new File(targetDirectory, "tmp.fasta");
        FileOutputStream fos = new FileOutputStream(tmpFile);
        FileChannel fco = fos.getChannel();
        for (File file : sourceFiles) {
            FileInputStream fis = new FileInputStream(file);
            FileChannel fci = fis.getChannel();
            ByteBuffer buffer = ByteBuffer.allocate(64000);
            while (fci.read(buffer) > 0) {
                buffer.flip();
                fco.write(buffer);
                buffer.clear();
            }
            fci.close();
        }
        fco.close();
        FastaFile fastaFile = new FastaFile(tmpFile);
        fastaFile.split(targetDirectory, prefix, maxUnitBases, maxUnitEntries);
        tmpFile.delete();
    }
```

## 64fd35c5-017

**A**

```java
private void getImage(String filename) throws MalformedURLException, IOException, SAXException, FileNotFoundException {
        String url = Constants.STRATEGICDOMINATION_URL + "/images/gameimages/" + filename;
        WebRequest req = new GetMethodWebRequest(url);
        WebResponse response = wc.getResponse(req);
        File file = new File("etc/images/" + filename);
        FileOutputStream outputStream = new FileOutputStream(file);
        IOUtils.copy(response.getInputStream(), outputStream);
    }
```

**B**

```java
public void updateDb(int scriptNumber) throws SQLException, IOException {
        String pathName = updatesPackage.replace(".", "/");
        InputStream in = getClass().getClassLoader().getResourceAsStream(pathName + "/" + scriptNumber + ".sql");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        IOUtils.copy(in, out);
        String script = out.toString("UTF-8");
        String[] statements = script.split(";");
        for (String statement : statements) {
            getJdbcTemplate().execute(statement);
        }
    }
```

## 64fd35c5-018

**A**

```java
protected boolean update(String sql, int requiredRows, int maxRows) throws SQLException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("executing " + sql + "...");
        }
        Connection connection = null;
        boolean oldAutoCommit = true;
        try {
            connection = dataSource.getConnection();
            connection.clearWarnings();
            oldAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(sql);
            if (requiredRows != -1 && rowsAffected < requiredRows) {
                LOG.warn("(" + rowsAffected + ") less than " + requiredRows + " rows affected, rolling back...");
                connection.rollback();
                return false;
            }
            if (maxRows != -1 && rowsAffected > maxRows) {
                LOG.warn("(" + rowsAffected + ") more than " + maxRows + " rows affected, rolling back...");
                connection.rollback();
                return false;
            }
            connection.commit();
            return true;
        } catch (SQLException e) {
            LOG.error("Unable to update database using: " + sql, e);
            throw e;
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(oldAutoCommit);
                    connection.close();
                }
            } catch (SQLException e) {
                LOG.error("Unable to close connection: " + e, e);
            }
        }
    }
```

**B**

```java
private void populateAPI(API api) {
        try {
            if (api.isPopulated()) {
                log.traceln("Skipping API " + api.getName() + " (already populated)");
                return;
            }
            api.setPopulated(true);
            String sql = "update API set populated=1 where name=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, api.getName());
            pstmt.executeUpdate();
            pstmt.close();
            storePackagesAndClasses(api);
            conn.commit();
        } catch (SQLException ex) {
            log.error("Store (api: " + api.getName() + ") failed!");
            DBUtils.logSQLException(ex);
            log.error("Rolling back..");
            try {
                conn.rollback();
            } catch (SQLException inner_ex) {
                log.error("rollback failed!");
            }
        }
    }
```

## 64fd35c5-019

**A**

```java
protected void checkWeavingJar() throws IOException {
        OutputStream out = null;
        try {
            final File weaving = new File(getWeavingPath());
            if (!weaving.exists()) {
                new File(getWeavingFolder()).mkdir();
                weaving.createNewFile();
                final Path src = new Path("weaving/openfrwk-weaving.jar");
                final InputStream in = FileLocator.openStream(getBundle(), src, false);
                out = new FileOutputStream(getWeavingPath(), true);
                IOUtils.copy(in, out);
                Logger.log(Logger.INFO, "Put weaving jar at location " + weaving);
            } else {
                Logger.getLog().info("File openfrwk-weaving.jar already exists at " + weaving);
            }
        } catch (final SecurityException e) {
            Logger.log(Logger.ERROR, "[SECURITY EXCEPTION] Not enough privilegies to create " + "folder and copy NexOpen weaving jar at location " + getWeavingFolder());
            Logger.logException(e);
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }
    }
```

**B**

```java
public void exportFile() {
        String expfolder = PropertyHandler.getInstance().getProperty(PropertyHandler.KINDLE_EXPORT_FOLDER_KEY);
        File out = new File(expfolder + File.separator + previewInfo.getTitle() + ".prc");
        File f = new File(absPath);
        try {
            FileOutputStream fout = new FileOutputStream(out);
            FileInputStream fin = new FileInputStream(f);
            int read = 0;
            byte[] buffer = new byte[1024 * 1024];
            while ((read = fin.read(buffer)) > 0) {
                fout.write(buffer, 0, read);
            }
            fin.close();
            fout.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

## 64fd35c5-020

**A**

```java
public Image storeImage(String title, String pathToImage, Map<String, Object> additionalProperties) {
        File collectionFolder = ProjectManager.getInstance().getFolder(PropertyHandler.getInstance().getProperty("_default_collection_name"));
        File imageFile = new File(pathToImage);
        String filename = "";
        String format = "";
        File copiedImageFile;
        while (true) {
            filename = "image" + UUID.randomUUID().hashCode();
            if (!DbEntryProvider.INSTANCE.idExists(filename)) {
                Path path = new Path(pathToImage);
                format = path.getFileExtension();
                copiedImageFile = new File(collectionFolder.getAbsolutePath() + File.separator + filename + "." + format);
                if (!copiedImageFile.exists()) break;
            }
        }
        try {
            copiedImageFile.createNewFile();
        } catch (IOException e1) {
            ExceptionHandlingService.INSTANCE.handleException(e1);
            return null;
        }
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(imageFile), 4096);
            out = new BufferedOutputStream(new FileOutputStream(copiedImageFile), 4096);
            int c;
            while ((c = in.read()) != -1) out.write(c);
            in.close();
            out.close();
        } catch (FileNotFoundException e) {
            ExceptionHandlingService.INSTANCE.handleException(e);
            return null;
        } catch (IOException e) {
            ExceptionHandlingService.INSTANCE.handleException(e);
            return null;
        }
        Image image = new ImageImpl();
        image.setId(filename);
        image.setFormat(format);
        image.setEntryDate(new Date());
        image.setTitle(title);
        image.setAdditionalProperties(additionalProperties);
        boolean success = DbEntryProvider.INSTANCE.storeNewImage(image);
        if (success) return image;
        return null;
    }
```

**B**

```java
private WikiSiteContentInfo createInfoIndexSite(Long domainId) {
        final UserInfo user = getSecurityService().getCurrentUser();
        final Locale locale = new Locale(user.getLocale());
        final String country = locale.getLanguage();
        InputStream inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("wiki_index_" + country + ".xhtml");
        if (inStream == null) {
            inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("wiki_index.xhtml");
        }
        if (inStream == null) {
            inStream = new ByteArrayInputStream(DEFAULT_WIKI_INDEX_SITE_TEXT.getBytes());
        }
        if (inStream != null) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                IOUtils.copyLarge(inStream, out);
                return createIndexVersion(domainId, out.toString(), user);
            } catch (IOException exception) {
                LOGGER.error("Error creating info page.", exception);
            } finally {
                try {
                    inStream.close();
                    out.close();
                } catch (IOException exception) {
                    LOGGER.error("Error reading wiki_index.xhtml", exception);
                }
            }
        }
        return null;
    }
```

## 64fd35c5-021

**A**

```java
private void fileCopy(final File src, final File dest) throws IOException {
        final FileChannel srcChannel = new FileInputStream(src).getChannel();
        final FileChannel dstChannel = new FileOutputStream(dest).getChannel();
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
        srcChannel.close();
        dstChannel.close();
    }
```

**B**

```java
public synchronized boolean copyTmpDataFile(String fpath) throws IOException {
        if (tmpDataOutput != null) tmpDataOutput.close();
        tmpDataOutput = null;
        if (tmpDataFile == null) return false;
        File nfp = new File(fpath);
        if (nfp.exists()) nfp.delete();
        FileInputStream src = new FileInputStream(tmpDataFile);
        FileOutputStream dst = new FileOutputStream(nfp);
        byte[] buffer = new byte[4096];
        int bytesRead;
        while ((bytesRead = src.read(buffer)) != -1) dst.write(buffer, 0, bytesRead);
        src.close();
        dst.close();
        return true;
    }
```

## 64fd35c5-022

**A**

```java
private static void copy(File source, File dest) throws FileNotFoundException, IOException {
        FileInputStream input = new FileInputStream(source);
        FileOutputStream output = new FileOutputStream(dest);
        System.out.println("Copying " + source + " to " + dest);
        IOUtils.copy(input, output);
        output.close();
        input.close();
        dest.setLastModified(source.lastModified());
    }
```

**B**

```java
private String copyTutorial() throws IOException {
        File inputFile = new File(getFilenameForOriginalTutorial());
        File outputFile = new File(getFilenameForCopiedTutorial());
        FileReader in = new FileReader(inputFile);
        FileWriter out = new FileWriter(outputFile);
        int c;
        while ((c = in.read()) != -1) out.write(c);
        in.close();
        out.close();
        return getFilenameForCopiedTutorial();
    }
```

## 64fd35c5-023

**A**

```java
public void downloadFile(OutputStream os, int fileId) throws IOException, SQLException {
        Connection conn = null;
        try {
            conn = ds.getConnection();
            Guard.checkConnectionNotNull(conn);
            PreparedStatement ps = conn.prepareStatement("select * from FILE_BODIES where file_id=?");
            ps.setInt(1, fileId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new FileNotFoundException("File with id=" + fileId + " not found!");
            }
            Blob blob = rs.getBlob("data");
            InputStream is = blob.getBinaryStream();
            IOUtils.copyLarge(is, os);
        } finally {
            JdbcDaoHelper.safeClose(conn, log);
        }
    }
```

**B**

```java
public void deletePortletName(PortletName portletNameBean) {
        DatabaseAdapter dbDyn = null;
        PreparedStatement ps = null;
        try {
            dbDyn = DatabaseAdapter.getInstance();
            if (portletNameBean.getPortletId() == null) throw new IllegalArgumentException("portletNameId is null");
            String sql = "delete from  WM_PORTAL_PORTLET_NAME " + "where  ID_SITE_CTX_TYPE=?";
            ps = dbDyn.prepareStatement(sql);
            RsetTools.setLong(ps, 1, portletNameBean.getPortletId());
            int i1 = ps.executeUpdate();
            if (log.isDebugEnabled()) log.debug("Count of deleted records - " + i1);
            dbDyn.commit();
        } catch (Exception e) {
            try {
                if (dbDyn != null) dbDyn.rollback();
            } catch (Exception e001) {
            }
            String es = "Error delete portlet name";
            log.error(es, e);
            throw new IllegalStateException(es, e);
        } finally {
            DatabaseManager.close(dbDyn, ps);
            dbDyn = null;
            ps = null;
        }
    }
```

## 64fd35c5-024

**A**

```java
public static void copyFile(File destFile, File src) throws IOException {
        File destDir = destFile.getParentFile();
        File tempFile = new File(destFile + "_tmp");
        destDir.mkdirs();
        InputStream is = new FileInputStream(src);
        try {
            FileOutputStream os = new FileOutputStream(tempFile);
            try {
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) > 0) os.write(buf, 0, len);
            } finally {
                os.close();
            }
        } finally {
            is.close();
        }
        destFile.delete();
        if (!tempFile.renameTo(destFile)) throw new IOException("Unable to rename " + tempFile + " to " + destFile);
    }
```

**B**

```java
public static void createModelZip(String filename, String tempdir) throws EDITSException {
        try {
            BufferedInputStream origin = null;
            FileOutputStream dest = new FileOutputStream(filename);
            ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(dest));
            int BUFFER = 2048;
            byte data[] = new byte[BUFFER];
            File f = new File(tempdir);
            for (File fs : f.listFiles()) {
                FileInputStream fi = new FileInputStream(fs.getAbsolutePath());
                origin = new BufferedInputStream(fi, BUFFER);
                ZipEntry entry = new ZipEntry(fs.getName());
                out.putNextEntry(entry);
                int count;
                while ((count = origin.read(data, 0, BUFFER)) != -1) out.write(data, 0, count);
                out.closeEntry();
                origin.close();
            }
            out.close();
        } catch (Exception e) {
            throw new EDITSException("Can not create a model in file " + filename + " from folder " + tempdir);
        }
    }
```

## 64fd35c5-025

**A**

```java
private String getTextResponse(String address) throws Exception {
        URL url = new URL(address);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setUseCaches(false);
        BufferedReader in = null;
        try {
            con.connect();
            assertEquals(HttpURLConnection.HTTP_OK, con.getResponseCode());
            in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                builder.append(inputLine);
            }
            return builder.toString();
        } finally {
            if (in != null) {
                in.close();
            }
            con.disconnect();
        }
    }
```

**B**

```java
public int getUrl() {
        try {
            final URL url = new URL(this.url);
            conn = url.openConnection();
            if (cookies != null) {
                conn.setRequestProperty("Cookie", cookies);
            }
            InputStreamReader inputstream = new InputStreamReader(conn.getInputStream(), charset);
            charset = inputstream.getEncoding();
            BufferedReader input = new BufferedReader(inputstream);
            String line;
            while ((line = input.readLine()) != null) {
                content += line + "\n";
            }
            return 0;
        } catch (MalformedURLException e) {
            return 1;
        } catch (IOException e2) {
            return 2;
        }
    }
```

## 64fd35c5-026

**A**

```java
public void xtest1() throws Exception {
        InputStream input = new FileInputStream("C:/Documentos/j931_01.pdf");
        InputStream tmp = new ITextManager().cut(input, 3, 8);
        FileOutputStream output = new FileOutputStream("C:/temp/split.pdf");
        IOUtils.copy(tmp, output);
        input.close();
        tmp.close();
        output.close();
    }
```

**B**

```java
public void copyToCurrentDir(File _copyFile, String _fileName) throws IOException {
        File outputFile = new File(getCurrentPath() + File.separator + _fileName);
        FileReader in;
        FileWriter out;
        if (!outputFile.exists()) {
            outputFile.createNewFile();
        }
        in = new FileReader(_copyFile);
        out = new FileWriter(outputFile);
        int c;
        while ((c = in.read()) != -1) out.write(c);
        in.close();
        out.close();
        reList();
    }
```

## 64fd35c5-027

**A**

```java
private void exportJar(File root, List<File> list, Manifest manifest) throws Exception {
        JarOutputStream jarOut = null;
        FileInputStream fin = null;
        try {
            jarOut = new JarOutputStream(new FileOutputStream(jarFile), manifest);
            for (int i = 0; i < list.size(); i++) {
                String filename = list.get(i).getAbsolutePath();
                filename = filename.substring(root.getAbsolutePath().length() + 1);
                fin = new FileInputStream(list.get(i));
                JarEntry entry = new JarEntry(filename.replace('\\', '/'));
                jarOut.putNextEntry(entry);
                byte[] buf = new byte[4096];
                int read;
                while ((read = fin.read(buf)) != -1) {
                    jarOut.write(buf, 0, read);
                }
                jarOut.closeEntry();
                jarOut.flush();
            }
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (Exception e) {
                    ExceptionOperation.operate(e);
                }
            }
            if (jarOut != null) {
                try {
                    jarOut.close();
                } catch (Exception e) {
                }
            }
        }
    }
```

**B**

```java
@Override
    public BufferedImageAndBytes load(T thing) {
        String iurl = resolver.getUrl(thing);
        URL url;
        for (int k = 0; k < nTries; k++) {
            if (k > 0) {
                logger.debug("retry #" + k);
            }
            try {
                url = new URL(iurl);
                URLConnection connection = url.openConnection();
                if (userAgent != null) {
                    connection.setRequestProperty("User-Agent", userAgent);
                }
                InputStream is = new BufferedInputStream(connection.getInputStream());
                ByteArrayOutputStream baos = new ByteArrayOutputStream(40000);
                int b;
                while ((b = is.read()) != -1) {
                    baos.write(b);
                }
                is.close();
                byte[] bytes = baos.toByteArray();
                ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
                BufferedImage image = ImageIO.read(bais);
                return new BufferedImageAndBytes(image, bytes);
            } catch (MalformedURLException e) {
                continue;
            } catch (IOException e) {
                continue;
            }
        }
        return null;
    }
```

## 64fd35c5-028

**A**

```java
private static String doGetForSessionKey(String authCode) throws Exception {
        String sessionKey = "";
        HttpClient hc = new DefaultHttpClient();
        HttpGet hg = new HttpGet(Common.TEST_SESSION_HOST + Common.TEST_SESSION_PARAM + authCode);
        HttpResponse hr = hc.execute(hg);
        BufferedReader br = new BufferedReader(new InputStreamReader(hr.getEntity().getContent()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        String result = sb.toString();
        Log.i("sessionKeyMessages", result);
        Map<String, String> map = Util.handleURLParameters(result);
        sessionKey = map.get(Common.TOP_SESSION);
        String topParameters = map.get(Common.TOP_PARAMETERS);
        String decTopParameters = Util.decodeBase64(topParameters);
        Log.i("base64", decTopParameters);
        map = Util.handleURLParameters(decTopParameters);
        Log.i("nick", map.get(Common.VISITOR_NICK));
        CachePool.put(Common.VISITOR_NICK, map.get(Common.VISITOR_NICK));
        return sessionKey;
    }
```

**B**

```java
public static String doPostWithBasicAuthentication(URL url, String username, String password, String parameters, Map<String, String> headers) throws IOException {
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setDoInput(true);
        con.setDoOutput(true);
        byte[] encodedPassword = (username + ":" + password).getBytes();
        BASE64Encoder encoder = new BASE64Encoder();
        con.setRequestProperty("Authorization", "Basic " + encoder.encode(encodedPassword));
        con.setConnectTimeout(2000);
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        if (parameters != null) con.setRequestProperty("Content-Length", "" + Integer.toString(parameters.getBytes().length));
        if (headers != null) {
            for (Map.Entry<String, String> header : headers.entrySet()) {
                con.setRequestProperty(header.getKey(), header.getValue());
            }
        }
        DataOutputStream wr = new DataOutputStream(con.getOutputStream());
        wr.writeBytes(parameters);
        wr.flush();
        wr.close();
        InputStream is = con.getInputStream();
        BufferedReader rd = new BufferedReader(new InputStreamReader(is));
        String line;
        StringBuffer response = new StringBuffer();
        while ((line = rd.readLine()) != null) {
            response.append(line);
            response.append('\n');
        }
        rd.close();
        is.close();
        con.disconnect();
        return response.toString();
    }
```

## 64fd35c5-029

**A**

```java
public Transaction() throws Exception {
        Connection Conn = null;
        Statement Stmt = null;
        try {
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            Conn = DriverManager.getConnection(DBUrl);
            Conn.setAutoCommit(true);
            Stmt = Conn.createStatement();
            try {
                Stmt.executeUpdate("DROP TABLE trans_test");
            } catch (SQLException sqlEx) {
            }
            Stmt.executeUpdate("CREATE TABLE trans_test (id int not null primary key, decdata double) type=BDB");
            Conn.setAutoCommit(false);
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (1, 21.0)");
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (2, 23.485115)");
            Conn.rollback();
            System.out.println("Roll Ok");
            ResultSet RS = Stmt.executeQuery("SELECT * from trans_test");
            if (!RS.next()) {
                System.out.println("Ok");
            } else {
                System.out.println("Rollback failed");
            }
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (2, 23.485115)");
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (1, 21.485115)");
            Conn.commit();
            RS = Stmt.executeQuery("SELECT * from trans_test where id=2");
            if (RS.next()) {
                System.out.println(RS.getDouble(2));
                System.out.println("Ok");
            } else {
                System.out.println("Rollback failed");
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (Stmt != null) {
                try {
                    Stmt.close();
                } catch (SQLException SQLEx) {
                }
            }
            if (Conn != null) {
                try {
                    Conn.close();
                } catch (SQLException SQLEx) {
                }
            }
        }
    }
```

**B**

```java
@Override
    public String resolveItem(String oldJpgFsPath) throws DatabaseException {
        if (oldJpgFsPath == null || "".equals(oldJpgFsPath)) throw new NullPointerException("oldJpgFsPath");
        try {
            getConnection().setAutoCommit(false);
        } catch (SQLException e) {
            LOGGER.warn("Unable to set autocommit off", e);
        }
        PreparedStatement statement = null;
        String ret = null;
        try {
            statement = getConnection().prepareStatement(SELECT_ITEM_STATEMENT);
            statement.setString(1, oldJpgFsPath);
            ResultSet rs = statement.executeQuery();
            int i = 0;
            int id = -1;
            int rowsAffected = 0;
            while (rs.next()) {
                id = rs.getInt("id");
                ret = rs.getString("imageFile");
                i++;
            }
            if (id != -1 && new File(ret).exists()) {
                statement = getConnection().prepareStatement(UPDATE_ITEM_STATEMENT);
                statement.setInt(1, id);
                rowsAffected = statement.executeUpdate();
            } else {
                return null;
            }
            if (rowsAffected == 1) {
                getConnection().commit();
                LOGGER.debug("DB has been updated.");
            } else {
                getConnection().rollback();
                LOGGER.error("DB has not been updated -> rollback!");
            }
        } catch (SQLException e) {
            LOGGER.error(e);
        } finally {
            closeConnection();
        }
        return ret;
    }
```

## 64fd35c5-030

**A**

```java
public void testCodingCompletedFromFile() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        WritableByteChannel channel = newChannel(baos);
        HttpParams params = new BasicHttpParams();
        SessionOutputBuffer outbuf = new SessionOutputBufferImpl(1024, 128, params);
        HttpTransportMetricsImpl metrics = new HttpTransportMetricsImpl();
        LengthDelimitedEncoder encoder = new LengthDelimitedEncoder(channel, outbuf, metrics, 5);
        encoder.write(wrap("stuff"));
        File tmpFile = File.createTempFile("testFile", "txt");
        FileOutputStream fout = new FileOutputStream(tmpFile);
        OutputStreamWriter wrtout = new OutputStreamWriter(fout);
        wrtout.write("more stuff");
        wrtout.flush();
        wrtout.close();
        try {
            FileChannel fchannel = new FileInputStream(tmpFile).getChannel();
            encoder.transfer(fchannel, 0, 10);
            fail("IllegalStateException should have been thrown");
        } catch (IllegalStateException ex) {
        } finally {
            tmpFile.delete();
        }
    }
```

**B**

```java
private boolean doPost(String content) throws IOException {
        logger.debug("Service Registry PutRecordHandler: " + baseurl.toString());
        logger.debug("**** Service Registry PutRecord Request ****\n " + content);
        HttpURLConnection huc = (HttpURLConnection) (baseurl.openConnection());
        huc.setRequestMethod("POST");
        huc.setDoOutput(true);
        ByteArrayInputStream in = new ByteArrayInputStream(content.getBytes());
        OutputStream out = huc.getOutputStream();
        byte[] buffer = new byte[BUFFER_SIZE];
        BufferedInputStream bis = new BufferedInputStream(in);
        int count = 0;
        while ((count = bis.read(buffer)) != -1) {
            out.write(buffer, 0, count);
        }
        out.close();
        int code = huc.getResponseCode();
        logger.debug("Service Registry Response Code: " + code);
        if (code == 200) {
            return true;
        } else return false;
    }
```

## 64fd35c5-031

**A**

```java
private void loadServers() {
        try {
            URL url = new URL(VirtualDeckConfig.SERVERS_URL);
            cmbServer.addItem("Local");
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String str;
            if (in.readLine().equals("[list]")) {
                while ((str = in.readLine()) != null) {
                    String[] host_line = str.split(";");
                    Host h = new Host();
                    h.setIp(host_line[0]);
                    h.setPort(Integer.parseInt(host_line[1]));
                    h.setName(host_line[2]);
                    getServers().add(h);
                    cmbServer.addItem(h.getName());
                }
            }
            in.close();
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
    }
```

**B**

```java
public static void test() {
        try {
            Pattern pattern = Pattern.compile("[0-9]{3}\\. <a href='(.*)\\.html'>(.*)</a><br />");
            URL url = new URL("http://farmfive.com/");
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
            String line;
            int count = 0;
            while ((line = br.readLine()) != null) {
                Matcher match = pattern.matcher(line);
                if (match.matches()) {
                    System.out.println(match.group(1) + " " + match.group(2));
                    count++;
                }
            }
            System.out.println(count + " counted");
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
```

## 64fd35c5-032

**A**

```java
@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String contentId = req.getParameter(CONTENT_ID);
        String contentType = req.getParameter(CONTENT_TYPE);
        if (contentId == null || contentType == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Content id or content type not specified");
            return;
        }
        try {
            switch(ContentType.valueOf(contentType)) {
                case IMAGE:
                    resp.setContentType("image/jpeg");
                    break;
                case AUDIO:
                    resp.setContentType("audio/mp3");
                    break;
                case VIDEO:
                    resp.setContentType("video/mpeg");
                    break;
                default:
                    throw new IllegalStateException("Invalid content type specified");
            }
        } catch (IllegalArgumentException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid content type specified");
            return;
        }
        String baseUrl = this.getServletContext().getInitParameter(BASE_URL);
        URL url = new URL(baseUrl + "/" + contentType.toLowerCase() + "/" + contentId);
        URLConnection conn = url.openConnection();
        resp.setContentLength(conn.getContentLength());
        IOUtils.copy(conn.getInputStream(), resp.getOutputStream());
    }
```

**B**

```java
public HttpURLConnection getURLConnection() throws IOException {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) _url.openConnection();
            conn.setUseCaches(false);
            conn.setRequestProperty("User-Agent", "WD-2.0");
            if (_doConditionalGET) {
                ResourceInfo ri = (ResourceInfo) conditionalGetTable().get(_url.toString());
                if (ri != null) {
                    if (ri.lastModified != null) {
                        conn.setRequestProperty("If-Modified-Since", ri.lastModified);
                    }
                    if (ri.etag != null) {
                        conn.setRequestProperty("If-None-Match", ri.etag);
                    }
                }
            }
            if (_username != null && _password != null) {
                String authenticationStr = _username + ":" + _password;
                String encodedAuthStr = Base64.encodeBytes(authenticationStr.getBytes());
                conn.setRequestProperty("Authorization", "Basic " + encodedAuthStr);
            }
            _httpResponseCode = conn.getResponseCode();
            if (_httpResponseCode == HttpURLConnection.HTTP_OK) {
                if (_doConditionalGET) {
                    ResourceInfo ri = new ResourceInfo();
                    ri.lastModified = conn.getHeaderField("Last-Modified");
                    ri.etag = conn.getHeaderField("ETag");
                    Hashtable table = conditionalGetTable();
                    table.put(_url.toString(), ri);
                    storeConditionalGetTable(table);
                }
            } else if (_httpResponseCode == HttpURLConnection.HTTP_NOT_MODIFIED) {
                _shouldGET = false;
            } else {
                Log.getInstance().write("Error getting url: " + _url + "\n" + "Error code: " + _httpResponseCode);
                _error = HTTP_NOT_OK;
                conn.disconnect();
                conn = null;
            }
        } catch (SocketException ex) {
            conn.disconnect();
            conn = null;
            _error = NETWORK_DOWN;
        }
        return conn;
    }
```

## 64fd35c5-033

**A**

```java
public static void main(String[] args) throws NoSuchAlgorithmException {
        String password = "root";
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.update(password.getBytes());
        final byte[] digest = messageDigest.digest();
        final StringBuilder buf = new StringBuilder(digest.length * 2);
        for (int j = 0; j < digest.length; j++) {
            buf.append(HEX_DIGITS[(digest[j] >> 4) & 0x0f]);
            buf.append(HEX_DIGITS[digest[j] & 0x0f]);
        }
        String pwd = buf.toString();
        System.out.println(pwd);
    }
```

**B**

```java
public static void decompressFile(File f) throws IOException {
        File target = new File(f.toString().substring(0, f.toString().length() - 3));
        System.out.print("Decompressing: " + f.getName() + ".. ");
        long initialSize = f.length();
        GZIPInputStream in = new GZIPInputStream(new FileInputStream(f));
        FileOutputStream fos = new FileOutputStream(target);
        byte[] buf = new byte[1024];
        int read;
        while ((read = in.read(buf)) != -1) {
            fos.write(buf, 0, read);
        }
        System.out.println("Done.");
        fos.close();
        in.close();
        long endSize = target.length();
        System.out.println("Initial size: " + initialSize + "; Decompressed size: " + endSize);
    }
```

## 64fd35c5-034

**A**

```java
private void checkRoundtrip(byte[] content) throws Exception {
        InputStream in = new ByteArrayInputStream(content);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        CodecUtil.encodeQuotedPrintableBinary(in, out);
        in = new QuotedPrintableInputStream(new ByteArrayInputStream(out.toByteArray()));
        out = new ByteArrayOutputStream();
        IOUtils.copy(in, out);
        assertEquals(content, out.toByteArray());
    }
```

**B**

```java
public void xtest11() throws Exception {
        PDFManager manager = new ITextManager();
        InputStream pdf = new FileInputStream("/tmp/UML2.pdf");
        InputStream page1 = manager.cut(pdf, 1, 1);
        OutputStream outputStream = new FileOutputStream("/tmp/page.pdf");
        IOUtils.copy(page1, outputStream);
        outputStream.close();
        pdf.close();
    }
```

## 64fd35c5-035

**A**

```java
public String doAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - start");
        }
        t_information_EditMap editMap = new t_information_EditMap();
        try {
            t_information_Form vo = null;
            vo = (t_information_Form) form;
            vo.setCompany(vo.getCounty());
            if ("����".equals(vo.getInfo_type())) {
                vo.setInfo_level(null);
                vo.setAlert_level(null);
            }
            String str_postFIX = "";
            int i_p = 0;
            editMap.add(vo);
            try {
                logger.info("���͹�˾�鱨��");
                String[] mobiles = request.getParameterValues("mobiles");
                vo.setMobiles(mobiles);
                SMSService.inforAlert(vo);
            } catch (Exception e) {
                logger.error("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)", e);
            }
            String filename = vo.getFile().getFileName();
            if (null != filename && !"".equals(filename)) {
                FormFile file = vo.getFile();
                String realpath = getServlet().getServletContext().getRealPath("/");
                realpath = realpath.replaceAll("\\\\", "/");
                String inforId = vo.getId();
                String rootFilePath = getServlet().getServletContext().getRealPath(request.getContextPath());
                rootFilePath = (new StringBuilder(String.valueOf(rootFilePath))).append(UploadFileOne.strPath).toString();
                String strAppend = (new StringBuilder(String.valueOf(UUIDGenerator.nextHex()))).append(UploadFileOne.getFileType(file)).toString();
                if (file.getFileSize() != 0) {
                    file.getInputStream();
                    String name = file.getFileName();
                    i_p = file.getFileName().lastIndexOf(".");
                    str_postFIX = file.getFileName().substring(i_p, file.getFileName().length());
                    String fullPath = realpath + "attach/" + strAppend + str_postFIX;
                    t_attach attach = new t_attach();
                    attach.setAttach_fullname(fullPath);
                    attach.setAttach_name(name);
                    attach.setInfor_id(Integer.parseInt(inforId));
                    attach.setInsert_day(new Date());
                    attach.setUpdate_day(new Date());
                    t_attach_EditMap attachEdit = new t_attach_EditMap();
                    attachEdit.add(attach);
                    File sysfile = new File(fullPath);
                    if (!sysfile.exists()) {
                        sysfile.createNewFile();
                    }
                    java.io.OutputStream out = new FileOutputStream(sysfile);
                    org.apache.commons.io.IOUtils.copy(file.getInputStream(), out);
                    out.close();
                }
            }
        } catch (HibernateException e) {
            logger.error("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)", e);
            ActionErrors errors = new ActionErrors();
            errors.add("org.apache.struts.action.GLOBAL_ERROR", new ActionError("error.database.save", e.toString()));
            saveErrors(request, errors);
            e.printStackTrace();
            request.setAttribute("t_information_Form", form);
            if (logger.isDebugEnabled()) {
                logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - end");
            }
            return "addpage";
        }
        if (logger.isDebugEnabled()) {
            logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - end");
        }
        return "aftersave";
    }
```

**B**

```java
public void maj(String titre, String num_version) {
        int res = 2;
        String content_xml = "";
        try {
            URL url = new URL("http://code.google.com/feeds/p/tux-team/downloads/basic");
            InputStreamReader ipsr = new InputStreamReader(url.openStream());
            BufferedReader br = new BufferedReader(ipsr);
            String line = null;
            StringBuffer buffer = new StringBuffer();
            while ((line = br.readLine()) != null) {
                buffer.append(line).append('\n');
            }
            br.close();
            content_xml = buffer.toString();
            res = lecture_xml(titre, num_version, content_xml);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        switch(res) {
            case 0:
                ihm.jl_maj.setText("Pas de mises à jour disponible. (" + num_version + ")");
                ihm.jl_maj.setIcon(Resources.getImageIcon("images/valide.png", IHM_AProposDe.class));
                break;
            case 1:
                ihm.jl_maj.setText("Une mise à jour est diponible. (" + maj_file_version + ")");
                ihm.jl_maj.setIcon(Resources.getImageIcon("images/warning.png", IHM_AProposDe.class));
                ihm.jb_maj.setVisible(true);
                break;
            default:
                ihm.jl_maj.setText("Serveur de mise à jour non disponible.");
                ihm.jl_maj.setIcon(Resources.getImageIcon("images/erreur.png", IHM_AProposDe.class));
        }
    }
```

## 64fd35c5-036

**A**

```java
private void sendFile(File file, HttpServletResponse response) throws IOException {
        response.setContentLength((int) file.length());
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            IOUtils.copy(inputStream, response.getOutputStream());
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
    }
```

**B**

```java
private BufferedReader getReader(final String fileUrl) throws IOException {
        InputStreamReader reader;
        try {
            reader = new FileReader(fileUrl);
        } catch (FileNotFoundException e) {
            URL url = new URL(fileUrl);
            reader = new InputStreamReader(url.openStream());
        }
        return new BufferedReader(reader);
    }
```

## 64fd35c5-037

**A**

```java
public void putFile(CompoundName file, FileInputStream fileInput) throws IOException {
        File fullDir = new File(REMOTE_BASE_DIR.getCanonicalPath());
        for (int i = 0; i < file.size() - 1; i++) fullDir = new File(fullDir, file.get(i));
        fullDir.mkdirs();
        File outputFile = new File(fullDir, file.get(file.size() - 1));
        FileOutputStream outStream = new FileOutputStream(outputFile);
        for (int byteIn = fileInput.read(); byteIn != -1; byteIn = fileInput.read()) outStream.write(byteIn);
        fileInput.close();
        outStream.close();
    }
```

**B**

```java
public static void copyFile(File oldFile, File newFile) throws Exception {
        newFile.getParentFile().mkdirs();
        newFile.createNewFile();
        FileChannel srcChannel = new FileInputStream(oldFile).getChannel();
        FileChannel dstChannel = new FileOutputStream(newFile).getChannel();
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
        srcChannel.close();
        dstChannel.close();
    }
```

## 64fd35c5-038

**A**

```java
private void copyFile(File sourceFile, File targetFile) {
        beNice();
        dispatchEvent(SynchronizationEventType.FileCopy, sourceFile, targetFile);
        File temporaryFile = new File(targetFile.getPath().concat(".jnstemp"));
        while (temporaryFile.exists()) {
            try {
                beNice();
                temporaryFile.delete();
                beNice();
            } catch (Exception ex) {
            }
        }
        try {
            if (targetFile.exists()) {
                targetFile.delete();
            }
            FileInputStream fis = new FileInputStream(sourceFile);
            FileOutputStream fos = new FileOutputStream(temporaryFile);
            byte[] buffer = new byte[204800];
            int readBytes = 0;
            int counter = 0;
            while ((readBytes = fis.read(buffer)) != -1) {
                counter++;
                updateStatus("... processing fragment " + String.valueOf(counter));
                fos.write(buffer, 0, readBytes);
            }
            fis.close();
            fos.close();
            temporaryFile.renameTo(targetFile);
            temporaryFile.setLastModified(sourceFile.lastModified());
            targetFile.setLastModified(sourceFile.lastModified());
        } catch (IOException e) {
            Exception dispatchedException = new Exception("ERROR: Copy File( " + sourceFile.getPath() + ", " + targetFile.getPath() + " )");
            dispatchEvent(dispatchedException, sourceFile, targetFile);
        }
        dispatchEvent(SynchronizationEventType.FileCopyDone, sourceFile, targetFile);
    }
```

**B**

```java
public boolean backupFile(File oldFile, File newFile) {
        boolean isBkupFileOK = false;
        FileChannel sourceChannel = null;
        FileChannel targetChannel = null;
        try {
            sourceChannel = new FileInputStream(oldFile).getChannel();
            targetChannel = new FileOutputStream(newFile).getChannel();
            targetChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
        } catch (IOException e) {
            logger.log(Level.SEVERE, "IO exception occurred while copying file", e);
        } finally {
            if ((newFile != null) && (newFile.exists()) && (newFile.length() > 0)) {
                isBkupFileOK = true;
            }
            try {
                if (sourceChannel != null) {
                    sourceChannel.close();
                }
                if (targetChannel != null) {
                    targetChannel.close();
                }
            } catch (IOException e) {
                logger.info("closing channels failed");
            }
        }
        return isBkupFileOK;
    }
```

## 64fd35c5-039

**A**

```java
public static void copyFile(File src, File dest, boolean preserveFileDate) throws IOException {
        if (src.exists() && src.isDirectory()) {
            throw new IOException("source file exists but is a directory");
        }
        if (dest.exists() && dest.isDirectory()) {
            dest = new File(dest, src.getName());
        }
        if (!dest.exists()) {
            dest.createNewFile();
        }
        FileChannel srcCH = null;
        FileChannel destCH = null;
        try {
            srcCH = new FileInputStream(src).getChannel();
            destCH = new FileOutputStream(dest).getChannel();
            destCH.transferFrom(srcCH, 0, srcCH.size());
        } finally {
            closeQuietly(srcCH);
            closeQuietly(destCH);
        }
        if (src.length() != dest.length()) {
            throw new IOException("Failed to copy full contents from '" + src + "' to '" + dest + "'");
        }
        if (preserveFileDate) {
            dest.setLastModified(src.lastModified());
        }
    }
```

**B**

```java
public static FileChannel newFileChannel(File file, String rw, boolean enableException) throws IOException {
        if (file == null) return null;
        if (rw == null || rw.length() == 0) {
            return null;
        }
        rw = rw.toLowerCase();
        if (rw.equals(MODE_READ)) {
            if (FileUtil.exists(file, enableException)) {
                FileInputStream fis = new FileInputStream(file);
                FileChannel ch = fis.getChannel();
                setObjectMap(ch.hashCode(), fis, FIS);
                return ch;
            }
        } else if (rw.equals(MODE_WRITE)) {
            FileOutputStream fos = new FileOutputStream(file);
            FileChannel ch = fos.getChannel();
            setObjectMap(ch.hashCode(), fos, FOS_W);
            return ch;
        } else if (rw.equals(MODE_APPEND)) {
            if (FileUtil.exists(file, enableException)) {
                RandomAccessFile raf = new RandomAccessFile(file, "rw");
                FileChannel ch = raf.getChannel();
                ch.position(ch.size());
                setObjectMap(ch.hashCode(), raf, FOS_A);
                return ch;
            }
        } else if (rw.equals(MODE_READ_WRITE)) {
            if (FileUtil.exists(file, enableException)) {
                RandomAccessFile raf = new RandomAccessFile(file, rw);
                FileChannel ch = raf.getChannel();
                setObjectMap(ch.hashCode(), raf, RAF);
                return ch;
            }
        } else {
            throw new IllegalArgumentException("Illegal read/write type : [" + rw + "]\n" + "You can use following types for: \n" + "  (1) Read Only  = \"r\"\n" + "  (2) Write Only = \"w\"\n" + "  (3) Read/Write = \"rw\"\n" + "  (4) Append     = \"a\"");
        }
        return null;
    }
```

## 64fd35c5-040

**A**

```java
PackageFileImpl(PackageDirectoryImpl dir, String name, InputStream data) throws IOException {
        this.dir = dir;
        this.name = name;
        this.updates = dir.getUpdates();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        IOUtils.copy(data, stream);
        updates.setNewData(getFullName(), stream.toByteArray());
        stream.close();
    }
```

**B**

```java
protected void downloadCacheFile(File file) throws Exception {
        ApplicationProperties app = ApplicationProperties.getInstance();
        String address = app.getProperty(JabberConstants.PROPERTY_JABBER_SERVERLIST, DEFAULT_SERVER_URL);
        URL url = new URL(address);
        file.createNewFile();
        OutputStream cache = new FileOutputStream(file);
        InputStream input = url.openStream();
        byte buffer[] = new byte[1024];
        int bytesRead = 0;
        while ((bytesRead = input.read(buffer)) >= 0) cache.write(buffer, 0, bytesRead);
        input.close();
        cache.close();
    }
```

## 64fd35c5-041

**A**

```java
public void getZipFiles(String filename) {
        try {
            String destinationname = "c:\\mods\\peu\\";
            byte[] buf = new byte[1024];
            ZipInputStream zipinputstream = null;
            ZipEntry zipentry;
            zipinputstream = new ZipInputStream(new FileInputStream(filename));
            zipentry = zipinputstream.getNextEntry();
            while (zipentry != null) {
                String entryName = zipentry.getName();
                System.out.println("entryname " + entryName);
                int n;
                FileOutputStream fileoutputstream;
                File newFile = new File(entryName);
                String directory = newFile.getParent();
                if (directory == null) {
                    if (newFile.isDirectory()) break;
                }
                fileoutputstream = new FileOutputStream(destinationname + entryName);
                while ((n = zipinputstream.read(buf, 0, 1024)) > -1) fileoutputstream.write(buf, 0, n);
                fileoutputstream.close();
                zipinputstream.closeEntry();
                zipentry = zipinputstream.getNextEntry();
            }
            zipinputstream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
```

**B**

```java
private void importDocument(String path, boolean detectParagraphs, Parser parser, ReadingAnnotationFilter filter, String encoding) {
        try {
            Reader in = null;
            int contentlength = 0;
            if (JGloss.messages.getString("encodings.default").equals(encoding)) encoding = null;
            String title = "";
            try {
                URL url = new URL(path);
                URLConnection c = url.openConnection();
                contentlength = c.getContentLength();
                String enc = c.getContentEncoding();
                InputStream is = new BufferedInputStream(c.getInputStream());
                if (encoding != null) in = new InputStreamReader(is, encoding); else {
                    in = CharacterEncodingDetector.getReader(is, enc);
                    encoding = ((InputStreamReader) in).getEncoding();
                }
                title = url.getFile();
                if (title == null || title.length() == 0) title = path;
            } catch (MalformedURLException ex) {
                File f = new File(path);
                contentlength = (int) f.length();
                title = f.getName();
                if (title.toLowerCase().endsWith("htm") || title.toLowerCase().endsWith("html")) {
                }
                InputStream is = new BufferedInputStream(new FileInputStream(path));
                if (encoding != null) in = new InputStreamReader(is, encoding); else {
                    in = CharacterEncodingDetector.getReader(is);
                    encoding = ((InputStreamReader) in).getEncoding();
                }
            }
            importFromReader(in, detectParagraphs, path, title, filter, parser, CharacterEncodingDetector.guessLength(contentlength, encoding));
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showConfirmDialog(this, JGloss.messages.getString("error.import.exception", new Object[] { path, ex.getClass().getName(), ex.getLocalizedMessage() }), JGloss.messages.getString("error.import.title"), JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE);
            if (model.getDocumentName() == null) this.dispose();
        }
    }
```

## 64fd35c5-042

**A**

```java
public static String md5Encode16(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes("utf-8"));
            byte b[] = md.digest();
            int i;
            StringBuilder buf = new StringBuilder("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) i += 256;
                if (i < 16) buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString().substring(8, 24);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e);
        }
    }
```

**B**

```java
public String makeLeoNounCall(String noun) {
        String ret = "";
        StringBuffer buf = new StringBuffer();
        try {
            URL url = new URL("http://dict.leo.org" + noun);
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), Charset.forName("ISO8859_1")));
            String inputLine;
            boolean display = false;
            while ((inputLine = in.readLine()) != null) {
                if (inputLine.contains("contentholder")) {
                    display = true;
                }
                if (display) buf.append(inputLine);
            }
            ret = FilterFunctions.findEndTag("<td", buf.toString());
            sleepRandomTime();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }
```

## 64fd35c5-043

**A**

```java
public ChatClient registerPlayer(int playerId, String playerLogin) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.reset();
        md.update(playerLogin.getBytes("UTF-8"), 0, playerLogin.length());
        byte[] accountToken = md.digest();
        byte[] token = generateToken(accountToken);
        ChatClient chatClient = new ChatClient(playerId, token);
        players.put(playerId, chatClient);
        return chatClient;
    }
```

**B**

```java
public static String exchangeForSessionToken(String protocol, String domain, String onetimeUseToken, PrivateKey key) throws IOException, GeneralSecurityException, AuthenticationException {
        String sessionUrl = getSessionTokenUrl(protocol, domain);
        URL url = new URL(sessionUrl);
        HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
        String header = formAuthorizationHeader(onetimeUseToken, key, url, "GET");
        httpConn.setRequestProperty("Authorization", header);
        if (httpConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
            throw new AuthenticationException(httpConn.getResponseCode() + ": " + httpConn.getResponseMessage());
        }
        String body = IOUtils.toString(httpConn.getInputStream());
        Map parsedTokens = StringUtils.string2Map(body, "\n", "=", true);
        parsedTokens = StringUtils.lowercaseKeys(parsedTokens);
        return (String) parsedTokens.get("token");
    }
```

## 64fd35c5-044

**A**

```java
public boolean refresh() {
        try {
            synchronized (text) {
                stream = (new URL(url)).openStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                String line;
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
                text = sb.toString();
            }
            price = 0;
            date = null;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (stream != null) try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
```

**B**

```java
boolean getHTML(URL url) {
        html = "";
        int r;
        BufferedInputStream in = null;
        BufferedInputStream imgIn = null;
        boolean retry;
        Vector imageRd = new Vector(0);
        do {
            retry = false;
            try {
                in = new BufferedInputStream(url.openStream(), 4096);
            } catch (IOException ioe) {
                rbe.stats.error("Unable to open URL.", url.toExternalForm());
                ioe.printStackTrace();
                retry = true;
                continue;
            }
            try {
                while ((r = in.read(buffer, 0, buffer.length)) != -1) {
                    if (r > 0) {
                        html = html + new String(buffer, 0, r);
                    }
                }
            } catch (IOException ioe) {
                rbe.stats.error("Unable to read HTML from URL.", url.toExternalForm());
                retry = true;
                continue;
            }
            if (retry) {
                try {
                    if (waitKey) {
                        rbe.getKey();
                    } else {
                        sleep(1000L);
                    }
                } catch (InterruptedException inte) {
                    System.out.println("In getHTML, caught interrupted exception!");
                    return true;
                }
            }
        } while (retry);
        try {
            in.close();
        } catch (IOException ioe) {
            rbe.stats.error("Unable to close URL.", url.toExternalForm());
        }
        if (DEBUG > 0) {
        }
        if (DEBUG > 10) {
            System.out.println(html);
        }
        int cur = 0;
        if (!RBE.getImage) return true;
        findImg(html, url, imgPat, srcPat, quotePat, imageRd);
        findImg(html, url, inputPat, srcPat, quotePat, imageRd);
        if (DEBUG > 2) {
            System.out.println("Found " + imageRd.size() + " images.");
        }
        while (imageRd.size() > 0) {
            int max = imageRd.size();
            int min = Math.max(max - rbe.maxImageRd, 0);
            int i;
            try {
                for (i = min; i < max; i++) {
                    ImageReader rd = (ImageReader) imageRd.elementAt(i);
                    if (!rd.readImage()) {
                        if (DEBUG > 2) {
                            System.out.println("Read " + rd.tot + " bytes from " + rd.imgURLStr);
                        }
                        imageRd.removeElementAt(i);
                        i--;
                        max--;
                    }
                }
            } catch (InterruptedException inte) {
                System.out.println("In getHTML, caught interrupted exception!");
                return true;
            }
        }
        return true;
    }
```

## 64fd35c5-045

**A**

```java
public String getCipherString(String source) throws CadenaNoCifradaException {
        String encryptedSource = null;
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-1");
            byte[] sha1hash = new byte[40];
            md.update(source.getBytes(encoding), 0, source.length());
            sha1hash = md.digest();
            encryptedSource = convertToHex(sha1hash);
        } catch (Exception e) {
            throw new CadenaNoCifradaException(e);
        }
        return encryptedSource;
    }
```

**B**

```java
public static String encrypt(String password) {
        String sign = password;
        try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
            md.update(sign.getBytes());
            byte[] hash = md.digest();
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < hash.length; i++) {
                if ((0xff & hash[i]) < 0x10) hexString.append("0" + Integer.toHexString((0xFF & hash[i]))); else hexString.append(Integer.toHexString(0xFF & hash[i]));
            }
            sign = hexString.toString();
        } catch (Exception nsae) {
            nsae.printStackTrace();
        }
        return sign;
    }
```

## 64fd35c5-046

**A**

```java
public static void copyFile(String source, String dest) throws IOException {
        FileChannel in = null, out = null;
        try {
            in = new FileInputStream(new File(source)).getChannel();
            out = new FileOutputStream(new File(dest)).getChannel();
            in.transferTo(0, in.size(), out);
        } finally {
            if (in != null) in.close();
            if (out != null) out.close();
        }
    }
```

**B**

```java
public java.io.File gzip(java.io.File file) throws Exception {
        java.io.File tmp = null;
        InputStream is = null;
        OutputStream os = null;
        try {
            tmp = java.io.File.createTempFile(file.getName(), ".gz");
            tmp.deleteOnExit();
            is = new BufferedInputStream(new FileInputStream(file));
            os = new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)));
            byte[] buf = new byte[4096];
            int nread = -1;
            while ((nread = is.read(buf)) != -1) {
                os.write(buf, 0, nread);
            }
            os.flush();
        } finally {
            os.close();
            is.close();
        }
        return tmp;
    }
```

## 64fd35c5-047

**A**

```java
public void run() {
            try {
                File outDir = new File(outDirTextField.getText());
                if (!outDir.exists()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "The chosen directory does not exist!", "Directory Not Found Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                if (!outDir.isDirectory()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "The chosen file is not a directory!", "Not a Directory Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                if (!outDir.canWrite()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "Cannot write to the chosen directory!", "Directory Not Writeable Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                File archiveDir = new File("foo.bar").getAbsoluteFile().getParentFile();
                URL baseUrl = UnpackWizard.class.getClassLoader().getResource(UnpackWizard.class.getName().replaceAll("\\.", "/") + ".class");
                if (baseUrl.getProtocol().equals("jar")) {
                    String jarPath = baseUrl.getPath();
                    jarPath = jarPath.substring(0, jarPath.indexOf('!'));
                    if (jarPath.startsWith("file:")) {
                        try {
                            archiveDir = new File(new URI(jarPath)).getAbsoluteFile().getParentFile();
                        } catch (URISyntaxException e1) {
                            e1.printStackTrace(System.err);
                        }
                    }
                }
                SortedMap<Integer, String> inputFileNames = new TreeMap<Integer, String>();
                for (Entry<Object, Object> anEntry : indexProperties.entrySet()) {
                    String key = anEntry.getKey().toString();
                    if (key.startsWith("archive file ")) {
                        inputFileNames.put(Integer.parseInt(key.substring("archive file ".length())), anEntry.getValue().toString());
                    }
                }
                byte[] buff = new byte[64 * 1024];
                try {
                    long bytesToWrite = 0;
                    long bytesReported = 0;
                    long bytesWritten = 0;
                    for (String aFileName : inputFileNames.values()) {
                        File aFile = new File(archiveDir, aFileName);
                        if (aFile.exists()) {
                            if (aFile.isFile()) {
                                bytesToWrite += aFile.length();
                            } else {
                                final File wrongFile = aFile;
                                SwingUtilities.invokeLater(new Runnable() {

                                    public void run() {
                                        JOptionPane.showMessageDialog(UnpackWizard.this, "File \"" + wrongFile.getAbsolutePath() + "\" is not a standard file!", "Non Standard File Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                });
                                return;
                            }
                        } else {
                            final File wrongFile = aFile;
                            SwingUtilities.invokeLater(new Runnable() {

                                public void run() {
                                    JOptionPane.showMessageDialog(UnpackWizard.this, "File \"" + wrongFile.getAbsolutePath() + "\" does not exist!", "File Not Found Error", JOptionPane.ERROR_MESSAGE);
                                }
                            });
                            return;
                        }
                    }
                    MultiFileInputStream mfis = new MultiFileInputStream(archiveDir, inputFileNames.values().toArray(new String[inputFileNames.size()]));
                    TarArchiveInputStream tis = new TarArchiveInputStream(new BufferedInputStream(mfis));
                    TarArchiveEntry tarEntry = tis.getNextTarEntry();
                    while (tarEntry != null) {
                        File outFile = new File(outDir.getAbsolutePath() + "/" + tarEntry.getName());
                        if (outFile.exists()) {
                            final File wrongFile = outFile;
                            SwingUtilities.invokeLater(new Runnable() {

                                public void run() {
                                    JOptionPane.showMessageDialog(UnpackWizard.this, "Was about to write out file \"" + wrongFile.getAbsolutePath() + "\" but it already " + "exists.\nPlease [re]move existing files out of the way " + "and try again.", "File Not Found Error", JOptionPane.ERROR_MESSAGE);
                                }
                            });
                            return;
                        }
                        if (tarEntry.isDirectory()) {
                            outFile.getAbsoluteFile().mkdirs();
                        } else {
                            outFile.getAbsoluteFile().getParentFile().mkdirs();
                            OutputStream os = new BufferedOutputStream(new FileOutputStream(outFile));
                            int len = tis.read(buff, 0, buff.length);
                            while (len != -1) {
                                os.write(buff, 0, len);
                                bytesWritten += len;
                                if (bytesWritten - bytesReported > (10 * 1024 * 1024)) {
                                    bytesReported = bytesWritten;
                                    final int progress = (int) (bytesReported * 100 / bytesToWrite);
                                    SwingUtilities.invokeLater(new Runnable() {

                                        @Override
                                        public void run() {
                                            progressBar.setValue(progress);
                                        }
                                    });
                                }
                                len = tis.read(buff, 0, buff.length);
                            }
                            os.close();
                        }
                        tarEntry = tis.getNextTarEntry();
                    }
                    long expectedCrc = 0;
                    try {
                        expectedCrc = Long.parseLong(indexProperties.getProperty("CRC32", "0"));
                    } catch (NumberFormatException e) {
                        System.err.println("Error while obtaining the expected CRC");
                        e.printStackTrace(System.err);
                    }
                    if (mfis.getCRC() == expectedCrc) {
                        SwingUtilities.invokeLater(new Runnable() {

                            @Override
                            public void run() {
                                progressBar.setValue(0);
                                JOptionPane.showMessageDialog(UnpackWizard.this, "Extraction completed successfully!", "Done!", JOptionPane.INFORMATION_MESSAGE);
                            }
                        });
                        return;
                    } else {
                        System.err.println("CRC Error: was expecting " + expectedCrc + " but got " + mfis.getCRC());
                        SwingUtilities.invokeLater(new Runnable() {

                            public void run() {
                                progressBar.setValue(0);
                                JOptionPane.showMessageDialog(UnpackWizard.this, "CRC Error: the data extracted does not have the expected CRC!\n" + "You should probably delete the extracted files, as they are " + "likely to be invalid.", "CRC Error", JOptionPane.ERROR_MESSAGE);
                            }
                        });
                        return;
                    }
                } catch (final IOException e) {
                    e.printStackTrace(System.err);
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            progressBar.setValue(0);
                            JOptionPane.showMessageDialog(UnpackWizard.this, "Input/Output Error: " + e.getLocalizedMessage(), "Input/Output Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
            } finally {
                SwingUtilities.invokeLater(new Runnable() {

                    public void run() {
                        progressBar.setValue(0);
                        setEnabled(true);
                    }
                });
            }
        }
```

**B**

```java
@Override
        public void testAction(ITestThread testThread) throws Throwable {
            try {
                final InputStream urlIn = new URL("http://jdistunit.sourceforge.net").openStream();
                final int availableBytes = urlIn.available();
                if (0 == availableBytes) {
                    throw new IllegalStateException("Zero bytes on target host.");
                }
                in = new BufferedReader(new InputStreamReader(urlIn));
                String line;
                while (null != (line = in.readLine())) {
                    page.append(line);
                    page.append('\n');
                    if (0 != lineDelay) {
                        OS.sleep(lineDelay);
                    }
                    if (null != testThread && testThread.isActionStopped()) {
                        break;
                    }
                }
            } finally {
                if (null != in) {
                    in.close();
                    in = null;
                }
            }
        }
```

## 64fd35c5-048

**A**

```java
public static Checksum checksum(File file, Checksum checksum) throws IOException {
        if (file.isDirectory()) {
            throw new IllegalArgumentException("Checksums can't be computed on directories");
        }
        InputStream in = null;
        try {
            in = new CheckedInputStream(new FileInputStream(file), checksum);
            IOUtils.copy(in, new OutputStream() {

                @Override
                public void write(byte[] b, int off, int len) {
                }

                @Override
                public void write(int b) {
                }

                @Override
                public void write(byte[] b) throws IOException {
                }
            });
        } finally {
            IOUtils.closeQuietly(in);
        }
        return checksum;
    }
```

**B**

```java
private void copyResource(final String resourceName, final File file) throws IOException {
        assertTrue(resourceName.startsWith("/"));
        InputStream in = null;
        boolean suppressExceptionOnClose = true;
        try {
            in = this.getClass().getResourceAsStream(resourceName);
            assertNotNull("Resource '" + resourceName + "' not found.", in);
            OutputStream out = null;
            try {
                out = new FileOutputStream(file);
                IOUtils.copy(in, out);
                suppressExceptionOnClose = false;
            } finally {
                try {
                    if (out != null) {
                        out.close();
                    }
                } catch (final IOException e) {
                    if (!suppressExceptionOnClose) {
                        throw e;
                    }
                }
            }
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (final IOException e) {
                if (!suppressExceptionOnClose) {
                    throw e;
                }
            }
        }
    }
```

## 64fd35c5-049

**A**

```java
public static File copyFile(String path) {
        File src = new File(path);
        File dest = new File(src.getName());
        try {
            if (!dest.exists()) {
                dest.createNewFile();
            }
            FileChannel source = new FileInputStream(src).getChannel();
            FileChannel destination = new FileOutputStream(dest).getChannel();
            destination.transferFrom(source, 0, source.size());
            source.close();
            destination.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }
```

**B**

```java
public void exportFile() {
        String expfolder = PropertyHandler.getInstance().getProperty(PropertyHandler.KINDLE_EXPORT_FOLDER_KEY);
        File out = new File(expfolder + File.separator + previewInfo.getTitle() + ".prc");
        File f = new File(absPath);
        try {
            FileOutputStream fout = new FileOutputStream(out);
            FileInputStream fin = new FileInputStream(f);
            int read = 0;
            byte[] buffer = new byte[1024 * 1024];
            while ((read = fin.read(buffer)) > 0) {
                fout.write(buffer, 0, read);
            }
            fin.close();
            fout.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

## 64fd35c5-050

**A**

```java
public static void copyFile(File in, File out) {
        try {
            FileChannel sourceChannel = new FileInputStream(in).getChannel();
            FileChannel destinationChannel = new FileOutputStream(out).getChannel();
            sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
            sourceChannel.close();
            destinationChannel.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

**B**

```java
@Override
    public String getPath() {
        InputStream in = null;
        OutputStream out = null;
        File file = null;
        try {
            file = File.createTempFile("java-storage_" + RandomStringUtils.randomAlphanumeric(32), ".tmp");
            file.deleteOnExit();
            out = new FileOutputStream(file);
            in = openStream();
            IOUtils.copy(in, out);
        } catch (IOException e) {
            throw new RuntimeException();
        } finally {
            IOUtils.closeQuietly(in);
            IOUtils.closeQuietly(out);
        }
        if (file != null && file.exists()) {
            return file.getPath();
        }
        return null;
    }
```
