# False-negative audit — 50 pairs (50 per condition, blind)

seed 13, version `phase01-v8`. For each pair decide whether the two fragments implement the **same functionality** (BigCloneBench's clone definition). Write `clone`, `not_clone` or `unsure` in `audit_labels.csv`; do not open `audit_key.csv` until you run `score`.

Rubric: `clone` = same functionality whatever the syntax (Type-1..4, incl. weak T3/T4); `not_clone` = different functionality or one is only a small part of the other; `unsure` = cannot tell in about a minute.

## f73c5234-001

**A**

```java
private void getRandomGUID(boolean secure) throws NoSuchAlgorithmException {
        MessageDigest md5 = null;
        StringBuffer sbValueBeforeMD5 = new StringBuffer();
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Error: " + e);
            throw e;
        }
        try {
            long time = System.currentTimeMillis();
            long rand = 0;
            if (secure) {
                rand = mySecureRand.nextLong();
            } else {
                rand = myRand.nextLong();
            }
            sbValueBeforeMD5.append(s_id);
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(time));
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(rand));
            valueBeforeMD5 = sbValueBeforeMD5.toString();
            md5.update(valueBeforeMD5.getBytes());
            byte[] array = md5.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            valueAfterMD5 = sb.toString();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
```

**B**

```java
public static String md5sum(String s, String alg) {
        try {
            MessageDigest md = MessageDigest.getInstance(alg);
            md.update(s.getBytes(), 0, s.length());
            StringBuffer sb = new StringBuffer();
            synchronized (sb) {
                for (byte b : md.digest()) sb.append(pad(Integer.toHexString(0xFF & b), ZERO.charAt(0), 2, true));
            }
            return sb.toString();
        } catch (Exception ex) {
            log(ex);
        }
        return null;
    }
```

## f73c5234-002

**A**

```java
private static void main(String[] args) {
        try {
            File f = new File("test.txt");
            if (f.exists()) {
                throw new IOException(f + " already exists.  I don't want to overwrite it.");
            }
            StraightStreamReader in;
            char[] cbuf = new char[0x1000];
            int read;
            int totRead;
            FileOutputStream out = new FileOutputStream(f);
            for (int i = 0x00; i < 0x100; i++) {
                out.write(i);
            }
            out.close();
            in = new StraightStreamReader(new FileInputStream(f));
            for (int i = 0x00; i < 0x100; i++) {
                read = in.read();
                if (read != i) {
                    System.err.println("Error: " + i + " read as " + read);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = in.read(cbuf);
            if (totRead != 0x100) {
                System.err.println("Simple buffered read did not read the full amount: 0x" + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead, 0x100 - totRead)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead + 0x123, 0x100 - totRead)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i + 0x123] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i + 0x123]);
                }
            }
            in.close();
            in = new StraightStreamReader(new FileInputStream(f));
            totRead = 0;
            while (totRead <= 0x100 && (read = in.read(cbuf, totRead + 0x123, 7)) > 0) {
                totRead += read;
            }
            if (totRead != 0x100) {
                System.err.println("Not enough read. Bytes read: " + Integer.toHexString(totRead));
            }
            for (int i = 0x00; i < totRead; i++) {
                if (cbuf[i + 0x123] != i) {
                    System.err.println("Error: 0x" + i + " read as 0x" + cbuf[i + 0x123]);
                }
            }
            in.close();
            f.delete();
        } catch (IOException x) {
            System.err.println(x.getMessage());
        }
    }
```

**B**

```java
public static void runDBUpdate() {
        if (!updateRunning) {
            if (updateJob != null) updateJob.cancel();
            updateJob = new Job("Worm Database Update") {

                protected IStatus run(IProgressMonitor monitor) {
                    try {
                        updateRunning = true;
                        distributor = getFromFile("[SERVER]", "csz", getAppPath() + "/server.ini");
                        MAC = getFromFile("[SPECIFICINFO]", "MAC", getAppPath() + "/register.ini");
                        serial = getFromFile("[SPECIFICINFO]", "serial", getAppPath() + "/register.ini");
                        if (MAC.equals("not_found") || serial.equals("not_found") || !serial.startsWith(distributor)) {
                            try {
                                MAC = getFromFile("[SPECIFICINFO]", "MAC", getAppPath() + "/register.ini");
                                serial = getFromFile("[SPECIFICINFO]", "serial", getAppPath() + "/register.ini");
                            } catch (Exception e) {
                                System.out.println(e);
                            }
                        } else {
                            try {
                                url = new URL("http://" + getFromFile("[SERVER]", "url", getAppPath() + "/server.ini"));
                            } catch (MalformedURLException e) {
                                System.out.println(e);
                            }
                            download = "/download2.php?distributor=" + distributor + "&&mac=" + MAC + "&&serial=" + serial;
                            readXML();
                            if (htmlMessage.contains("error")) {
                                try {
                                    PrintWriter pw = new PrintWriter(getAppPath() + "/register.ini");
                                    pw.write("");
                                    pw.close();
                                } catch (IOException e) {
                                    System.out.println(e);
                                }
                                setProperty(IProgressConstants.ICON_PROPERTY, IconImg.liveUpIco);
                                if (isModal(this)) {
                                    showResults2();
                                } else {
                                    setProperty(IProgressConstants.KEEP_PROPERTY, Boolean.TRUE);
                                    setProperty(IProgressConstants.ACTION_PROPERTY, getUpdateCompletedAction2());
                                }
                            } else {
                                if (!getDBVersion().equals(latestVersion)) {
                                    try {
                                        OutputStream out = null;
                                        HttpURLConnection conn = null;
                                        InputStream in = null;
                                        int size;
                                        try {
                                            URL url = new URL(fileLoc);
                                            String outFile = getAppPath() + "/temp/" + getFileName(url);
                                            File oFile = new File(outFile);
                                            oFile.delete();
                                            out = new BufferedOutputStream(new FileOutputStream(outFile));
                                            monitor.beginTask("Connecting to NWD Server", 100);
                                            conn = (HttpURLConnection) url.openConnection();
                                            conn.setConnectTimeout(20000);
                                            conn.connect();
                                            if (conn.getResponseCode() / 100 != 2) {
                                                System.out.println("Error: " + conn.getResponseCode());
                                                return null;
                                            }
                                            monitor.worked(100);
                                            monitor.done();
                                            size = conn.getContentLength();
                                            monitor.beginTask("Download Worm Definition", size);
                                            in = conn.getInputStream();
                                            byte[] buffer;
                                            String downloadedSize;
                                            long numWritten = 0;
                                            boolean status = true;
                                            while (status) {
                                                if (size - numWritten > 1024) {
                                                    buffer = new byte[1024];
                                                } else {
                                                    buffer = new byte[(int) (size - numWritten)];
                                                }
                                                int read = in.read(buffer);
                                                if (read == -1) {
                                                    break;
                                                }
                                                out.write(buffer, 0, read);
                                                numWritten += read;
                                                downloadedSize = Long.toString(numWritten / 1024) + " KB";
                                                monitor.worked(read);
                                                monitor.subTask(downloadedSize + " of " + Integer.toString(size / 1024) + " KB");
                                                if (size == numWritten) {
                                                    status = false;
                                                }
                                                if (monitor.isCanceled()) return Status.CANCEL_STATUS;
                                            }
                                            if (in != null) {
                                                in.close();
                                            }
                                            if (out != null) {
                                                out.close();
                                            }
                                            try {
                                                ZipFile zFile = new ZipFile(outFile);
                                                Enumeration all = zFile.entries();
                                                while (all.hasMoreElements()) {
                                                    ZipEntry zEntry = (ZipEntry) all.nextElement();
                                                    long zSize = zEntry.getSize();
                                                    if (zSize > 0) {
                                                        if (zEntry.getName().endsWith("script")) {
                                                            InputStream instream = zFile.getInputStream(zEntry);
                                                            FileOutputStream fos = new FileOutputStream(oldLoc[0]);
                                                            int ch;
                                                            while ((ch = instream.read()) != -1) {
                                                                fos.write(ch);
                                                            }
                                                            instream.close();
                                                            fos.close();
                                                        } else if (zEntry.getName().endsWith("data")) {
                                                            InputStream instream = zFile.getInputStream(zEntry);
                                                            FileOutputStream fos = new FileOutputStream(oldLoc[1]);
                                                            int ch;
                                                            while ((ch = instream.read()) != -1) {
                                                                fos.write(ch);
                                                            }
                                                            instream.close();
                                                            fos.close();
                                                        }
                                                    }
                                                }
                                                File xFile = new File(outFile);
                                                xFile.deleteOnExit();
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            try {
                                                monitor.done();
                                                monitor.beginTask("Install Worm Definition", 10000);
                                                monitor.worked(2500);
                                                CorePlugin.getDefault().getRawPacketHandler().removeRawPacketListener(p);
                                                p = null;
                                                if (!wormDB.getConn().isClosed()) {
                                                    shutdownDB();
                                                }
                                                System.out.println(wormDB.getConn().isClosed());
                                                for (int i = 0; i < 2; i++) {
                                                    try {
                                                        Process pid = Runtime.getRuntime().exec("cmd /c copy \"" + oldLoc[i].replace("/", "\\") + "\" \"" + newLoc[i].replace("/", "\\") + "\"/y");
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                    new File(oldLoc[i]).deleteOnExit();
                                                }
                                                monitor.worked(2500);
                                                initialArray();
                                                p = new PacketPrinter();
                                                CorePlugin.getDefault().getRawPacketHandler().addRawPacketListener(p);
                                                monitor.worked(2500);
                                                monitor.done();
                                                setProperty(IProgressConstants.ICON_PROPERTY, IconImg.liveUpIco);
                                                if (isModal(this)) {
                                                    showResults();
                                                } else {
                                                    setProperty(IProgressConstants.KEEP_PROPERTY, Boolean.TRUE);
                                                    setProperty(IProgressConstants.ACTION_PROPERTY, getUpdateCompletedAction());
                                                }
                                            } catch (Exception e) {
                                                setProperty(IProgressConstants.ICON_PROPERTY, IconImg.liveUpIco);
                                                if (isModal(this)) {
                                                    showResults2();
                                                } else {
                                                    setProperty(IProgressConstants.KEEP_PROPERTY, Boolean.TRUE);
                                                    setProperty(IProgressConstants.ACTION_PROPERTY, getUpdateCompletedAction2());
                                                }
                                                System.out.println(e);
                                            } finally {
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    } catch (Exception e) {
                                        setProperty(IProgressConstants.ICON_PROPERTY, IconImg.liveUpIco);
                                        if (isModal(this)) {
                                            showResults2();
                                        } else {
                                            setProperty(IProgressConstants.KEEP_PROPERTY, Boolean.TRUE);
                                            setProperty(IProgressConstants.ACTION_PROPERTY, getUpdateCompletedAction2());
                                        }
                                        e.printStackTrace();
                                    }
                                } else {
                                    cancel();
                                    setProperty(IProgressConstants.ICON_PROPERTY, IconImg.liveUpIco);
                                    if (isModal(this)) {
                                        showResults1();
                                    } else {
                                        setProperty(IProgressConstants.KEEP_PROPERTY, Boolean.TRUE);
                                        setProperty(IProgressConstants.ACTION_PROPERTY, getUpdateCompletedAction1());
                                    }
                                }
                            }
                        }
                        return Status.OK_STATUS;
                    } catch (Exception e) {
                        showResults2();
                        return Status.OK_STATUS;
                    } finally {
                        lock.release();
                        updateRunning = false;
                        if (getValue("AUTO_UPDATE")) schedule(10800000);
                    }
                }
            };
            updateJob.schedule();
        }
    }
```

## f73c5234-003

**A**

```java
public static void main(String[] args) throws IOException {
        String uri = "hdfs://localhost:8020/user/leeing/maxtemp/sample.txt";
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(URI.create(uri), conf);
        FSDataInputStream in = null;
        try {
            in = fs.open(new Path(uri));
            IOUtils.copyBytes(in, System.out, 8192, false);
            System.out.println("\n");
            in.seek(0);
            IOUtils.copyBytes(in, System.out, 8192, false);
        } finally {
            IOUtils.closeStream(in);
        }
    }
```

**B**

```java
public void sendContent(OutputStream out, Range range, Map<String, String> params, String contentType) throws IOException {
        LOGGER.debug("DOWNLOAD - Send content: " + realFile.getAbsolutePath());
        LOGGER.debug("Output stream: " + out.toString());
        if (ServerConfiguration.isDynamicSEL()) {
            LOGGER.error("IS DINAMIC SEL????");
        } else {
        }
        if (".tokens".equals(realFile.getName()) || ".response".equals(realFile.getName()) || ".request".equals(realFile.getName()) || isAllowedClient) {
            FileInputStream in = null;
            try {
                in = new FileInputStream(realFile);
                int bytes = IOUtils.copy(in, out);
                LOGGER.debug("System resource or Allowed Client wrote bytes:  " + bytes);
                out.flush();
            } catch (Exception e) {
                LOGGER.error("Error while downloading over encryption system " + realFile.getName() + " file", e);
            } finally {
                IOUtils.closeQuietly(in);
            }
        } else {
        }
    }
```

## f73c5234-004

**A**

```java
private String fetchHTML(String s) {
        String str;
        StringBuffer sb = new StringBuffer();
        try {
            URL url = new URL(s);
            InputStream is = url.openStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            while ((str = br.readLine()) != null) {
                sb.append(str);
            }
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
        return sb.toString();
    }
```

**B**

```java
private static List<InputMethodDescriptor> loadIMDescriptors() {
        String nm = SERVICES + InputMethodDescriptor.class.getName();
        Enumeration<URL> en;
        LinkedList<InputMethodDescriptor> imdList = new LinkedList<InputMethodDescriptor>();
        NativeIM nativeIM = ContextStorage.getNativeIM();
        imdList.add(nativeIM);
        try {
            en = ClassLoader.getSystemResources(nm);
            ClassLoader cl = ClassLoader.getSystemClassLoader();
            while (en.hasMoreElements()) {
                URL url = en.nextElement();
                InputStreamReader isr = new InputStreamReader(url.openStream(), "UTF-8");
                BufferedReader br = new BufferedReader(isr);
                String str = br.readLine();
                while (str != null) {
                    str = str.trim();
                    int comPos = str.indexOf("#");
                    if (comPos >= 0) {
                        str = str.substring(0, comPos);
                    }
                    if (str.length() > 0) {
                        imdList.add((InputMethodDescriptor) cl.loadClass(str).newInstance());
                    }
                    str = br.readLine();
                }
            }
        } catch (Exception e) {
        }
        return imdList;
    }
```

## f73c5234-005

**A**

```java
public static void copy(String srcFileName, String destFileName) throws IOException {
        if (srcFileName == null) {
            throw new IllegalArgumentException("srcFileName is null");
        }
        if (destFileName == null) {
            throw new IllegalArgumentException("destFileName is null");
        }
        FileChannel src = null;
        FileChannel dest = null;
        try {
            src = new FileInputStream(srcFileName).getChannel();
            dest = new FileOutputStream(destFileName).getChannel();
            long n = src.size();
            MappedByteBuffer buf = src.map(FileChannel.MapMode.READ_ONLY, 0, n);
            dest.write(buf);
        } finally {
            if (dest != null) {
                try {
                    dest.close();
                } catch (IOException e1) {
                }
            }
            if (src != null) {
                try {
                    src.close();
                } catch (IOException e1) {
                }
            }
        }
    }
```

**B**

```java
@SuppressWarnings("finally")
  private void decompress(final File src) throws IOException
  {
    final String srcPath = src.getPath();
    checkSourceFile(src);
    final boolean test = this.switches.contains(Switch.test);

    final File dst;
    if (test)
      dst = File.createTempFile("jaxlib-bzip", null);
    else
    {
      if (srcPath.endsWith(".bz2"))
        dst = new File(srcPath.substring(0, srcPath.length() - 4));
      else
      {
        this.log.println("WARNING: Can't guess original name, using extension \".out\":").println(srcPath);
        dst = new File(srcPath + ".out");
      }
    }
    if (!checkDestFile(dst))
      return;

    final boolean showProgress = this.switches.contains(Switch.showProgress);

    BZip2InputStream  in          = null;
    FileOutputStream  out         = null;
    FileChannel       outChannel  = null;
    FileLock          inLock      = null;
    FileLock          outLock     = null;

    try
    {
      final FileInputStream in0       = new FileInputStream(src);
      final FileChannel     inChannel = in0.getChannel();
      final long            inSize    = inChannel.size();

      inLock = inChannel.tryLock(0, inSize, true);
      if (inLock == null)
        throw error("source file locked by another process: " + src);

      in          = new BZip2InputStream(new BufferedXInputStream(in0, 8192));
      out         = new FileOutputStream(dst);
      outChannel  = out.getChannel();

      outLock = outChannel.tryLock();
      if (outLock == null)
        throw error("destination file locked by another process: " + dst);

      if (showProgress || this.verbose)
      {
        this.log.print("source: " + src).print(": size=").println(inSize);
        this.log.println("target: " + dst);
      }

      long  pos       = 0;
      int   progress  = 0;
      final long maxStep = showProgress ? Math.max(8192, inSize / MAX_PROGRESS) : Integer.MAX_VALUE;

      while (true)
      {
        final long step = outChannel.transferFrom(in, pos, maxStep);
        if (step <= 0)
        {
          final long a = inChannel.size();
          if (a != inSize)
            throw error("file " + src + " has been modified concurrently by another process");

          if (inChannel.position() >= inSize)
          {
            if (showProgress)
            {
              for (int i = progress; i < MAX_PROGRESS; i++)
                this.log.print('#');
              this.log.println(" done");
            }
            break;
          }
        }
        else
        {
          pos += step;
          if (showProgress)
          {
            final double  p           = (double) inChannel.position() / (double) inSize;
            final int     newProgress = (int) (MAX_PROGRESS * p);
            for (int i = progress; i < newProgress; i++)
              this.log.print('#');
            progress = newProgress;
          }
        }
      }

      final long outSize = outChannel.size();
      in.close();
      out.close();

      if (this.verbose)
      {
        final double ratio = (outSize == 0) ? (inSize * 100) : ((double) inSize / (double) outSize);
        this.log.print("compressed size: ").print(inSize)
          .print("; decompressed size: ").print(outSize)
          .print("; compression ratio: ").print(ratio).println('%');
      }

      if (!test && !this.switches.contains(Switch.keep))
      {
        if (!src.delete())
          throw error("unable to delete sourcefile: " + src);
      }

      if (test && !dst.delete())
        throw error("unable to delete testfile: " + dst);
    }
    catch (final IOException ex)
    {
      IO.tryClose(in);
      IO.tryClose(out);
      IO.tryRelease(inLock);
      IO.tryRelease(outLock);
      try
      {
        this.log.println();
      }
      finally
      {
        throw ex;
      }
    }

  }
```

## f73c5234-006

**A**

```java
private String generateCode(String seed) {
        try {
            Security.addProvider(new FNVProvider());
            MessageDigest digest = MessageDigest.getInstance("FNV-1a");
            digest.update((seed + UUID.randomUUID().toString()).getBytes());
            byte[] hash1 = digest.digest();
            String sHash1 = "m" + (new String(LibraryBase64.encode(hash1))).replaceAll("=", "").replaceAll("-", "_");
            return sHash1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
```

**B**

```java
public static String encrypt(String passPhrase, String password) {
        String algorithm = "PBEWithMD5AndDES";
        byte[] salt = new byte[8];
        int iterations = 20;
        byte[] output = new byte[128];
        if (passPhrase == null || "".equals(passPhrase) || password == null || "".equals(password)) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "Required parameter missing");
        }
        try {
            Security.addProvider(new com.sun.crypto.provider.SunJCE());
            KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray());
            SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance(algorithm);
            SecretKey secretKey = secretKeyFactory.generateSecret(keySpec);
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(passPhrase.getBytes());
            byte[] input = new byte[password.length()];
            input = password.getBytes();
            messageDigest.update(input);
            byte[] digest = messageDigest.digest();
            System.arraycopy(digest, 0, salt, 0, 8);
            AlgorithmParameterSpec algorithmParameterSpec = new PBEParameterSpec(salt, iterations);
            Cipher cipher = Cipher.getInstance(algorithm);
            int mode = Cipher.ENCRYPT_MODE;
            cipher.init(mode, secretKey, algorithmParameterSpec);
            output = cipher.doFinal(input);
        } catch (NoSuchAlgorithmException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "Algorithm not found", e);
        } catch (InvalidAlgorithmParameterException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "nvalidAlgorithmParameter", e);
        } catch (InvalidKeySpecException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "InvalidKeySpec", e);
        } catch (InvalidKeyException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "InvalidKey", e);
        } catch (NoSuchPaddingException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "NoSuchPadding", e);
        } catch (BadPaddingException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "BadPadding", e);
        } catch (IllegalBlockSizeException e) {
            throw new GeneralException(PassPhraseCrypto.class, "encrypt", "IllegalBlockSize", e);
        }
        StringBuffer result = new StringBuffer();
        for (int i = 0; i < output.length; i++) {
            result.append(Byte.toString(output[i]));
        }
        return result.toString();
    }
```

## f73c5234-007

**A**

```java
private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws IOException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new IOException("Destination '" + destFile + "' exists but is a directory");
        }
        FileInputStream input = new FileInputStream(srcFile);
        try {
            FileOutputStream output = new FileOutputStream(destFile);
            try {
                IOUtils.copy(input, output);
            } finally {
                IOUtils.closeQuietly(output);
            }
        } finally {
            IOUtils.closeQuietly(input);
        }
        if (srcFile.length() != destFile.length()) {
            throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "'");
        }
        if (preserveFileDate) {
            destFile.setLastModified(srcFile.lastModified());
        }
    }
```

**B**

```java
public void copyFile(String source_name, String dest_name) throws IOException {
        File source_file = new File(source_name);
        File destination_file = new File(dest_name);
        FileInputStream source = null;
        FileOutputStream destination = null;
        byte[] buffer;
        int bytes_read;
        try {
            if (!source_file.exists() || !source_file.isFile()) throw new FileCopyException(MM.PHRASES.getPhrase("25") + " " + source_name);
            if (!source_file.canRead()) throw new FileCopyException(MM.PHRASES.getPhrase("26") + " " + MM.PHRASES.getPhrase("27") + ": " + source_name);
            if (destination_file.exists()) {
                if (destination_file.isFile()) {
                    DataInputStream in = new DataInputStream(System.in);
                    String response;
                    if (!destination_file.canWrite()) throw new FileCopyException(MM.PHRASES.getPhrase("28") + " " + MM.PHRASES.getPhrase("29") + ": " + dest_name);
                    System.out.print(MM.PHRASES.getPhrase("19") + dest_name + MM.PHRASES.getPhrase("30") + ": ");
                    System.out.flush();
                    response = in.readLine();
                    if (!response.equals("Y") && !response.equals("y")) throw new FileCopyException(MM.PHRASES.getPhrase("31"));
                } else throw new FileCopyException(MM.PHRASES.getPhrase("28") + " " + MM.PHRASES.getPhrase("32") + ": " + dest_name);
            } else {
                File parentdir = parent(destination_file);
                if (!parentdir.exists()) throw new FileCopyException(MM.PHRASES.getPhrase("28") + " " + MM.PHRASES.getPhrase("33") + ": " + dest_name);
                if (!parentdir.canWrite()) throw new FileCopyException(MM.PHRASES.getPhrase("28") + " " + MM.PHRASES.getPhrase("34") + ": " + dest_name);
            }
            source = new FileInputStream(source_file);
            destination = new FileOutputStream(destination_file);
            buffer = new byte[1024];
            while (true) {
                bytes_read = source.read(buffer);
                if (bytes_read == -1) break;
                destination.write(buffer, 0, bytes_read);
            }
        } finally {
            if (source != null) try {
                source.close();
            } catch (IOException e) {
                ;
            }
            if (destination != null) try {
                destination.close();
            } catch (IOException e) {
                ;
            }
        }
    }
```

## f73c5234-008

**A**

```java
private String convert(InputStream input, String encoding) throws Exception {
        Process p = Runtime.getRuntime().exec("tidy -q -f /dev/null -wrap 0 --output-xml yes --doctype omit --force-output true --new-empty-tags  " + emptyTags + " --quote-nbsp no -utf8");
        Thread t = new CopyThread(input, p.getOutputStream());
        t.start();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        IOUtils.copy(p.getInputStream(), output);
        p.waitFor();
        t.join();
        return output.toString();
    }
```

**B**

```java
private static <OS extends OutputStream> OS getUnzipAndDecodeOutputStream(InputStream inputStream, final OS outputStream) {
        final PipedOutputStream pipedOutputStream = new PipedOutputStream();
        final List<Throwable> ungzipThreadThrowableList = new LinkedList<Throwable>();
        Writer decoderWriter = null;
        Thread ungzipThread = null;
        try {
            final PipedInputStream pipedInputStream = new PipedInputStream(pipedOutputStream);
            ungzipThread = new Thread(new Runnable() {

                public void run() {
                    GZIPInputStream gzipInputStream = null;
                    try {
                        gzipInputStream = new GZIPInputStream(pipedInputStream);
                        IOUtils.copy(gzipInputStream, outputStream);
                    } catch (Throwable t) {
                        ungzipThreadThrowableList.add(t);
                    } finally {
                        IOUtils.closeQuietly(gzipInputStream);
                        IOUtils.closeQuietly(pipedInputStream);
                    }
                }
            });
            decoderWriter = Base64.newDecoder(pipedOutputStream);
            ungzipThread.start();
            IOUtils.copy(inputStream, decoderWriter, DVK_MESSAGE_CHARSET);
            decoderWriter.flush();
            pipedOutputStream.flush();
        } catch (IOException e) {
            throw new RuntimeException("failed to unzip and decode input", e);
        } finally {
            IOUtils.closeQuietly(decoderWriter);
            IOUtils.closeQuietly(pipedOutputStream);
            if (ungzipThread != null) {
                try {
                    ungzipThread.join();
                } catch (InterruptedException ie) {
                    throw new RuntimeException("thread interrupted while for ungzip thread to finish", ie);
                }
            }
        }
        if (!ungzipThreadThrowableList.isEmpty()) {
            throw new RuntimeException("ungzip failed", ungzipThreadThrowableList.get(0));
        }
        return outputStream;
    }
```

## f73c5234-009

**A**

```java
private void documentFileChooserActionPerformed(java.awt.event.ActionEvent evt) {
        if (evt.getActionCommand().equals(JFileChooser.APPROVE_SELECTION)) {
            File selectedFile = documentFileChooser.getSelectedFile();
            File collectionCopyFile;
            String newDocumentName = selectedFile.getName();
            Document newDocument = new Document(newDocumentName);
            if (activeCollection.containsDocument(newDocument)) {
                int matchingFilenameDistinguisher = 1;
                StringBuilder distinguisherReplacer = new StringBuilder();
                newDocumentName = newDocumentName.concat("(" + matchingFilenameDistinguisher + ")");
                newDocument.setDocumentName(newDocumentName);
                while (activeCollection.containsDocument(newDocument)) {
                    matchingFilenameDistinguisher++;
                    newDocumentName = distinguisherReplacer.replace(newDocumentName.length() - 2, newDocumentName.length() - 1, new Integer(matchingFilenameDistinguisher).toString()).toString();
                    newDocument.setDocumentName(newDocumentName);
                }
            }
            Scanner tokenizer = null;
            FileChannel fileSource = null;
            FileChannel collectionDestination = null;
            HashMap<String, Integer> termHashMap = new HashMap<String, Integer>();
            Index collectionIndex = activeCollection.getIndex();
            int documentTermMaxFrequency = 0;
            int currentTermFrequency;
            try {
                tokenizer = new Scanner(new BufferedReader(new FileReader(selectedFile)));
                tokenizer.useDelimiter(Pattern.compile("\\p{Space}|\\p{Punct}|\\p{Cntrl}"));
                String nextToken;
                while (tokenizer.hasNext()) {
                    nextToken = tokenizer.next().toLowerCase();
                    if (!nextToken.isEmpty()) if (termHashMap.containsKey(nextToken)) termHashMap.put(nextToken, termHashMap.get(nextToken) + 1); else termHashMap.put(nextToken, 1);
                }
                Term newTerm;
                for (String term : termHashMap.keySet()) {
                    newTerm = new Term(term);
                    if (!collectionIndex.termExists(newTerm)) collectionIndex.addTerm(newTerm);
                    currentTermFrequency = termHashMap.get(term);
                    if (currentTermFrequency > documentTermMaxFrequency) documentTermMaxFrequency = currentTermFrequency;
                    collectionIndex.addOccurence(newTerm, newDocument, currentTermFrequency);
                }
                activeCollection.addDocument(newDocument);
                String userHome = System.getProperty("user.home");
                String fileSeparator = System.getProperty("file.separator");
                collectionCopyFile = new File(userHome + fileSeparator + "Infrared" + fileSeparator + activeCollection.getDocumentCollectionName() + fileSeparator + newDocumentName);
                collectionCopyFile.createNewFile();
                fileSource = new FileInputStream(selectedFile).getChannel();
                collectionDestination = new FileOutputStream(collectionCopyFile).getChannel();
                collectionDestination.transferFrom(fileSource, 0, fileSource.size());
            } catch (FileNotFoundException e) {
                System.err.println(e.getMessage() + " This error should never occur! The file was just selected!");
                return;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "An I/O error occured during file transfer!", "File transfer I/O error", JOptionPane.WARNING_MESSAGE);
                return;
            } finally {
                try {
                    if (tokenizer != null) tokenizer.close();
                    if (fileSource != null) fileSource.close();
                    if (collectionDestination != null) collectionDestination.close();
                } catch (IOException e) {
                    System.err.println(e.getMessage());
                }
            }
            processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
        } else if (evt.getActionCommand().equalsIgnoreCase(JFileChooser.CANCEL_SELECTION)) processWindowEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    }
```

**B**

```java
@Override
    public DataUpdateResult<Record> archiveRecord(String authToken, Record record, Filter filter, Field sourceField, InputModel inputmodel) throws DataOperationException {
        validateUserIsSignedOn(authToken);
        validateUserHasAdminRights(authToken);
        DataUpdateResult<Record> recordUpdateResult = new DataUpdateResult<Record>();
        if (record != null) {
            Connection connection = null;
            boolean archived = false;
            try {
                long userId = getSignedOnUser(authToken).getUserId();
                connection = DatabaseConnector.getConnection();
                connection.setAutoCommit(false);
                recordUpdateResult.setMessage(messages.server_record_delete_success(""));
                recordUpdateResult.setSuccessful(true);
                String sql = "update tms.records set archivedtimestamp = now() where recordid = ?";
                PreparedStatement updateRecord = connection.prepareStatement(sql);
                updateRecord.setLong(1, record.getRecordid());
                int recordArchived = 0;
                recordArchived = updateRecord.executeUpdate();
                if (recordArchived > 0) AuditTrailManager.updateAuditTrail(connection, AuditTrailManager.createAuditTrailEvent(record, userId, AuditableEvent.EVENTYPE_DELETE), authToken, getSession());
                TopicUpdateServiceImpl.archiveRecordTopics(connection, record.getTopics(), record.getRecordid());
                ArrayList<RecordAttribute> recordAttributes = record.getRecordattributes();
                if (recordAttributes != null && recordAttributes.size() > 0) {
                    Iterator<RecordAttribute> rItr = recordAttributes.iterator();
                    while (rItr.hasNext()) {
                        RecordAttribute r = rItr.next();
                        String rAtSql = "update tms.recordattributes set archivedtimestamp = now() where recordattributeid = ?";
                        PreparedStatement updateRecordAttribute = connection.prepareStatement(rAtSql);
                        updateRecordAttribute.setLong(1, r.getRecordattributeid());
                        int recordAttribArchived = 0;
                        recordAttribArchived = updateRecordAttribute.executeUpdate();
                        if (recordAttribArchived > 0) AuditTrailManager.updateAuditTrail(connection, AuditTrailManager.createAuditTrailEvent(r, userId, AuditableEvent.EVENTYPE_DELETE), authToken, getSession());
                    }
                }
                ArrayList<Term> terms = record.getTerms();
                Iterator<Term> termsItr = terms.iterator();
                while (termsItr.hasNext()) {
                    Term term = termsItr.next();
                    TermUpdater.archiveTerm(connection, term, userId, authToken, getSession());
                }
                connection.commit();
                archived = true;
                if (filter != null) RecordIdTracker.refreshRecordIdsInSessionByFilter(this.getThreadLocalRequest().getSession(), connection, true, filter, sourceField, authToken); else RecordIdTracker.refreshRecordIdsInSession(this.getThreadLocalRequest().getSession(), connection, false, authToken);
                RecordRetrievalServiceImpl retriever = new RecordRetrievalServiceImpl();
                RecordIdTracker.refreshRecordIdsInSession(this.getThreadLocalRequest().getSession(), connection, false, authToken);
                Record updatedRecord = retriever.retrieveRecordByRecordId(initSignedOnUser(authToken), record.getRecordid(), this.getThreadLocalRequest().getSession(), false, inputmodel, authToken);
                recordUpdateResult.setResult(updatedRecord);
            } catch (Exception e) {
                if (!archived && connection != null) {
                    try {
                        connection.rollback();
                    } catch (SQLException e1) {
                        LogUtility.log(Level.SEVERE, getSession(), messages.log_db_rollback(""), e1, authToken);
                        e1.printStackTrace();
                    }
                }
                recordUpdateResult.setFailed(true);
                if (archived) {
                    recordUpdateResult.setMessage(messages.server_record_delete_retrieve(""));
                    recordUpdateResult.setException(e);
                    LogUtility.log(Level.SEVERE, getSession(), messages.server_record_delete_retrieve(""), e, authToken);
                } else {
                    recordUpdateResult.setMessage(messages.server_record_delete_fail(""));
                    recordUpdateResult.setException(new PersistenceException(e));
                    LogUtility.log(Level.SEVERE, getSession(), messages.server_record_delete_fail(""), e, authToken);
                }
                GWT.log(recordUpdateResult.getMessage(), e);
            } finally {
                try {
                    if (connection != null) {
                        connection.setAutoCommit(true);
                        connection.close();
                    }
                } catch (Exception e) {
                    LogUtility.log(Level.SEVERE, getSession(), messages.log_db_close(""), e, authToken);
                }
            }
        }
        return recordUpdateResult;
    }
```

## f73c5234-010

**A**

```java
public ClientDTO changePassword(String pMail, String pMdp) {
        Client vClientBean = null;
        ClientDTO vClientDTO = null;
        vClientBean = mClientDao.getClient(pMail);
        if (vClientBean != null) {
            MessageDigest vMd5Instance;
            try {
                vMd5Instance = MessageDigest.getInstance("MD5");
                vMd5Instance.reset();
                vMd5Instance.update(pMdp.getBytes());
                byte[] vDigest = vMd5Instance.digest();
                BigInteger vBigInt = new BigInteger(1, vDigest);
                String vHashPassword = vBigInt.toString(16);
                vClientBean.setMdp(vHashPassword);
                vClientDTO = BeanToDTO.getInstance().createClientDTO(vClientBean);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        return vClientDTO;
    }
```

**B**

```java
public void processSaveCompany(Company companyBean, AuthSession authSession) {
        if (authSession == null) {
            return;
        }
        DatabaseAdapter dbDyn = null;
        PreparedStatement ps = null;
        try {
            dbDyn = DatabaseAdapter.getInstance();
            String sql = "UPDATE WM_LIST_COMPANY " + "SET " + "	full_name = ?, " + "	short_name = ?, " + "	address = ?, " + "	telefon_buh = ?, " + "	telefon_chief = ?, " + "	chief = ?, " + "	buh = ?, " + "	fax = ?, " + "	email = ?, " + "	icq = ?, " + "	short_client_info = ?, " + "	url = ?, " + "	short_info = ? " + "WHERE ID_FIRM = ? and ID_FIRM in ";
            switch(dbDyn.getFamaly()) {
                case DatabaseManager.MYSQL_FAMALY:
                    String idList = authSession.getGrantedCompanyId();
                    sql += " (" + idList + ") ";
                    break;
                default:
                    sql += "(select z1.ID_FIRM from v$_read_list_firm z1 where z1.user_login = ?)";
                    break;
            }
            ps = dbDyn.prepareStatement(sql);
            int num = 1;
            ps.setString(num++, companyBean.getName());
            ps.setString(num++, companyBean.getShortName());
            ps.setString(num++, companyBean.getAddress());
            ps.setString(num++, "");
            ps.setString(num++, "");
            ps.setString(num++, companyBean.getCeo());
            ps.setString(num++, companyBean.getCfo());
            ps.setString(num++, "");
            ps.setString(num++, "");
            RsetTools.setLong(ps, num++, null);
            ps.setString(num++, "");
            ps.setString(num++, companyBean.getWebsite());
            ps.setString(num++, companyBean.getInfo());
            RsetTools.setLong(ps, num++, companyBean.getId());
            switch(dbDyn.getFamaly()) {
                case DatabaseManager.MYSQL_FAMALY:
                    break;
                default:
                    ps.setString(num++, authSession.getUserLogin());
                    break;
            }
            int i1 = ps.executeUpdate();
            if (log.isDebugEnabled()) log.debug("Count of updated record - " + i1);
            dbDyn.commit();
        } catch (Exception e) {
            try {
                if (dbDyn != null) dbDyn.rollback();
            } catch (Exception e001) {
            }
            String es = "Error save company";
            log.error(es, e);
            throw new IllegalStateException(es, e);
        } finally {
            DatabaseManager.close(dbDyn, ps);
            dbDyn = null;
            ps = null;
        }
    }
```

## f73c5234-011

**A**

```java
public static boolean copy(File source, File target) {
        try {
            if (!source.exists()) return false;
            target.getParentFile().mkdirs();
            InputStream input = new FileInputStream(source);
            OutputStream output = new FileOutputStream(target);
            byte[] buf = new byte[1024];
            int len;
            while ((len = input.read(buf)) > 0) output.write(buf, 0, len);
            input.close();
            output.close();
            return true;
        } catch (Exception exc) {
            exc.printStackTrace();
            return false;
        }
    }
```

**B**

```java
public static void createZipFromDataset(String localResourceId, File dataset, File metadata) {
        CommunicationLogger.warning("System entered ZipFactory");
        try {
            String tmpDir = System.getProperty("java.io.tmpdir");
            String outFilename = tmpDir + "/" + localResourceId + ".zip";
            CommunicationLogger.warning("File name: " + outFilename);
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));
            byte[] buf = new byte[1024];
            FileInputStream in = new FileInputStream(dataset);
            out.putNextEntry(new ZipEntry(dataset.getName()));
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in = new FileInputStream(metadata);
            out.putNextEntry(new ZipEntry(metadata.getName()));
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            out.closeEntry();
            in.close();
            out.close();
        } catch (IOException e) {
            System.out.println("IO EXCEPTION: " + e.getMessage());
        }
    }
```

## f73c5234-012

**A**

```java
@Test
    public void testWrite() throws Exception {
        MrstkXmlFileReader reader = new MrstkXmlFileReader();
        reader.setFileName("..//data//MrstkXML//prototype3.xml");
        reader.read();
        SpectrumArray sp = reader.getOutput();
        File tmp = File.createTempFile("mrstktest", ".xml");
        System.out.println("Writing temp file: " + tmp.getAbsolutePath());
        MrstkXmlFileWriter writer = new MrstkXmlFileWriter(sp);
        writer.setFile(tmp);
        writer.write();
        MrstkXmlFileReader reader2 = new MrstkXmlFileReader();
        reader2.setFileName(writer.getFile().getAbsolutePath());
        reader2.read();
        SpectrumArray sp2 = reader2.getOutput();
        assertTrue(sp.equals(sp2));
    }
```

**B**

```java
private File sendQuery(String query) throws MusicBrainzException {
        File xmlServerResponse = null;
        try {
            xmlServerResponse = new File(SERVER_RESPONSE_FILE);
            long start = Calendar.getInstance().getTimeInMillis();
            System.out.println("\n\n++++++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("    consulta de busqueda -> " + query);
            URL url = new URL(query);
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String response = "";
            String line = "";
            System.out.println("    Respuesta del servidor: \n");
            while ((line = in.readLine()) != null) {
                response += line;
            }
            xmlServerResponse = new File(SERVER_RESPONSE_FILE);
            System.out.println("    Ruta del archivo XML -> " + xmlServerResponse.getAbsolutePath());
            BufferedWriter out = new BufferedWriter(new FileWriter(xmlServerResponse));
            out.write(response);
            out.close();
            System.out.println("Tamanho del xmlFile -> " + xmlServerResponse.length());
            long ahora = (Calendar.getInstance().getTimeInMillis() - start);
            System.out.println(" Tiempo transcurrido en la consulta (en milesimas) -> " + ahora);
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++\n\n");
        } catch (IOException e) {
            e.printStackTrace();
            String msg = e.getMessage();
            if (e instanceof FileNotFoundException) {
                msg = "ERROR: MusicBrainz URL used is not found:\n" + msg;
            } else {
            }
            throw new MusicBrainzException(msg);
        }
        return xmlServerResponse;
    }
```

## f73c5234-013

**A**

```java
private void getRandomGUID(boolean secure) {
        MessageDigest md5 = null;
        StringBuffer sbValueBeforeMD5 = new StringBuffer();
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            logger.debug("Random GUID error: " + e.getMessage());
        }
        try {
            long time = System.currentTimeMillis();
            long rand = 0;
            if (secure) {
                rand = mySecureRand.nextLong();
            } else {
                rand = myRand.nextLong();
            }
            sbValueBeforeMD5.append(s_id);
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(time));
            sbValueBeforeMD5.append(":");
            sbValueBeforeMD5.append(Long.toString(rand));
            valueBeforeMD5 = sbValueBeforeMD5.toString();
            md5.update(valueBeforeMD5.getBytes());
            byte[] array = md5.digest();
            StringBuffer sb = new StringBuffer();
            for (int j = 0; j < array.length; ++j) {
                int b = array[j] & 0xFF;
                if (b < 0x10) sb.append('0');
                sb.append(Integer.toHexString(b));
            }
            valueAfterMD5 = sb.toString();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
    }
```

**B**

```java
public List<Mosque> getAllMosquaisFromDataBase() {
        List<Mosque> mosquais = new ArrayList<Mosque>();
        InputStream is = null;
        String result = "";
        ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        if (MyMapActivity.DEVELOPER_MODE) {
            nameValuePairs.add(new BasicNameValuePair(Param.LATITUDE, MyMapActivity.mLatitude + ""));
            nameValuePairs.add(new BasicNameValuePair(Param.LONGITUDE, MyMapActivity.mLongitude + ""));
        } else {
            nameValuePairs.add(new BasicNameValuePair(Param.LATITUDE, MyMapActivity.myLocation.getLatitude() + ""));
            nameValuePairs.add(new BasicNameValuePair(Param.LONGITUDE, MyMapActivity.myLocation.getLongitude() + ""));
        }
        nameValuePairs.add(new BasicNameValuePair(Param.RAYON, DataBaseQuery.rayon * Param.KM_MARGE + ""));
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(Param.URI_SELECT_ALL_DATA_BASE);
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            HttpResponse response = httpclient.execute(httppost);
            HttpEntity entity = response.getEntity();
            is = entity.getContent();
        } catch (Exception e) {
            Log.e("log_tag", "Error in http connection " + e.toString());
        }
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            is.close();
            result = sb.toString();
        } catch (Exception e) {
            Log.e("log_tag", "Error converting result " + e.toString());
        }
        try {
            JSONArray jArray = new JSONArray(result);
            for (int i = 0; i < jArray.length(); i++) {
                JSONObject json_data = jArray.getJSONObject(i);
                Mosque mosquai = new Mosque(json_data.getInt(Param.ID), json_data.getString(Param.NOM), json_data.getDouble(Param.LATITUDE), json_data.getDouble(Param.LONGITUDE), json_data.getString(Param.INFO), json_data.getInt(Param.HAVE_PICTURE) == 1 ? true : false, json_data.getString(Param.PICTURE));
                mosquais.add(mosquai);
            }
        } catch (JSONException e) {
            Log.e("log_tag", "Error parsing data " + e.toString());
        }
        return mosquais;
    }
```

## f73c5234-014

**A**

```java
public static void main(String[] args) {
        try {
            FileReader reader = new FileReader(args[0]);
            FileWriter writer = new FileWriter(args[1]);
            html2xhtml(reader, writer);
            writer.close();
            reader.close();
        } catch (Exception e) {
            freemind.main.Resources.getInstance().logException(e);
        }
    }
```

**B**

```java
public void execute(File sourceFile, File destinationFile, Properties htmlCleanerConfig) {
        FileReader reader = null;
        Writer writer = null;
        try {
            reader = new FileReader(sourceFile);
            logger.info("Using source file: " + trimPath(userDir, sourceFile));
            if (!destinationFile.getParentFile().exists()) {
                createDirectory(destinationFile.getParentFile());
            }
            writer = new FileWriter(destinationFile);
            logger.info("Destination file:  " + trimPath(userDir, destinationFile));
            execute(reader, writer, htmlCleanerConfig);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                    writer = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                    reader = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
```

## f73c5234-015

**A**

```java
public int process(ProcessorContext context) throws InterruptedException, ProcessorException {
        logger.info("JAISaveTask:process");
        final RenderedOp im = (RenderedOp) context.get("RenderedOp");
        final String path = "s3://s3.amazonaws.com/rssfetch/" + (new Guid());
        final PNGEncodeParam.RGB encPar = new PNGEncodeParam.RGB();
        encPar.setTransparentRGB(new int[] { 0, 0, 0 });
        File tmpFile = null;
        try {
            tmpFile = File.createTempFile("thmb", ".png");
            OutputStream out = new FileOutputStream(tmpFile);
            final ParameterBlock pb = (new ParameterBlock()).addSource(im).add(out).add("png").add(encPar);
            JAI.create("encode", pb, null);
            out.flush();
            out.close();
            FileInputStream in = new FileInputStream(tmpFile);
            final XFile xfile = new XFile(path);
            final XFileOutputStream xout = new XFileOutputStream(xfile);
            final com.luzan.common.nfs.s3.XFileExtensionAccessor xfa = ((com.luzan.common.nfs.s3.XFileExtensionAccessor) xfile.getExtensionAccessor());
            if (xfa != null) {
                xfa.setMimeType("image/png");
                xfa.setContentLength(tmpFile.length());
            }
            IOUtils.copy(in, xout);
            xout.flush();
            xout.close();
            in.close();
            context.put("outputPath", path);
        } catch (IOException e) {
            logger.error(e);
            throw new ProcessorException(e);
        } catch (Throwable e) {
            logger.error(e);
            throw new ProcessorException(e);
        } finally {
            if (tmpFile != null && tmpFile.exists()) {
                tmpFile.delete();
            }
        }
        return TaskState.STATE_MO_START + TaskState.STATE_ENCODE;
    }
```

**B**

```java
@Transactional(readOnly = false)
    public void saveOrUpdateProduct(Product product, File[] doc, String[] docFileName, String[] docContentType) throws IOException {
        logger.info("addOrUpdateProduct()");
        List<Images> imgList = new ArrayList<Images>();
        InputStream in = null;
        OutputStream out = null;
        String saveDirectory = ServletActionContext.getServletContext().getRealPath("common/userfiles/image/");
        if (doc != null && doc.length > 0) {
            File uploadPath = new File(saveDirectory);
            if (!uploadPath.exists()) uploadPath.mkdirs();
            for (int i = 0; i < doc.length; i++) {
                Images img = new Images();
                in = new FileInputStream(doc[i]);
                img.setName(docFileName[i].substring(0, docFileName[i].lastIndexOf(".")));
                img.setRenameAs(docFileName[i]);
                imgList.add(img);
                out = new FileOutputStream(saveDirectory + "/" + img.getRenameAs());
                byte[] buffer = new byte[1024];
                int len;
                while ((len = in.read(buffer)) > 0) out.write(buffer, 0, len);
                out.flush();
            }
        }
        product.setImagesCollection(imgList);
        productDao.saveOrUpdateProduct(product);
        if (null != in) {
            try {
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (null != out) {
            try {
                out.close();
            } catch (Exception e) {
                logger.info("addOrUpdateProduct() **********" + e.getStackTrace());
                e.printStackTrace();
            }
        }
    }
```

## f73c5234-016

**A**

```java
@SuppressWarnings("finally")
  private void compress(File src) throws IOException
  {
    if (this.switches.contains(Switch.test))
      return;

    checkSourceFile(src);
    if (src.getPath().endsWith(".bz2"))
    {
      this.log.println("WARNING: skipping file because it already has .bz2 suffix:").println(src);
      return;
    }

    final File dst = new File(src.getPath() + ".bz2").getAbsoluteFile();
    if (!checkDestFile(dst))
      return;

    FileChannel       inChannel   = null;
    FileChannel       outChannel  = null;
    FileOutputStream  fileOut     = null;
    BZip2OutputStream bzOut       = null;
    FileLock          inLock      = null;
    FileLock          outLock     = null;

    try
    {
      inChannel = new FileInputStream(src).getChannel();
      final long inSize = inChannel.size();
      inLock = inChannel.tryLock(0, inSize, true);
      if (inLock == null)
        throw error("source file locked by another process: " + src);

      fileOut     = new FileOutputStream(dst);
      outChannel  = fileOut.getChannel();
      bzOut       = new BZip2OutputStream(
        new BufferedXOutputStream(fileOut, 8192),
        Math.min(
          (this.blockSize == -1) ? BZip2OutputStream.MAX_BLOCK_SIZE : this.blockSize,
          BZip2OutputStream.chooseBlockSize(inSize)
        )
      );

      outLock = outChannel.tryLock();
      if (outLock == null)
        throw error("destination file locked by another process: " + dst);

      final boolean showProgress = this.switches.contains(Switch.showProgress);
      long pos = 0;
      int progress = 0;

      if (showProgress || this.verbose)
      {
        this.log.print("source: " + src).print(": size=").println(inSize);
        this.log.println("target: " + dst);
      }

      while (true)
      {
        final long maxStep = showProgress ? Math.max(8192, (inSize - pos) / MAX_PROGRESS) : (inSize - pos);
        if (maxStep <= 0)
        {
          if (showProgress)
          {
            for (int i = progress; i < MAX_PROGRESS; i++)
              this.log.print('#');
            this.log.println(" done");
          }
          break;
        }
        else
        {
          final long step = inChannel.transferTo(pos, maxStep, bzOut);
          if ((step == 0) && (inChannel.size() != inSize))
            throw error("file " + src + " has been modified concurrently by another process");

          pos += step;
          if (showProgress)
          {
            final double  p           = (double) pos / (double) inSize;
            final int     newProgress = (int) (MAX_PROGRESS * p);
            for (int i = progress; i < newProgress; i++)
              this.log.print('#');
            progress = newProgress;
          }
        }
      }

      inLock.release();
      inChannel.close();
      bzOut.closeInstance();
      final long outSize = outChannel.position();
      outChannel.truncate(outSize);
      outLock.release();
      fileOut.close();

      if (this.verbose)
      {
        final double ratio = (inSize == 0) ? (outSize * 100) : ((double) outSize / (double) inSize);
        this.log.print("raw size: ").print(inSize)
          .print("; compressed size: ").print(outSize)
          .print("; compression ratio: ").print(ratio).println('%');
      }

      if (!this.switches.contains(Switch.keep))
      {
        if (!src.delete())
          throw error("unable to delete sourcefile: " + src);
      }
    }
    catch (final IOException ex)
    {
      IO.tryClose(inChannel);
      IO.tryClose(bzOut);
      IO.tryClose(fileOut);
      IO.tryRelease(inLock);
      IO.tryRelease(outLock);
      try
      {
        this.log.println();
      }
      finally
      {
        throw ex;
      }
    }
  }
```

**B**

```java
public static boolean copyFileChannel(final File _fileFrom, final File _fileTo, final boolean _append) {
        FileChannel srcChannel = null;
        FileChannel dstChannel = null;
        try {
            srcChannel = new FileInputStream(_fileFrom).getChannel();
            dstChannel = new FileOutputStream(_fileTo, _append).getChannel();
            if (_append) {
                dstChannel.transferFrom(srcChannel, dstChannel.size(), srcChannel.size());
            } else {
                dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
            }
            srcChannel.close();
            dstChannel.close();
        } catch (final IOException e) {
            return false;
        } finally {
            try {
                if (srcChannel != null) {
                    srcChannel.close();
                }
            } catch (final IOException _evt) {
                FuLog.error(_evt);
            }
            try {
                if (dstChannel != null) {
                    dstChannel.close();
                }
            } catch (final IOException _evt) {
                FuLog.error(_evt);
            }
        }
        return true;
    }
```

## f73c5234-017

**A**

```java
private void getImage(String filename) throws MalformedURLException, IOException, SAXException, FileNotFoundException {
        String url = Constants.STRATEGICDOMINATION_URL + "/images/gameimages/" + filename;
        WebRequest req = new GetMethodWebRequest(url);
        WebResponse response = wc.getResponse(req);
        File file = new File("etc/images/" + filename);
        FileOutputStream outputStream = new FileOutputStream(file);
        IOUtils.copy(response.getInputStream(), outputStream);
    }
```

**B**

```java
private void doConvert(HttpServletResponse response, ConversionRequestResolver rr, EGE ege, ConversionsPath cpath) throws FileUploadException, IOException, RequestResolvingException, EGEException, FileNotFoundException, ConverterException, ZipException {
        InputStream is = null;
        OutputStream os = null;
        if (ServletFileUpload.isMultipartContent(rr.getRequest())) {
            ServletFileUpload upload = new ServletFileUpload();
            FileItemIterator iter = upload.getItemIterator(rr.getRequest());
            while (iter.hasNext()) {
                FileItemStream item = iter.next();
                if (!item.isFormField()) {
                    is = item.openStream();
                    applyConversionsProperties(rr.getConversionProperties(), cpath);
                    DataBuffer buffer = new DataBuffer(0, EGEConstants.BUFFER_TEMP_PATH);
                    String alloc = buffer.allocate(is);
                    InputStream ins = buffer.getDataAsStream(alloc);
                    is.close();
                    try {
                        ValidationResult vRes = ege.performValidation(ins, cpath.getInputDataType());
                        if (vRes.getStatus().equals(ValidationResult.Status.FATAL)) {
                            ValidationServlet valServ = new ValidationServlet();
                            valServ.printValidationResult(response, vRes);
                            try {
                                ins.close();
                            } finally {
                                buffer.removeData(alloc, true);
                            }
                            return;
                        }
                    } catch (ValidatorException vex) {
                        LOGGER.warn(vex.getMessage());
                    } finally {
                        try {
                            ins.close();
                        } catch (Exception ex) {
                        }
                    }
                    File zipFile = null;
                    FileOutputStream fos = null;
                    String newTemp = UUID.randomUUID().toString();
                    IOResolver ior = EGEConfigurationManager.getInstance().getStandardIOResolver();
                    File buffDir = new File(buffer.getDataDir(alloc));
                    zipFile = new File(EGEConstants.BUFFER_TEMP_PATH + File.separator + newTemp + EZP_EXT);
                    fos = new FileOutputStream(zipFile);
                    ior.compressData(buffDir, fos);
                    ins = new FileInputStream(zipFile);
                    File szipFile = new File(EGEConstants.BUFFER_TEMP_PATH + File.separator + newTemp + ZIP_EXT);
                    fos = new FileOutputStream(szipFile);
                    try {
                        try {
                            ege.performConversion(ins, fos, cpath);
                        } finally {
                            fos.close();
                        }
                        boolean isComplex = EGEIOUtils.isComplexZip(szipFile);
                        response.setContentType(APPLICATION_OCTET_STREAM);
                        String fN = item.getName().substring(0, item.getName().lastIndexOf("."));
                        if (isComplex) {
                            String fileExt;
                            if (cpath.getOutputDataType().getMimeType().equals(APPLICATION_MSWORD)) {
                                fileExt = DOCX_EXT;
                            } else {
                                fileExt = ZIP_EXT;
                            }
                            response.setHeader("Content-Disposition", "attachment; filename=\"" + fN + fileExt + "\"");
                            FileInputStream fis = new FileInputStream(szipFile);
                            os = response.getOutputStream();
                            try {
                                EGEIOUtils.copyStream(fis, os);
                            } finally {
                                fis.close();
                            }
                        } else {
                            String fileExt = getMimeExtensionProvider().getFileExtension(cpath.getOutputDataType().getMimeType());
                            response.setHeader("Content-Disposition", "attachment; filename=\"" + fN + fileExt + "\"");
                            os = response.getOutputStream();
                            EGEIOUtils.unzipSingleFile(new ZipFile(szipFile), os);
                        }
                    } finally {
                        ins.close();
                        if (os != null) {
                            os.flush();
                            os.close();
                        }
                        buffer.clear(true);
                        szipFile.delete();
                        if (zipFile != null) {
                            zipFile.delete();
                        }
                    }
                }
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST);
            return;
        }
    }
```

## f73c5234-018

**A**

```java
protected boolean update(String sql, int requiredRows, int maxRows) throws SQLException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("executing " + sql + "...");
        }
        Connection connection = null;
        boolean oldAutoCommit = true;
        try {
            connection = dataSource.getConnection();
            connection.clearWarnings();
            oldAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            Statement statement = connection.createStatement();
            int rowsAffected = statement.executeUpdate(sql);
            if (requiredRows != -1 && rowsAffected < requiredRows) {
                LOG.warn("(" + rowsAffected + ") less than " + requiredRows + " rows affected, rolling back...");
                connection.rollback();
                return false;
            }
            if (maxRows != -1 && rowsAffected > maxRows) {
                LOG.warn("(" + rowsAffected + ") more than " + maxRows + " rows affected, rolling back...");
                connection.rollback();
                return false;
            }
            connection.commit();
            return true;
        } catch (SQLException e) {
            LOG.error("Unable to update database using: " + sql, e);
            throw e;
        } finally {
            try {
                if (connection != null) {
                    connection.setAutoCommit(oldAutoCommit);
                    connection.close();
                }
            } catch (SQLException e) {
                LOG.error("Unable to close connection: " + e, e);
            }
        }
    }
```

**B**

```java
public void readData(RowSetInternal caller) throws SQLException {
        Connection con = null;
        try {
            CachedRowSet crs = (CachedRowSet) caller;
            if (crs.getPageSize() == 0 && crs.size() > 0) {
                crs.close();
            }
            writerCalls = 0;
            userCon = false;
            con = this.connect(caller);
            if (con == null || crs.getCommand() == null) throw new SQLException(resBundle.handleGetObject("crsreader.connecterr").toString());
            try {
                con.setTransactionIsolation(crs.getTransactionIsolation());
            } catch (Exception ex) {
                ;
            }
            PreparedStatement pstmt = con.prepareStatement(crs.getCommand());
            decodeParams(caller.getParams(), pstmt);
            try {
                pstmt.setMaxRows(crs.getMaxRows());
                pstmt.setMaxFieldSize(crs.getMaxFieldSize());
                pstmt.setEscapeProcessing(crs.getEscapeProcessing());
                pstmt.setQueryTimeout(crs.getQueryTimeout());
            } catch (Exception ex) {
                throw new SQLException(ex.getMessage());
            }
            if (crs.getCommand().toLowerCase().indexOf("select") != -1) {
                ResultSet rs = pstmt.executeQuery();
                if (crs.getPageSize() == 0) {
                    crs.populate(rs);
                } else {
                    pstmt = con.prepareStatement(crs.getCommand(), ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                    decodeParams(caller.getParams(), pstmt);
                    try {
                        pstmt.setMaxRows(crs.getMaxRows());
                        pstmt.setMaxFieldSize(crs.getMaxFieldSize());
                        pstmt.setEscapeProcessing(crs.getEscapeProcessing());
                        pstmt.setQueryTimeout(crs.getQueryTimeout());
                    } catch (Exception ex) {
                        throw new SQLException(ex.getMessage());
                    }
                    rs = pstmt.executeQuery();
                    crs.populate(rs, startPosition);
                }
                rs.close();
            } else {
                pstmt.executeUpdate();
            }
            pstmt.close();
            try {
                con.commit();
            } catch (SQLException ex) {
                ;
            }
            if (getCloseConnection() == true) con.close();
        } catch (SQLException ex) {
            throw ex;
        } finally {
            try {
                if (con != null && getCloseConnection() == true) {
                    try {
                        if (!con.getAutoCommit()) {
                            con.rollback();
                        }
                    } catch (Exception dummy) {
                    }
                    con.close();
                    con = null;
                }
            } catch (SQLException e) {
            }
        }
    }
```

## f73c5234-019

**A**

```java
protected void checkWeavingJar() throws IOException {
        OutputStream out = null;
        try {
            final File weaving = new File(getWeavingPath());
            if (!weaving.exists()) {
                new File(getWeavingFolder()).mkdir();
                weaving.createNewFile();
                final Path src = new Path("weaving/openfrwk-weaving.jar");
                final InputStream in = FileLocator.openStream(getBundle(), src, false);
                out = new FileOutputStream(getWeavingPath(), true);
                IOUtils.copy(in, out);
                Logger.log(Logger.INFO, "Put weaving jar at location " + weaving);
            } else {
                Logger.getLog().info("File openfrwk-weaving.jar already exists at " + weaving);
            }
        } catch (final SecurityException e) {
            Logger.log(Logger.ERROR, "[SECURITY EXCEPTION] Not enough privilegies to create " + "folder and copy NexOpen weaving jar at location " + getWeavingFolder());
            Logger.logException(e);
        } finally {
            if (out != null) {
                out.flush();
                out.close();
            }
        }
    }
```

**B**

```java
public int process(ProcessorContext context) throws InterruptedException, ProcessorException {
        logger.info("JAISaveTask:process");
        final RenderedOp im = (RenderedOp) context.get("RenderedOp");
        final String path = "s3://s3.amazonaws.com/rssfetch/" + (new Guid());
        final PNGEncodeParam.RGB encPar = new PNGEncodeParam.RGB();
        encPar.setTransparentRGB(new int[] { 0, 0, 0 });
        File tmpFile = null;
        try {
            tmpFile = File.createTempFile("thmb", ".png");
            OutputStream out = new FileOutputStream(tmpFile);
            final ParameterBlock pb = (new ParameterBlock()).addSource(im).add(out).add("png").add(encPar);
            JAI.create("encode", pb, null);
            out.flush();
            out.close();
            FileInputStream in = new FileInputStream(tmpFile);
            final XFile xfile = new XFile(path);
            final XFileOutputStream xout = new XFileOutputStream(xfile);
            final com.luzan.common.nfs.s3.XFileExtensionAccessor xfa = ((com.luzan.common.nfs.s3.XFileExtensionAccessor) xfile.getExtensionAccessor());
            if (xfa != null) {
                xfa.setMimeType("image/png");
                xfa.setContentLength(tmpFile.length());
            }
            IOUtils.copy(in, xout);
            xout.flush();
            xout.close();
            in.close();
            context.put("outputPath", path);
        } catch (IOException e) {
            logger.error(e);
            throw new ProcessorException(e);
        } catch (Throwable e) {
            logger.error(e);
            throw new ProcessorException(e);
        } finally {
            if (tmpFile != null && tmpFile.exists()) {
                tmpFile.delete();
            }
        }
        return TaskState.STATE_MO_START + TaskState.STATE_ENCODE;
    }
```

## f73c5234-020

**A**

```java
public Image storeImage(String title, String pathToImage, Map<String, Object> additionalProperties) {
        File collectionFolder = ProjectManager.getInstance().getFolder(PropertyHandler.getInstance().getProperty("_default_collection_name"));
        File imageFile = new File(pathToImage);
        String filename = "";
        String format = "";
        File copiedImageFile;
        while (true) {
            filename = "image" + UUID.randomUUID().hashCode();
            if (!DbEntryProvider.INSTANCE.idExists(filename)) {
                Path path = new Path(pathToImage);
                format = path.getFileExtension();
                copiedImageFile = new File(collectionFolder.getAbsolutePath() + File.separator + filename + "." + format);
                if (!copiedImageFile.exists()) break;
            }
        }
        try {
            copiedImageFile.createNewFile();
        } catch (IOException e1) {
            ExceptionHandlingService.INSTANCE.handleException(e1);
            return null;
        }
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(imageFile), 4096);
            out = new BufferedOutputStream(new FileOutputStream(copiedImageFile), 4096);
            int c;
            while ((c = in.read()) != -1) out.write(c);
            in.close();
            out.close();
        } catch (FileNotFoundException e) {
            ExceptionHandlingService.INSTANCE.handleException(e);
            return null;
        } catch (IOException e) {
            ExceptionHandlingService.INSTANCE.handleException(e);
            return null;
        }
        Image image = new ImageImpl();
        image.setId(filename);
        image.setFormat(format);
        image.setEntryDate(new Date());
        image.setTitle(title);
        image.setAdditionalProperties(additionalProperties);
        boolean success = DbEntryProvider.INSTANCE.storeNewImage(image);
        if (success) return image;
        return null;
    }
```

**B**

```java
public Texture loadTexture(String file) throws IOException {
        URL imageUrl = urlFactory.makeUrl(file);
        Texture cached = textureLoader.getImageFromCache(imageUrl);
        if (cached != null) return cached;
        Image image;
        if (zip) {
            ZipInputStream zis = new ZipInputStream(url.openStream());
            ZipEntry entry;
            boolean found = false;
            while ((entry = zis.getNextEntry()) != null) {
                if (file.equals(entry.getName())) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                throw new IOException("Cannot find file \"" + file + "\".");
            }
            int extIndex = file.lastIndexOf('.');
            if (extIndex == -1) {
                throw new IOException("Cannot parse file extension.");
            }
            String fileExt = file.substring(extIndex);
            image = TextureManager.loadImage(fileExt, zis, true);
        } else {
            image = TextureManager.loadImage(imageUrl, true);
        }
        return textureLoader.loadTexture(imageUrl, image);
    }
```

## f73c5234-021

**A**

```java
private void fileCopy(final File src, final File dest) throws IOException {
        final FileChannel srcChannel = new FileInputStream(src).getChannel();
        final FileChannel dstChannel = new FileOutputStream(dest).getChannel();
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
        srcChannel.close();
        dstChannel.close();
    }
```

**B**

```java
public void doInsertImage() {
        logger.debug(">>> Inserting image...");
        logger.debug(" fullFileName : #0", uploadedFileName);
        String fileName = uploadedFileName.substring(uploadedFileName.lastIndexOf(File.separator) + 1);
        logger.debug(" fileName : #0", fileName);
        String newFileName = System.currentTimeMillis() + "_" + fileName;
        String filePath = ImageResource.getResourceDirectory() + File.separator + newFileName;
        logger.debug(" filePath : #0", filePath);
        try {
            File file = new File(filePath);
            file.createNewFile();
            FileChannel srcChannel = null;
            FileChannel dstChannel = null;
            try {
                srcChannel = new FileInputStream(uploadedFile).getChannel();
                dstChannel = new FileOutputStream(file).getChannel();
                dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
            } finally {
                closeChannel(srcChannel);
                closeChannel(dstChannel);
            }
            StringBuilder imageTag = new StringBuilder();
            imageTag.append("<img src=\"");
            imageTag.append(getRequest().getContextPath());
            imageTag.append("/seam/resource");
            imageTag.append(ImageResource.RESOURCE_PATH);
            imageTag.append("/");
            imageTag.append(newFileName);
            imageTag.append("\"/>");
            if (getQuestionDefinition().getDescription() == null) {
                getQuestionDefinition().setDescription("");
            }
            getQuestionDefinition().setDescription(getQuestionDefinition().getDescription() + imageTag);
        } catch (IOException e) {
            logger.error("Error during saving image file", e);
        }
        uploadedFile = null;
        uploadedFileName = null;
        logger.debug("<<< Inserting image...Ok");
    }
```

## f73c5234-022

**A**

```java
private static void copy(File source, File dest) throws FileNotFoundException, IOException {
        FileInputStream input = new FileInputStream(source);
        FileOutputStream output = new FileOutputStream(dest);
        System.out.println("Copying " + source + " to " + dest);
        IOUtils.copy(input, output);
        output.close();
        input.close();
        dest.setLastModified(source.lastModified());
    }
```

**B**

```java
public static void copyFile(File sourceFile, File destFile, boolean overwrite) throws IOException, DirNotFoundException, FileNotFoundException, FileExistsAlreadyException {
        File destDir = new File(destFile.getParent());
        if (!destDir.exists()) {
            throw new DirNotFoundException(destDir.getAbsolutePath());
        }
        if (!sourceFile.exists()) {
            throw new FileNotFoundException(sourceFile.getAbsolutePath());
        }
        if (!overwrite && destFile.exists()) {
            throw new FileExistsAlreadyException(destFile.getAbsolutePath());
        }
        FileInputStream in = new FileInputStream(sourceFile);
        FileOutputStream out = new FileOutputStream(destFile);
        byte[] buffer = new byte[8 * 1024];
        int count = 0;
        do {
            out.write(buffer, 0, count);
            count = in.read(buffer, 0, buffer.length);
        } while (count != -1);
        in.close();
        out.close();
    }
```

## f73c5234-023

**A**

```java
public void downloadFile(OutputStream os, int fileId) throws IOException, SQLException {
        Connection conn = null;
        try {
            conn = ds.getConnection();
            Guard.checkConnectionNotNull(conn);
            PreparedStatement ps = conn.prepareStatement("select * from FILE_BODIES where file_id=?");
            ps.setInt(1, fileId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new FileNotFoundException("File with id=" + fileId + " not found!");
            }
            Blob blob = rs.getBlob("data");
            InputStream is = blob.getBinaryStream();
            IOUtils.copyLarge(is, os);
        } finally {
            JdbcDaoHelper.safeClose(conn, log);
        }
    }
```

**B**

```java
protected synchronized Long putModel(String table, String linkTable, String type, TupleBinding binding, LocatableModel model) {
        try {
            if (model.getId() != null && !"".equals(model.getId())) {
                ps7.setInt(1, Integer.parseInt(model.getId()));
                ps7.execute();
                ps6.setInt(1, Integer.parseInt(model.getId()));
                ps6.execute();
            }
            if (persistenceMethod == PostgreSQLStore.BYTEA) {
                ps1.setString(1, model.getContig());
                ps1.setInt(2, model.getStartPosition());
                ps1.setInt(3, model.getStopPosition());
                ps1.setString(4, type);
                DatabaseEntry objData = new DatabaseEntry();
                binding.objectToEntry(model, objData);
                ps1.setBytes(5, objData.getData());
                ps1.executeUpdate();
            } else if (persistenceMethod == PostgreSQLStore.OID || persistenceMethod == PostgreSQLStore.FIELDS) {
                ps1b.setString(1, model.getContig());
                ps1b.setInt(2, model.getStartPosition());
                ps1b.setInt(3, model.getStopPosition());
                ps1b.setString(4, type);
                DatabaseEntry objData = new DatabaseEntry();
                binding.objectToEntry(model, objData);
                int oid = lobj.create(LargeObjectManager.READ | LargeObjectManager.WRITE);
                LargeObject obj = lobj.open(oid, LargeObjectManager.WRITE);
                obj.write(objData.getData());
                obj.close();
                ps1b.setInt(5, oid);
                ps1b.executeUpdate();
            }
            ResultSet rs = null;
            PreparedStatement ps = conn.prepareStatement("select currval('" + table + "_" + table + "_id_seq')");
            rs = ps.executeQuery();
            int modelId = -1;
            if (rs != null) {
                if (rs.next()) {
                    modelId = rs.getInt(1);
                }
            }
            rs.close();
            ps.close();
            for (String key : model.getTags().keySet()) {
                int tagId = -1;
                if (tags.get(key) != null) {
                    tagId = tags.get(key);
                } else {
                    ps2.setString(1, key);
                    rs = ps2.executeQuery();
                    if (rs != null) {
                        while (rs.next()) {
                            tagId = rs.getInt(1);
                        }
                    }
                    rs.close();
                }
                if (tagId < 0) {
                    ps3.setString(1, key);
                    ps3.setString(2, model.getTags().get(key));
                    ps3.executeUpdate();
                    rs = ps4.executeQuery();
                    if (rs != null) {
                        if (rs.next()) {
                            tagId = rs.getInt(1);
                            tags.put(key, tagId);
                        }
                    }
                    rs.close();
                }
                ps5.setInt(1, tagId);
                ps5.executeUpdate();
            }
            conn.commit();
            return (new Long(modelId));
        } catch (SQLException e) {
            try {
                conn.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            e.printStackTrace();
            System.err.println(e.getMessage());
        } catch (Exception e) {
            try {
                conn.rollback();
            } catch (SQLException e2) {
                e2.printStackTrace();
            }
            e.printStackTrace();
            System.err.println(e.getMessage());
        }
        return (null);
    }
```

## f73c5234-024

**A**

```java
public static void copyFile(File destFile, File src) throws IOException {
        File destDir = destFile.getParentFile();
        File tempFile = new File(destFile + "_tmp");
        destDir.mkdirs();
        InputStream is = new FileInputStream(src);
        try {
            FileOutputStream os = new FileOutputStream(tempFile);
            try {
                byte[] buf = new byte[8192];
                int len;
                while ((len = is.read(buf)) > 0) os.write(buf, 0, len);
            } finally {
                os.close();
            }
        } finally {
            is.close();
        }
        destFile.delete();
        if (!tempFile.renameTo(destFile)) throw new IOException("Unable to rename " + tempFile + " to " + destFile);
    }
```

**B**

```java
public File convert(URI uri) throws DjatokaException {
        processing.add(uri.toString());
        File urlLocal = null;
        try {
            logger.info("processingRemoteURI: " + uri.toURL());
            boolean isJp2 = false;
            InputStream src = IOUtils.getInputStream(uri.toURL());
            String ext = uri.toURL().toString().substring(uri.toURL().toString().lastIndexOf(".") + 1).toLowerCase();
            if (ext.equals(FORMAT_ID_TIF) || ext.equals(FORMAT_ID_TIFF)) {
                urlLocal = File.createTempFile("convert" + uri.hashCode(), "." + FORMAT_ID_TIF);
            } else if (formatMap.containsKey(ext) && (formatMap.get(ext).equals(FORMAT_MIMEYPE_JP2) || formatMap.get(ext).equals(FORMAT_MIMEYPE_JPX))) {
                urlLocal = File.createTempFile("cache" + uri.hashCode(), "." + ext);
                isJp2 = true;
            } else {
                if (src.markSupported()) src.mark(15);
                if (ImageProcessingUtils.checkIfJp2(src)) urlLocal = File.createTempFile("cache" + uri.hashCode(), "." + FORMAT_ID_JP2);
                if (src.markSupported()) src.reset(); else {
                    src.close();
                    src = IOUtils.getInputStream(uri.toURL());
                }
            }
            if (urlLocal == null) {
                urlLocal = File.createTempFile("convert" + uri.hashCode(), ".img");
            }
            urlLocal.deleteOnExit();
            FileOutputStream dest = new FileOutputStream(urlLocal);
            IOUtils.copyStream(src, dest);
            if (!isJp2) urlLocal = processImage(urlLocal, uri);
            src.close();
            dest.close();
            return urlLocal;
        } catch (Exception e) {
            urlLocal.delete();
            throw new DjatokaException(e);
        } finally {
            if (processing.contains(uri.toString())) processing.remove(uri.toString());
        }
    }
```

## f73c5234-025

**A**

```java
private String getTextResponse(String address) throws Exception {
        URL url = new URL(address);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setUseCaches(false);
        BufferedReader in = null;
        try {
            con.connect();
            assertEquals(HttpURLConnection.HTTP_OK, con.getResponseCode());
            in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder builder = new StringBuilder();
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                builder.append(inputLine);
            }
            return builder.toString();
        } finally {
            if (in != null) {
                in.close();
            }
            con.disconnect();
        }
    }
```

**B**

```java
public boolean consolidateCrossrefGet(BiblioItem bib, ArrayList<BiblioItem> bib2) throws Exception {
        boolean result = false;
        String doi = bib.getDOI();
        String aut = bib.getFirstAuthorSurname();
        String title = bib.getTitle();
        String firstPage = null;
        String pageRange = bib.getPageRange();
        int beginPage = bib.getBeginPage();
        if (beginPage != -1) {
            firstPage = "" + beginPage;
        } else if (pageRange != null) {
            StringTokenizer st = new StringTokenizer(pageRange, "--");
            if (st.countTokens() == 2) {
                firstPage = st.nextToken();
            } else if (st.countTokens() == 1) firstPage = pageRange;
        }
        if (aut != null) {
            aut = TextUtilities.removeAccents(aut);
        }
        if (title != null) {
            title = TextUtilities.removeAccents(title);
        }
        if (doi != null) {
            if (doi.startsWith("doi:") | doi.startsWith("DOI:")) {
                doi.substring(4, doi.length());
                doi = doi.trim();
            }
            doi = doi.replace(" ", "");
            String xml = null;
            if (cCon != null) {
                PreparedStatement pstmt = null;
                try {
                    pstmt = cCon.prepareStatement(QUERY_CROSSREF_SQL3);
                    pstmt.setString(1, doi);
                    ResultSet res = pstmt.executeQuery();
                    if (res.next()) {
                        xml = res.getString(1);
                    }
                    res.close();
                    pstmt.close();
                } catch (SQLException se) {
                    System.err.println("EXCEPTION HANDLING CROSSREF CACHE");
                    throw new GROBIDServiceException("EXCEPTION HANDLING CROSSREF CACHE.", se);
                } finally {
                    try {
                        if (pstmt != null) pstmt.close();
                    } catch (SQLException se) {
                    }
                }
                if (xml != null) {
                    InputSource is = new InputSource();
                    is.setCharacterStream(new StringReader(xml));
                    DefaultHandler crossref = new crossrefUnixrefSaxParser(bib2);
                    SAXParserFactory spf = SAXParserFactory.newInstance();
                    SAXParser parser = spf.newSAXParser();
                    parser.parse(is, crossref);
                    if (bib2.size() > 0) {
                        if (!bib2.get(0).getError()) result = true;
                    }
                }
            }
            if (xml == null) {
                String subpath = String.format(DOI_BASE_QUERY, crossref_id, crossref_pw, doi);
                URL url = new URL("http://" + crossref_host + "/" + subpath);
                System.out.println("Sending: " + url.toString());
                HttpURLConnection urlConn = null;
                try {
                    urlConn = (HttpURLConnection) url.openConnection();
                } catch (Exception e) {
                    this.setProxy();
                    try {
                        urlConn = (HttpURLConnection) url.openConnection();
                    } catch (Exception e2) {
                        urlConn = null;
                        throw new GROBIDServiceException("An exception occured while running Grobid.", e2);
                    }
                }
                if (urlConn != null) {
                    try {
                        urlConn.setDoOutput(true);
                        urlConn.setDoInput(true);
                        urlConn.setRequestMethod("GET");
                        urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                        InputStream in = urlConn.getInputStream();
                        xml = TextUtilities.convertStreamToString(in);
                        InputSource is = new InputSource();
                        is.setCharacterStream(new StringReader(xml));
                        DefaultHandler crossref = new crossrefUnixrefSaxParser(bib2);
                        SAXParserFactory spf = SAXParserFactory.newInstance();
                        SAXParser parser = spf.newSAXParser();
                        parser.parse(is, crossref);
                        if (bib2.size() > 0) {
                            if (!bib2.get(0).getError()) result = true;
                        }
                        urlConn.disconnect();
                    } catch (Exception e) {
                        System.err.println("Warning: Consolidation set true, " + "but the online connection to Crossref fails.");
                    }
                    if (cCon != null) {
                        PreparedStatement pstmt2 = null;
                        try {
                            pstmt2 = cCon.prepareStatement(INSERT_CROSSREF_SQL3);
                            pstmt2.setString(1, doi);
                            pstmt2.setString(2, xml);
                            pstmt2.executeUpdate();
                            pstmt2.close();
                        } catch (SQLException se) {
                            System.err.println("EXCEPTION HANDLING CROSSREF UPDATE");
                        } finally {
                            try {
                                if (pstmt2 != null) pstmt2.close();
                            } catch (SQLException se) {
                            }
                        }
                    }
                }
            }
        } else if ((title != null) & (aut != null)) {
            String xml = null;
            if (cCon != null) {
                PreparedStatement pstmt = null;
                try {
                    pstmt = cCon.prepareStatement(QUERY_CROSSREF_SQL);
                    pstmt.setString(1, aut);
                    pstmt.setString(2, title);
                    ResultSet res = pstmt.executeQuery();
                    if (res.next()) {
                        xml = res.getString(1);
                    }
                    res.close();
                    pstmt.close();
                } catch (SQLException se) {
                    throw new GROBIDServiceException("EXCEPTION HANDLING CROSSREF CACHE", se);
                } finally {
                    try {
                        if (pstmt != null) pstmt.close();
                    } catch (SQLException se) {
                    }
                }
                if (xml != null) {
                    InputSource is = new InputSource();
                    is.setCharacterStream(new StringReader(xml));
                    DefaultHandler crossref = new crossrefUnixrefSaxParser(bib2);
                    SAXParserFactory spf = SAXParserFactory.newInstance();
                    SAXParser parser = spf.newSAXParser();
                    parser.parse(is, crossref);
                    if (bib2.size() > 0) {
                        if (!bib2.get(0).getError()) result = true;
                    }
                }
            }
            if (xml == null) {
                String subpath = String.format(TITLE_BASE_QUERY, crossref_id, crossref_pw, URLEncoder.encode(title), URLEncoder.encode(aut));
                URL url = new URL("http://" + crossref_host + "/" + subpath);
                System.out.println("Sending: " + url.toString());
                HttpURLConnection urlConn = null;
                try {
                    urlConn = (HttpURLConnection) url.openConnection();
                } catch (Exception e) {
                    this.setProxy();
                    try {
                        urlConn = (HttpURLConnection) url.openConnection();
                    } catch (Exception e2) {
                        urlConn = null;
                        throw new GROBIDServiceException("An exception occured while running Grobid.", e2);
                    }
                }
                if (urlConn != null) {
                    try {
                        urlConn.setDoOutput(true);
                        urlConn.setDoInput(true);
                        urlConn.setRequestMethod("GET");
                        urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                        InputStream in = urlConn.getInputStream();
                        xml = TextUtilities.convertStreamToString(in);
                        InputSource is = new InputSource();
                        is.setCharacterStream(new StringReader(xml));
                        DefaultHandler crossref = new crossrefUnixrefSaxParser(bib2);
                        SAXParserFactory spf = SAXParserFactory.newInstance();
                        SAXParser parser = spf.newSAXParser();
                        parser.parse(is, crossref);
                        if (bib2.size() > 0) {
                            if (!bib2.get(0).getError()) result = true;
                        }
                        urlConn.disconnect();
                    } catch (Exception e) {
                        System.err.println("Warning: Consolidation set true, " + "but the online connection to Crossref fails.");
                    }
                    if (cCon != null) {
                        PreparedStatement pstmt2 = null;
                        try {
                            pstmt2 = cCon.prepareStatement(INSERT_CROSSREF_SQL);
                            pstmt2.setString(1, aut);
                            pstmt2.setString(2, bib.getTitle());
                            pstmt2.setString(3, xml);
                            pstmt2.executeUpdate();
                            pstmt2.close();
                        } catch (SQLException se) {
                            System.err.println("EXCEPTION HANDLING CROSSREF UPDATE");
                        } finally {
                            try {
                                if (pstmt2 != null) pstmt2.close();
                            } catch (SQLException se) {
                            }
                        }
                    }
                }
            }
        } else if ((firstPage != null) & (bib.getJournal() != null) & (bib.getVolume() != null)) {
            String subpath = String.format(JOURNAL_BASE_QUERY, crossref_id, crossref_pw, URLEncoder.encode(bib.getJournal()), URLEncoder.encode(bib.getVolume()), firstPage);
            URL url = new URL("http://" + crossref_host + "/" + subpath);
            String urlmsg = url.toString();
            System.out.println(urlmsg);
            String xml = null;
            if (cCon != null) {
                PreparedStatement pstmt = null;
                try {
                    pstmt = cCon.prepareStatement(QUERY_CROSSREF_SQL2);
                    pstmt.setString(1, urlmsg);
                    ResultSet res = pstmt.executeQuery();
                    if (res.next()) {
                        xml = res.getString(1);
                    }
                    res.close();
                    pstmt.close();
                } catch (SQLException se) {
                    System.err.println("EXCEPTION HANDLING CROSSREF CACHE");
                    throw new GROBIDServiceException("EXCEPTION HANDLING CROSSREF CACHE.", se);
                } finally {
                    try {
                        if (pstmt != null) pstmt.close();
                    } catch (SQLException se) {
                    }
                }
                if (xml != null) {
                    InputSource is = new InputSource();
                    is.setCharacterStream(new StringReader(xml));
                    DefaultHandler crossref = new crossrefUnixrefSaxParser(bib2);
                    SAXParserFactory spf = SAXParserFactory.newInstance();
                    SAXParser parser = spf.newSAXParser();
                    parser.parse(is, crossref);
                    if (bib2.size() > 0) {
                        if (!bib2.get(0).getError()) result = true;
                    }
                }
            }
            if (xml == null) {
                System.out.println("Sending: " + urlmsg);
                HttpURLConnection urlConn = null;
                try {
                    urlConn = (HttpURLConnection) url.openConnection();
                } catch (Exception e) {
                    this.setProxy();
                    try {
                        urlConn = (HttpURLConnection) url.openConnection();
                    } catch (Exception e2) {
                        urlConn = null;
                        throw new GROBIDServiceException("An exception occured while running Grobid.", e2);
                    }
                }
                if (urlConn != null) {
                    try {
                        urlConn.setDoOutput(true);
                        urlConn.setDoInput(true);
                        urlConn.setRequestMethod("GET");
                        urlConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                        InputStream in = urlConn.getInputStream();
                        xml = TextUtilities.convertStreamToString(in);
                        InputSource is = new InputSource();
                        is.setCharacterStream(new StringReader(xml));
                        DefaultHandler crossref = new crossrefUnixrefSaxParser(bib2);
                        SAXParserFactory spf = SAXParserFactory.newInstance();
                        SAXParser p = spf.newSAXParser();
                        p.parse(is, crossref);
                        if (bib2.size() > 0) {
                            if (!bib2.get(0).getError()) result = true;
                        }
                        in.close();
                        urlConn.disconnect();
                    } catch (Exception e) {
                        System.err.println("Warning: Consolidation set true, " + "but the online connection to Crossref fails.");
                    }
                    if (cCon != null) {
                        PreparedStatement pstmt2 = null;
                        try {
                            pstmt2 = cCon.prepareStatement(INSERT_CROSSREF_SQL2);
                            pstmt2.setString(1, urlmsg);
                            pstmt2.setString(2, xml);
                            pstmt2.executeUpdate();
                            pstmt2.close();
                        } catch (SQLException se) {
                            System.err.println("EXCEPTION HANDLING CROSSREF UPDATE");
                        } finally {
                            try {
                                if (pstmt2 != null) pstmt2.close();
                            } catch (SQLException se) {
                            }
                        }
                    }
                }
            }
        }
        return result;
    }
```

## f73c5234-026

**A**

```java
public void xtest1() throws Exception {
        InputStream input = new FileInputStream("C:/Documentos/j931_01.pdf");
        InputStream tmp = new ITextManager().cut(input, 3, 8);
        FileOutputStream output = new FileOutputStream("C:/temp/split.pdf");
        IOUtils.copy(tmp, output);
        input.close();
        tmp.close();
        output.close();
    }
```

**B**

```java
public static URL[] getURLsForAllJars(URL url, File tmpDir) {
        FileInputStream fin = null;
        InputStream in = null;
        ZipInputStream zin = null;
        try {
            ArrayList array = new ArrayList();
            in = url.openStream();
            String fileName = url.getFile();
            int index = fileName.lastIndexOf('/');
            if (index != -1) {
                fileName = fileName.substring(index + 1);
            }
            final File f = createTempFile(fileName, in, tmpDir);
            fin = (FileInputStream) org.apache.axis2.java.security.AccessController.doPrivileged(new PrivilegedExceptionAction() {

                public Object run() throws FileNotFoundException {
                    return new FileInputStream(f);
                }
            });
            array.add(f.toURL());
            zin = new ZipInputStream(fin);
            ZipEntry entry;
            String entryName;
            while ((entry = zin.getNextEntry()) != null) {
                entryName = entry.getName();
                if ((entryName != null) && entryName.toLowerCase().startsWith("lib/") && entryName.toLowerCase().endsWith(".jar")) {
                    String suffix = entryName.substring(4);
                    File f2 = createTempFile(suffix, zin, tmpDir);
                    array.add(f2.toURL());
                }
            }
            return (URL[]) array.toArray(new URL[array.size()]);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (IOException e) {
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                }
            }
            if (zin != null) {
                try {
                    zin.close();
                } catch (IOException e) {
                }
            }
        }
    }
```

## f73c5234-027

**A**

```java
private void exportJar(File root, List<File> list, Manifest manifest) throws Exception {
        JarOutputStream jarOut = null;
        FileInputStream fin = null;
        try {
            jarOut = new JarOutputStream(new FileOutputStream(jarFile), manifest);
            for (int i = 0; i < list.size(); i++) {
                String filename = list.get(i).getAbsolutePath();
                filename = filename.substring(root.getAbsolutePath().length() + 1);
                fin = new FileInputStream(list.get(i));
                JarEntry entry = new JarEntry(filename.replace('\\', '/'));
                jarOut.putNextEntry(entry);
                byte[] buf = new byte[4096];
                int read;
                while ((read = fin.read(buf)) != -1) {
                    jarOut.write(buf, 0, read);
                }
                jarOut.closeEntry();
                jarOut.flush();
            }
        } finally {
            if (fin != null) {
                try {
                    fin.close();
                } catch (Exception e) {
                    ExceptionOperation.operate(e);
                }
            }
            if (jarOut != null) {
                try {
                    jarOut.close();
                } catch (Exception e) {
                }
            }
        }
    }
```

**B**

```java
private static void findDictionary() {
        java.net.URL url = Translator.class.getResource("Translator.class");
        String location = url.getFile();
        String dictionaryName = (String) Settings.getDefault().getSetting("dictionary");
        InputStream inputStream;
        try {
            if (location.indexOf(".jar!") == -1) inputStream = new FileInputStream(location.substring(0, location.indexOf("Translator.class")) + dictionaryName); else {
                JarFile jarFile;
                if (location.indexOf("rachota.sourceforge.net") != -1) {
                    String fileName = location.substring(0, location.indexOf("!/") + 2);
                    url = new URL("jar:http://rachota.sourceforge.net/rachota_22.jar!/");
                    JarURLConnection jarConnection = (JarURLConnection) url.openConnection();
                    jarFile = jarConnection.getJarFile();
                } else {
                    String fileName = System.getProperty("os.name").indexOf("Windows") == -1 ? "/" : "";
                    fileName = fileName + location.substring(6, location.indexOf(".jar") + 4);
                    fileName = Tools.replaceAll(fileName, "%20", " ");
                    jarFile = new JarFile(fileName);
                }
                ZipEntry entry = jarFile.getEntry("org/cesilko/rachota/core/" + dictionaryName);
                if (entry == null) {
                    entry = jarFile.getEntry("org/cesilko/rachota/core/Dictionary_en_US.properties");
                    Settings.getDefault().setSetting("dictionary", "Dictionary_en_US.properties");
                }
                inputStream = jarFile.getInputStream(entry);
            }
            dictionary = new PropertyResourceBundle(inputStream);
        } catch (Exception e) {
            System.out.println("Error: Reading from " + dictionaryName + " dictionary failed.");
            e.printStackTrace();
        }
    }
```

## f73c5234-028

**A**

```java
private static String doGetForSessionKey(String authCode) throws Exception {
        String sessionKey = "";
        HttpClient hc = new DefaultHttpClient();
        HttpGet hg = new HttpGet(Common.TEST_SESSION_HOST + Common.TEST_SESSION_PARAM + authCode);
        HttpResponse hr = hc.execute(hg);
        BufferedReader br = new BufferedReader(new InputStreamReader(hr.getEntity().getContent()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        String result = sb.toString();
        Log.i("sessionKeyMessages", result);
        Map<String, String> map = Util.handleURLParameters(result);
        sessionKey = map.get(Common.TOP_SESSION);
        String topParameters = map.get(Common.TOP_PARAMETERS);
        String decTopParameters = Util.decodeBase64(topParameters);
        Log.i("base64", decTopParameters);
        map = Util.handleURLParameters(decTopParameters);
        Log.i("nick", map.get(Common.VISITOR_NICK));
        CachePool.put(Common.VISITOR_NICK, map.get(Common.VISITOR_NICK));
        return sessionKey;
    }
```

**B**

```java
public void processAction(ActionMapping mapping, ActionForm form, PortletConfig config, ActionRequest req, ActionResponse res) throws Exception {
        boolean editor = false;
        req.setAttribute(ViewReportsAction.REPORT_EDITOR_OR_ADMIN, false);
        User user = _getUser(req);
        List<Role> roles = RoleFactory.getAllRolesForUser(user.getUserId());
        for (Role role : roles) {
            if (role.getName().equals("Report Administrator") || role.getName().equals("Report Editor") || role.getName().equals("CMS Administrator")) {
                req.setAttribute(ViewReportsAction.REPORT_EDITOR_OR_ADMIN, true);
                editor = true;
                break;
            }
        }
        requiresInput = false;
        badParameters = false;
        newReport = false;
        ActionRequestImpl reqImpl = (ActionRequestImpl) req;
        HttpServletRequest httpReq = reqImpl.getHttpServletRequest();
        String cmd = req.getParameter(Constants.CMD);
        Logger.debug(this, "Inside EditReportAction cmd=" + cmd);
        ReportForm rfm = (ReportForm) form;
        ArrayList<String> ds = (DbConnectionFactory.getAllDataSources());
        ArrayList<DataSource> dsResults = new ArrayList<DataSource>();
        for (String dataSource : ds) {
            DataSource d = rfm.getNewDataSource();
            if (dataSource.equals(com.dotmarketing.util.Constants.DATABASE_DEFAULT_DATASOURCE)) {
                d.setDsName("DotCMS Datasource");
            } else {
                d.setDsName(dataSource);
            }
            dsResults.add(d);
        }
        rfm.setDataSources(dsResults);
        httpReq.setAttribute("dataSources", rfm.getDataSources());
        Long reportId = UtilMethods.parseLong(req.getParameter("reportId"), 0);
        String referrer = req.getParameter("referrer");
        if (reportId > 0) {
            report = ReportFactory.getReport(reportId);
            ArrayList<String> adminRoles = new ArrayList<String>();
            adminRoles.add(com.dotmarketing.util.Constants.ROLE_REPORT_ADMINISTRATOR);
            if (user.getUserId().equals(report.getOwner())) {
                _checkWritePermissions(report, user, httpReq, adminRoles);
            }
            if (cmd == null || !cmd.equals(Constants.EDIT)) {
                rfm.setSelectedDataSource(report.getDs());
                rfm.setReportName(report.getReportName());
                rfm.setReportDescription(report.getReportDescription());
                rfm.setReportId(report.getInode());
                rfm.setWebFormReport(report.isWebFormReport());
                httpReq.setAttribute("selectedDS", report.getDs());
            }
        } else {
            if (!editor) {
                throw new DotRuntimeException("user not allowed to create a new report");
            }
            report = new Report();
            report.setOwner(_getUser(req).getUserId());
            newReport = true;
        }
        req.setAttribute(WebKeys.PERMISSION_INODE_EDIT, report);
        if ((cmd != null) && cmd.equals(Constants.EDIT)) {
            if (Validator.validate(req, form, mapping)) {
                report.setReportName(rfm.getReportName());
                report.setReportDescription(rfm.getReportDescription());
                report.setWebFormReport(rfm.isWebFormReport());
                if (rfm.isWebFormReport()) report.setDs("None"); else report.setDs(rfm.getSelectedDataSource());
                String jrxmlPath = "";
                String jasperPath = "";
                try {
                    HibernateUtil.startTransaction();
                    ReportFactory.saveReport(report);
                    _applyPermissions(req, report);
                    if (!rfm.isWebFormReport()) {
                        if (UtilMethods.isSet(Config.getStringProperty("ASSET_REAL_PATH"))) {
                            jrxmlPath = Config.getStringProperty("ASSET_REAL_PATH") + File.separator + Config.getStringProperty("REPORT_PATH") + File.separator + report.getInode() + ".jrxml";
                            jasperPath = Config.getStringProperty("ASSET_REAL_PATH") + File.separator + Config.getStringProperty("REPORT_PATH") + File.separator + report.getInode() + ".jasper";
                        } else {
                            jrxmlPath = Config.CONTEXT.getRealPath(File.separator + Config.getStringProperty("REPORT_PATH") + File.separator + report.getInode() + ".jrxml");
                            jasperPath = Config.CONTEXT.getRealPath(File.separator + Config.getStringProperty("REPORT_PATH") + File.separator + report.getInode() + ".jasper");
                        }
                        UploadPortletRequest upr = PortalUtil.getUploadPortletRequest(req);
                        File importFile = upr.getFile("jrxmlFile");
                        if (importFile.exists()) {
                            byte[] currentData = new byte[0];
                            FileInputStream is = new FileInputStream(importFile);
                            int size = is.available();
                            currentData = new byte[size];
                            is.read(currentData);
                            File f = new File(jrxmlPath);
                            FileChannel channelTo = new FileOutputStream(f).getChannel();
                            ByteBuffer currentDataBuffer = ByteBuffer.allocate(currentData.length);
                            currentDataBuffer.put(currentData);
                            currentDataBuffer.position(0);
                            channelTo.write(currentDataBuffer);
                            channelTo.force(false);
                            channelTo.close();
                            try {
                                JasperCompileManager.compileReportToFile(jrxmlPath, jasperPath);
                            } catch (Exception e) {
                                Logger.error(this, "Unable to compile or save jrxml: " + e.toString());
                                try {
                                    f = new File(jrxmlPath);
                                    f.delete();
                                } catch (Exception ex) {
                                    Logger.info(this, "Unable to delete jrxml. This is usually a permissions problem.");
                                }
                                try {
                                    f = new File(jasperPath);
                                    f.delete();
                                } catch (Exception ex) {
                                    Logger.info(this, "Unable to delete jasper. This is usually a permissions problem.");
                                }
                                HibernateUtil.rollbackTransaction();
                                SessionMessages.add(req, "error", UtilMethods.htmlLineBreak(e.getMessage()));
                                setForward(req, "portlet.ext.report.edit_report");
                                return;
                            }
                            JasperReport jasperReport = (JasperReport) JRLoader.loadObject(jasperPath);
                            ReportParameterFactory.deleteReportsParameters(report);
                            _loadReportParameters(jasperReport.getParameters());
                            report.setRequiresInput(requiresInput);
                            HibernateUtil.save(report);
                        } else if (newReport) {
                            HibernateUtil.rollbackTransaction();
                            SessionMessages.add(req, "error", "message.report.compile.error");
                            setForward(req, "portlet.ext.report.edit_report");
                            return;
                        }
                    }
                    HibernateUtil.commitTransaction();
                    HashMap params = new HashMap();
                    SessionMessages.add(req, "message", "message.report.upload.success");
                    params.put("struts_action", new String[] { "/ext/report/view_reports" });
                    referrer = com.dotmarketing.util.PortletURLUtil.getRenderURL(((ActionRequestImpl) req).getHttpServletRequest(), javax.portlet.WindowState.MAXIMIZED.toString(), params);
                    _sendToReferral(req, res, referrer);
                    return;
                } catch (Exception ex) {
                    HibernateUtil.rollbackTransaction();
                    Logger.error(this, "Unable to save Report: " + ex.toString());
                    File f;
                    Logger.info(this, "Trying to delete jrxml");
                    try {
                        f = new File(jrxmlPath);
                        f.delete();
                    } catch (Exception e) {
                        Logger.info(this, "Unable to delete jrxml. This is usually because the file doesn't exist.");
                    }
                    try {
                        f = new File(jasperPath);
                        f.delete();
                    } catch (Exception e) {
                        Logger.info(this, "Unable to delete jasper. This is usually because the file doesn't exist.");
                    }
                    if (badParameters) {
                        SessionMessages.add(req, "error", ex.getMessage());
                    } else {
                        SessionMessages.add(req, "error", "message.report.compile.error");
                    }
                    setForward(req, "portlet.ext.report.edit_report");
                    return;
                }
            } else {
                setForward(req, "portlet.ext.report.edit_report");
            }
        }
        if ((cmd != null) && cmd.equals("downloadReportSource")) {
            ActionResponseImpl resImpl = (ActionResponseImpl) res;
            HttpServletResponse response = resImpl.getHttpServletResponse();
            if (!downloadSourceReport(reportId, httpReq, response)) {
                SessionMessages.add(req, "error", "message.report.source.file.not.found");
            }
        }
        setForward(req, "portlet.ext.report.edit_report");
    }
```

## f73c5234-029

**A**

```java
public Transaction() throws Exception {
        Connection Conn = null;
        Statement Stmt = null;
        try {
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            Conn = DriverManager.getConnection(DBUrl);
            Conn.setAutoCommit(true);
            Stmt = Conn.createStatement();
            try {
                Stmt.executeUpdate("DROP TABLE trans_test");
            } catch (SQLException sqlEx) {
            }
            Stmt.executeUpdate("CREATE TABLE trans_test (id int not null primary key, decdata double) type=BDB");
            Conn.setAutoCommit(false);
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (1, 21.0)");
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (2, 23.485115)");
            Conn.rollback();
            System.out.println("Roll Ok");
            ResultSet RS = Stmt.executeQuery("SELECT * from trans_test");
            if (!RS.next()) {
                System.out.println("Ok");
            } else {
                System.out.println("Rollback failed");
            }
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (2, 23.485115)");
            Stmt.executeUpdate("INSERT INTO trans_test (id, decdata) VALUES (1, 21.485115)");
            Conn.commit();
            RS = Stmt.executeQuery("SELECT * from trans_test where id=2");
            if (RS.next()) {
                System.out.println(RS.getDouble(2));
                System.out.println("Ok");
            } else {
                System.out.println("Rollback failed");
            }
        } catch (Exception ex) {
            throw ex;
        } finally {
            if (Stmt != null) {
                try {
                    Stmt.close();
                } catch (SQLException SQLEx) {
                }
            }
            if (Conn != null) {
                try {
                    Conn.close();
                } catch (SQLException SQLEx) {
                }
            }
        }
    }
```

**B**

```java
public Source get_source(String pageURL, Boolean checkInBase) {
        URL url;
        URLConnection conn;
        Reader inReader;
        Source source = null;
        String LastModified = "";
        Boolean updateData = false;
        try {
            url = new URL(pageURL);
            conn = url.openConnection();
            conn.setRequestProperty("Accept-Charset", "windows-1251");
            if (checkInBase) {
                for (int i = 0; ; i++) {
                    String name = conn.getHeaderFieldKey(i);
                    String value = conn.getHeaderField(i);
                    if (name == null && value == null) {
                        break;
                    }
                    if ("Last-Modified".equals(name)) {
                        LastModified = value;
                    }
                }
                Ini.rs = Ini.stmt.executeQuery("select count(1) as qwe from " + " PUBLIC.PAGES " + "where url = '" + pageURL + "';");
                Ini.rs.next();
                if (Ini.rs.getInt("qwe") == 0) {
                    Ini.stmt.executeUpdate("insert into PUBLIC.PAGES(url, lastUpdateDate) " + " values('" + pageURL + "', " + "'" + LastModified + "'" + ");");
                } else {
                    Ini.rs = Ini.stmt.executeQuery("select lastUpdateDate from " + " PUBLIC.PAGES " + "where url = '" + pageURL + "';");
                    Ini.rs.next();
                    if (!Ini.rs.getString("lastUpdateDate").equals(LastModified)) {
                        updateData = true;
                    } else {
                        return null;
                    }
                }
            }
            inReader = new InputStreamReader(conn.getInputStream(), "windows-1251");
            source = new Source(inReader);
            source.setLogger(null);
            source.fullSequentialParse();
            if (updateData) {
                Ini.stmt.executeUpdate("delete from PUBLIC.LINKDATA " + "where id in (" + "select id from PUBLIC.PAGES " + "where url = '" + pageURL + "'" + ")");
                Ini.stmt.executeUpdate("delete from PUBLIC.PAGES " + "where url = '" + pageURL + "';");
                Ini.stmt.executeUpdate("insert into PUBLIC.PAGES " + " values('" + pageURL + "', " + "'" + LastModified + "'" + ");");
            }
        } catch (Exception ex) {
            Ini.logger.fatal("Error: ", ex);
        }
        return source;
    }
```

## f73c5234-030

**A**

```java
public void testCodingCompletedFromFile() throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        WritableByteChannel channel = newChannel(baos);
        HttpParams params = new BasicHttpParams();
        SessionOutputBuffer outbuf = new SessionOutputBufferImpl(1024, 128, params);
        HttpTransportMetricsImpl metrics = new HttpTransportMetricsImpl();
        LengthDelimitedEncoder encoder = new LengthDelimitedEncoder(channel, outbuf, metrics, 5);
        encoder.write(wrap("stuff"));
        File tmpFile = File.createTempFile("testFile", "txt");
        FileOutputStream fout = new FileOutputStream(tmpFile);
        OutputStreamWriter wrtout = new OutputStreamWriter(fout);
        wrtout.write("more stuff");
        wrtout.flush();
        wrtout.close();
        try {
            FileChannel fchannel = new FileInputStream(tmpFile).getChannel();
            encoder.transfer(fchannel, 0, 10);
            fail("IllegalStateException should have been thrown");
        } catch (IllegalStateException ex) {
        } finally {
            tmpFile.delete();
        }
    }
```

**B**

```java
public void compressImage(InputStream input, OutputStream output, DjatokaEncodeParam params) throws DjatokaException {
        if (params == null) params = new DjatokaEncodeParam();
        File inputFile = null;
        try {
            inputFile = File.createTempFile("tmp", ".tif");
            IOUtils.copyStream(input, new FileOutputStream(inputFile));
            if (params.getLevels() == 0) {
                ImageRecord dim = ImageRecordUtils.getImageDimensions(inputFile.getAbsolutePath());
                params.setLevels(ImageProcessingUtils.getLevelCount(dim.getWidth(), dim.getHeight()));
                dim = null;
            }
        } catch (IOException e1) {
            logger.error("Unexpected file format; expecting uncompressed TIFF", e1);
            throw new DjatokaException("Unexpected file format; expecting uncompressed TIFF");
        }
        String out = STDOUT;
        File winOut = null;
        if (isWindows) {
            try {
                winOut = File.createTempFile("pipe_", ".jp2");
            } catch (IOException e) {
                logger.error(e, e);
                throw new DjatokaException(e);
            }
            out = winOut.getAbsolutePath();
        }
        String command = getKduCompressCommand(inputFile.getAbsolutePath(), out, params);
        logger.debug("compressCommand: " + command);
        Runtime rt = Runtime.getRuntime();
        try {
            final Process process = rt.exec(command, envParams, new File(env));
            if (out.equals(STDOUT)) {
                IOUtils.copyStream(process.getInputStream(), output);
            } else if (isWindows) {
                FileInputStream fis = new FileInputStream(out);
                IOUtils.copyStream(fis, output);
                fis.close();
            }
            process.waitFor();
            if (process != null) {
                String errorCheck = null;
                try {
                    errorCheck = new String(IOUtils.getByteArray(process.getErrorStream()));
                } catch (Exception e1) {
                    logger.error(e1, e1);
                }
                process.getInputStream().close();
                process.getOutputStream().close();
                process.getErrorStream().close();
                process.destroy();
                if (errorCheck != null) throw new DjatokaException(errorCheck);
            }
        } catch (IOException e) {
            logger.error(e, e);
            throw new DjatokaException(e);
        } catch (InterruptedException e) {
            logger.error(e, e);
            throw new DjatokaException(e);
        }
        if (inputFile != null) inputFile.delete();
        if (winOut != null) winOut.delete();
    }
```

## f73c5234-031

**A**

```java
private void loadServers() {
        try {
            URL url = new URL(VirtualDeckConfig.SERVERS_URL);
            cmbServer.addItem("Local");
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String str;
            if (in.readLine().equals("[list]")) {
                while ((str = in.readLine()) != null) {
                    String[] host_line = str.split(";");
                    Host h = new Host();
                    h.setIp(host_line[0]);
                    h.setPort(Integer.parseInt(host_line[1]));
                    h.setName(host_line[2]);
                    getServers().add(h);
                    cmbServer.addItem(h.getName());
                }
            }
            in.close();
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
    }
```

**B**

```java
public static String send(String ipStr, int port, String password, String command, InetAddress localhost, int localPort) throws SocketTimeoutException, BadRcon, ResponseEmpty {
        StringBuffer response = new StringBuffer();
        try {
            rconSocket = new Socket();
            rconSocket.bind(new InetSocketAddress(localhost, localPort));
            rconSocket.connect(new InetSocketAddress(ipStr, port), RESPONSE_TIMEOUT);
            out = rconSocket.getOutputStream();
            in = rconSocket.getInputStream();
            BufferedReader buffRead = new BufferedReader(new InputStreamReader(in));
            rconSocket.setSoTimeout(RESPONSE_TIMEOUT);
            String digestSeed = "";
            boolean loggedIn = false;
            boolean keepGoing = true;
            while (keepGoing) {
                String receivedContent = buffRead.readLine();
                if (receivedContent.startsWith("### Digest seed: ")) {
                    digestSeed = receivedContent.substring(17, receivedContent.length());
                    try {
                        MessageDigest md5 = MessageDigest.getInstance("MD5");
                        md5.update(digestSeed.getBytes());
                        md5.update(password.getBytes());
                        String digestStr = "login " + digestedToHex(md5.digest()) + "\n";
                        out.write(digestStr.getBytes());
                    } catch (NoSuchAlgorithmException e1) {
                        response.append("MD5 algorithm not available - unable to complete RCON request.");
                        keepGoing = false;
                    }
                } else if (receivedContent.startsWith("error: not authenticated: you can only invoke 'login'")) {
                    throw new BadRcon();
                } else if (receivedContent.startsWith("Authentication failed.")) {
                    throw new BadRcon();
                } else if (receivedContent.startsWith("Authentication successful, rcon ready.")) {
                    keepGoing = false;
                    loggedIn = true;
                }
            }
            if (loggedIn) {
                String cmd = "exec " + command + "\n";
                out.write(cmd.getBytes());
                readResponse(buffRead, response);
                if (response.length() == 0) {
                    throw new ResponseEmpty();
                }
            }
        } catch (SocketTimeoutException timeout) {
            throw timeout;
        } catch (UnknownHostException e) {
            response.append("UnknownHostException: " + e.getMessage());
        } catch (IOException e) {
            response.append("Couldn't get I/O for the connection: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
                if (rconSocket != null) {
                    rconSocket.close();
                }
            } catch (IOException e1) {
            }
        }
        return response.toString();
    }
```

## f73c5234-032

**A**

```java
@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String contentId = req.getParameter(CONTENT_ID);
        String contentType = req.getParameter(CONTENT_TYPE);
        if (contentId == null || contentType == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Content id or content type not specified");
            return;
        }
        try {
            switch(ContentType.valueOf(contentType)) {
                case IMAGE:
                    resp.setContentType("image/jpeg");
                    break;
                case AUDIO:
                    resp.setContentType("audio/mp3");
                    break;
                case VIDEO:
                    resp.setContentType("video/mpeg");
                    break;
                default:
                    throw new IllegalStateException("Invalid content type specified");
            }
        } catch (IllegalArgumentException e) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid content type specified");
            return;
        }
        String baseUrl = this.getServletContext().getInitParameter(BASE_URL);
        URL url = new URL(baseUrl + "/" + contentType.toLowerCase() + "/" + contentId);
        URLConnection conn = url.openConnection();
        resp.setContentLength(conn.getContentLength());
        IOUtils.copy(conn.getInputStream(), resp.getOutputStream());
    }
```

**B**

```java
@Override
    public void process(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String userAgentGroup = processUserAgent(request);
        final LiwenxRequest lRequest = new LiwenxRequestImpl(request, response, messageSource, userAgentGroup);
        Locator loc = router.route(lRequest);
        if (loc instanceof RedirectLocator) {
            response.sendRedirect(((RedirectLocator) loc).getPage());
        } else {
            ((AbstractLiwenxRequest) lRequest).setRequestedLocator(loc);
            try {
                LiwenxResponse resp = processPage(lRequest, lRequest.getRequestedLocator(), maxRedirections);
                processHeaders(resp, response);
                processCookies(resp, response);
                if (resp instanceof ExternalRedirectionResponse) {
                    response.sendRedirect(((ExternalRedirectionResponse) resp).getRedirectTo());
                } else if (resp instanceof BinaryResponse) {
                    BinaryResponse bResp = (BinaryResponse) resp;
                    response.setContentType(bResp.getMimeType().toString());
                    IOUtils.copy(bResp.getInputStream(), response.getOutputStream());
                } else if (resp instanceof XmlResponse) {
                    final Element root = ((XmlResponse) resp).getXml();
                    Document doc = root.getDocument();
                    if (doc == null) {
                        doc = new Document(root);
                    }
                    final Locator l = lRequest.getCurrentLocator();
                    final Device device = l.getDevice();
                    response.setContentType(calculateContentType(device));
                    response.setCharacterEncoding(encoding);
                    if (device == Device.HTML) {
                        view.processView(doc, l.getLocale(), userAgentGroup, response.getWriter());
                    } else {
                        Serializer s = new Serializer(response.getOutputStream(), encoding);
                        s.write(doc);
                    }
                }
            } catch (PageNotFoundException e) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            } catch (TooManyRedirectionsException e) {
                throw e;
            } catch (Exception e) {
                throw e;
            }
        }
    }
```

## f73c5234-033

**A**

```java
public static void main(String[] args) throws NoSuchAlgorithmException {
        String password = "root";
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.update(password.getBytes());
        final byte[] digest = messageDigest.digest();
        final StringBuilder buf = new StringBuilder(digest.length * 2);
        for (int j = 0; j < digest.length; j++) {
            buf.append(HEX_DIGITS[(digest[j] >> 4) & 0x0f]);
            buf.append(HEX_DIGITS[digest[j] & 0x0f]);
        }
        String pwd = buf.toString();
        System.out.println(pwd);
    }
```

**B**

```java
public static byte[] clearPassToUserPassword(String clearpass, HashAlg alg, byte[] salt) {
        if (alg == null) {
            throw new IllegalArgumentException("Invalid hash argorithm.");
        }
        try {
            MessageDigest digester = null;
            StringBuilder resultInText = new StringBuilder();
            switch(alg) {
                case MD5:
                    resultInText.append("{MD5}");
                    digester = MessageDigest.getInstance("MD5");
                    break;
                case SMD5:
                    resultInText.append("{SMD5}");
                    digester = MessageDigest.getInstance("MD5");
                    break;
                case SHA:
                    resultInText.append("{SHA}");
                    digester = MessageDigest.getInstance("SHA");
                    break;
                case SSHA:
                    resultInText.append("{SSHA}");
                    digester = MessageDigest.getInstance("SHA");
                    break;
                default:
                    break;
            }
            digester.reset();
            digester.update(clearpass.getBytes(DEFAULT_ENCODING));
            byte[] hash = null;
            if (salt != null && (alg == HashAlg.SMD5 || alg == HashAlg.SSHA)) {
                digester.update(salt);
                hash = ArrayUtils.addAll(digester.digest(), salt);
            } else {
                hash = digester.digest();
            }
            resultInText.append(new String(Base64.encodeBase64(hash), DEFAULT_ENCODING));
            return resultInText.toString().getBytes(DEFAULT_ENCODING);
        } catch (UnsupportedEncodingException uee) {
            log.warn("Error occurred while hashing password ", uee);
            return new byte[0];
        } catch (java.security.NoSuchAlgorithmException nse) {
            log.warn("Error occurred while hashing password ", nse);
            return new byte[0];
        }
    }
```

## f73c5234-034

**A**

```java
private void checkRoundtrip(byte[] content) throws Exception {
        InputStream in = new ByteArrayInputStream(content);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        CodecUtil.encodeQuotedPrintableBinary(in, out);
        in = new QuotedPrintableInputStream(new ByteArrayInputStream(out.toByteArray()));
        out = new ByteArrayOutputStream();
        IOUtils.copy(in, out);
        assertEquals(content, out.toByteArray());
    }
```

**B**

```java
protected byte[] readGZippedBytes(TupleInput in) {
        final boolean is_compressed = in.readBoolean();
        byte array[] = readBytes(in);
        if (array == null) return null;
        if (!is_compressed) {
            return array;
        }
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(array);
            GZIPInputStream gzin = new GZIPInputStream(bais);
            ByteArrayOutputStream baos = new ByteArrayOutputStream(array.length);
            IOUtils.copyTo(gzin, baos);
            gzin.close();
            bais.close();
            return baos.toByteArray();
        } catch (IOException err) {
            throw new RuntimeException(err);
        }
    }
```

## f73c5234-035

**A**

```java
public String doAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - start");
        }
        t_information_EditMap editMap = new t_information_EditMap();
        try {
            t_information_Form vo = null;
            vo = (t_information_Form) form;
            vo.setCompany(vo.getCounty());
            if ("����".equals(vo.getInfo_type())) {
                vo.setInfo_level(null);
                vo.setAlert_level(null);
            }
            String str_postFIX = "";
            int i_p = 0;
            editMap.add(vo);
            try {
                logger.info("���͹�˾�鱨��");
                String[] mobiles = request.getParameterValues("mobiles");
                vo.setMobiles(mobiles);
                SMSService.inforAlert(vo);
            } catch (Exception e) {
                logger.error("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)", e);
            }
            String filename = vo.getFile().getFileName();
            if (null != filename && !"".equals(filename)) {
                FormFile file = vo.getFile();
                String realpath = getServlet().getServletContext().getRealPath("/");
                realpath = realpath.replaceAll("\\\\", "/");
                String inforId = vo.getId();
                String rootFilePath = getServlet().getServletContext().getRealPath(request.getContextPath());
                rootFilePath = (new StringBuilder(String.valueOf(rootFilePath))).append(UploadFileOne.strPath).toString();
                String strAppend = (new StringBuilder(String.valueOf(UUIDGenerator.nextHex()))).append(UploadFileOne.getFileType(file)).toString();
                if (file.getFileSize() != 0) {
                    file.getInputStream();
                    String name = file.getFileName();
                    i_p = file.getFileName().lastIndexOf(".");
                    str_postFIX = file.getFileName().substring(i_p, file.getFileName().length());
                    String fullPath = realpath + "attach/" + strAppend + str_postFIX;
                    t_attach attach = new t_attach();
                    attach.setAttach_fullname(fullPath);
                    attach.setAttach_name(name);
                    attach.setInfor_id(Integer.parseInt(inforId));
                    attach.setInsert_day(new Date());
                    attach.setUpdate_day(new Date());
                    t_attach_EditMap attachEdit = new t_attach_EditMap();
                    attachEdit.add(attach);
                    File sysfile = new File(fullPath);
                    if (!sysfile.exists()) {
                        sysfile.createNewFile();
                    }
                    java.io.OutputStream out = new FileOutputStream(sysfile);
                    org.apache.commons.io.IOUtils.copy(file.getInputStream(), out);
                    out.close();
                }
            }
        } catch (HibernateException e) {
            logger.error("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse)", e);
            ActionErrors errors = new ActionErrors();
            errors.add("org.apache.struts.action.GLOBAL_ERROR", new ActionError("error.database.save", e.toString()));
            saveErrors(request, errors);
            e.printStackTrace();
            request.setAttribute("t_information_Form", form);
            if (logger.isDebugEnabled()) {
                logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - end");
            }
            return "addpage";
        }
        if (logger.isDebugEnabled()) {
            logger.debug("doAdd(ActionMapping, ActionForm, HttpServletRequest, HttpServletResponse) - end");
        }
        return "aftersave";
    }
```

**B**

```java
public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String limitsSet = "";
        String synstatus = SystemFilesLoader.getInstance().getNewgenlibProperties().getProperty("SYNDETICS", "OFF");
        String synncode = SystemFilesLoader.getInstance().getNewgenlibProperties().getProperty("SYNDETICS_CLIENT_CODE", "");
        try {
            if (request.getSession().getAttribute("searchLimits") != null) {
                System.out.println("searchLimits set");
                limitsSet = "SET";
                java.util.Hashtable htLimits = new java.util.Hashtable();
                htLimits = (java.util.Hashtable) request.getSession().getAttribute("searchLimits");
            } else {
                limitsSet = "UNSET";
                System.out.println("searchLimits not set");
            }
            java.util.Properties prop = System.getProperties();
            prop.load(new FileInputStream(ejb.bprocess.util.NewGenLibRoot.getRoot() + java.io.File.separator + "SystemFiles" + java.io.File.separator + "ENV_VAR.txt"));
            System.out.println("SEARCH MODE IS " + searchmode + " FILE PATH " + ejb.bprocess.util.NewGenLibRoot.getRoot() + java.io.File.separator + "SystemFiles" + java.io.File.separator + "ENV_VAR.txt");
        } catch (Exception e) {
        }
        javax.servlet.http.HttpSession session = request.getSession();
        String forward = "searchView";
        int link = 0, singleLink = 0;
        java.util.Vector vecThisPage = new java.util.Vector();
        aportal.form.cataloguing.SearchViewForm svF = (aportal.form.cataloguing.SearchViewForm) form;
        svF.setSyndeticsStatus(synstatus);
        svF.setSyndeticsClientCode(synncode);
        opacHm = (ejb.bprocess.opac.xcql.OPACUtilitiesHome) ejb.bprocess.util.HomeFactory.getInstance().getRemoteHome("OPACUtilities");
        ejb.bprocess.opac.xcql.OPACUtilities opacUt = opacHm.create();
        System.out.println("CLASS NO " + request.getParameter("ClassNo") + " ClassNoForwarded " + session.getAttribute("ClassNoForwarded"));
        if (svF.getExportRec() == null || !(svF.getExportRec().equals("export"))) {
            if (request.getParameter("CatId") != null && request.getParameter("OwnerId") != null && request.getParameter("relation") != null && !(session.getAttribute("HostItemDisplay") != null && session.getAttribute("HostItemDisplay").toString().equals("false"))) {
                home = (ejb.bprocess.opac.xcql.SearchSRUWCatalogueHome) ejb.bprocess.util.HomeFactory.getInstance().getRemoteHome("SearchSRUWCatalogue");
                ejb.bprocess.opac.xcql.SearchSRUWCatalogue searchCat = home.create();
                String catId1 = request.getParameter("CatId");
                String ownId1 = request.getParameter("OwnerId");
                System.out.println("*********************CatId1: " + catId1);
                svF.setCatalogueRecordId(catId1);
                svF.setOwnerLibraryId(ownId1);
                String rel = request.getParameter("relation");
                java.util.Vector vecL = searchCat.getRelatedCatalogueRecords(null, catId1, ownId1, rel);
                request.setAttribute("LuceneVector", vecL);
                session.setAttribute("searchVec", vecL);
                singleLink = 1;
                session.setAttribute("HostItemDisplay", "false");
                link = 1;
                forward = "searchRes";
                vecThisPage.addElement(catId1);
                vecThisPage.addElement(ownId1);
            } else if (link == 0 || singleLink == 1) {
                System.out.println("LINK AND SINGLE LINK " + link + " single " + singleLink);
                if ((request.getParameter("ClassNo") != null) && session.getAttribute("ClassNoForwarded") == null) {
                    System.out.println("action called for class no.");
                    String classificNo = request.getParameter("ClassNo");
                    System.out.println("TITLE WORDS ");
                    home = (ejb.bprocess.opac.xcql.SearchSRUWCatalogueHome) ejb.bprocess.util.HomeFactory.getInstance().getRemoteHome("SearchSRUWCatalogue");
                    ejb.bprocess.opac.xcql.SearchSRUWCatalogue searchCat = home.create();
                    String rawSearchText = (new beans.miscellaneous.RequestStringProcessor()).processString("*" + classificNo + "*");
                    System.out.println("raw search Text" + rawSearchText);
                    String searchText = "classificationNumber=" + rawSearchText;
                    System.out.println("search text is " + searchText);
                    String xmlRes = (new org.z3950.zing.cql.CQLParser()).parse(searchText).toXCQL(0);
                    java.util.Hashtable hs = new java.util.Hashtable();
                    java.util.Vector v1 = new java.util.Vector();
                    if (session.getAttribute("searchLimits") != null) {
                        hs = (java.util.Hashtable) session.getAttribute("searchLimits");
                    }
                    Vector vec = new Vector();
                    String solrQuery = Utility.getInstance().simplifiedSolrQuery(classificNo, "classificationNumber");
                    if (limitsSet.equalsIgnoreCase("SET")) {
                        String limitsQuery = limitsSolrQuery(hs);
                        solrQuery += limitsQuery;
                    }
                    solrQuery += " & ";
                    Vector newRetvec = searchCat.processSolrQuery(1, 25, solrQuery, "245_Tag", "asc");
                    Hashtable ht = (Hashtable) newRetvec.get(0);
                    String totrec = (String) ht.get("HITS");
                    session.setAttribute("TOTALREC", Integer.parseInt(totrec));
                    v1 = (Vector) ht.get("RESULTS");
                    hs.put("Query", solrQuery);
                    if (v1.size() > 0) {
                        hs.put("searchText", rawSearchText);
                        hs.put("noOfRecords", 25);
                        hs.put("browseType", "Classification Number");
                        session.setAttribute("searchEntry", hs);
                        session.setAttribute("searchVec", v1);
                        forward = "searchRes";
                    } else {
                        forward = "home";
                    }
                } else {
                    System.out.println("ELSE CALLED ");
                    String record = request.getParameter("record");
                    String recNo = request.getParameter("recNo");
                    Integer catId = 0, ownerId = 0;
                    String title = "";
                    if (request.getParameter("CatId") != null && request.getParameter("OwnerId") != null) {
                        catId = new Integer(request.getParameter("CatId")).intValue();
                        ownerId = new Integer(request.getParameter("OwnerId")).intValue();
                        System.out.println("catId is +++=" + catId);
                        System.out.println("OwnerId is +++=" + ownerId);
                        title = request.getParameter("title");
                        svF.setCatalogueRecordId(request.getParameter("CatId"));
                        svF.setOwnerLibraryId(request.getParameter("OwnerId"));
                    }
                    System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%VVVVVVVVVVVVVVVVVVVVVV");
                    ArrayList alOtherBooks = ((ejb.bprocess.opac.SearchCatalogue) ejb.bprocess.util.HomeFactory.getInstance().getHome("SearchCatalogue")).getOtherBooksInTheRack(null, catId.toString(), ownerId.toString(), ownerId.toString());
                    System.out.println("alOtherBooks size is  " + alOtherBooks.size());
                    Vector vOtherBooks = new Vector();
                    Session catrecsession = DBConnector.getInstance().getSession();
                    utility = ejb.bprocess.util.Utility.getInstance(catrecsession);
                    for (int i = 0; i < alOtherBooks.size(); i++) {
                        String[] scData = (String[]) (alOtherBooks.get(i));
                        String catalogueId = scData[0];
                        String ownerLibId = scData[1];
                        System.out.println("catId is +++=" + catalogueId);
                        System.out.println("OwnerId is +++=" + ownerLibId);
                        String xmlWholeRecord = "";
                        String titleD = "";
                        String titleV = "";
                        String authorV = "";
                        String isbnNumber = "";
                        if (catalogueId != null && ownerLibId != null) {
                            try {
                                System.out.println("***************************** 0");
                                Hashtable htDetails = utility.getCatalogueRecord(new Integer(catalogueId), new Integer(ownerLibId));
                                System.out.println("***************************** 1");
                                if (htDetails != null && !htDetails.isEmpty()) {
                                    System.out.println("htDetails" + htDetails.toString());
                                    titleV = utility.getTestedString(htDetails.get("Title"));
                                    authorV = utility.getTestedString(htDetails.get("Author"));
                                    isbnNumber = utility.getTestedString(htDetails.get("ISBN"));
                                    String[] str1 = titleV.split("/");
                                    if (str1.length > 0) {
                                        titleD = str1[0];
                                        if (titleD.length() > 45) {
                                            titleD = titleD.substring(0, 45) + "...";
                                        }
                                    }
                                    String[] str = new String[5];
                                    str[0] = titleD;
                                    str[1] = authorV;
                                    str[2] = isbnNumber;
                                    str[3] = catalogueId;
                                    str[4] = ownerLibId;
                                    vOtherBooks.add(str);
                                    System.out.println("Other Books size is " + vOtherBooks.size());
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    System.out.println("Other Books vector is *************************** \n ");
                    for (int i = 0; i < vOtherBooks.size(); i++) {
                        String[] str = (String[]) vOtherBooks.get(i);
                        System.out.println("title   :" + str[0].toString());
                        System.out.println("author  :" + str[1].toString());
                        System.out.println("isbn  :" + str[2].toString());
                        System.out.println("catID  :" + str[3].toString());
                        System.out.println("ownerLibId  :" + str[4].toString());
                    }
                    System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                    request.setAttribute("fisheyedata", vOtherBooks);
                    catrecsession.close();
                    session.setAttribute("SingleViewExport", vecThisPage);
                    if (session.getAttribute("OnlySingleRec") != null && session.getAttribute("OnlySingleRec").toString().equals("true")) {
                        java.util.Vector v1 = new java.util.Vector();
                        System.out.println("SEARCH MODE " + searchmode);
                        if (searchmode.equalsIgnoreCase("a")) {
                            System.out.println("SEARCHMODE IN SEARCH VIEW ACTION (IF) " + searchmode);
                            v1 = (java.util.Vector) request.getAttribute("LuceneVector");
                            System.out.println("VECTOR V1 " + v1);
                        } else {
                            System.out.println("SEARCHMODE IN SEARCH VIEW ACTION (ELSE)" + searchmode);
                            v1 = (java.util.Vector) session.getAttribute("searchVec");
                        }
                        Object[] obj = (Object[]) v1.elementAt(0);
                        String str[] = (String[]) obj[0];
                        java.util.Hashtable h = new java.util.Hashtable();
                        String tit = "";
                        h = (java.util.Hashtable) obj[1];
                        System.out.println("HASH TABLE in view action " + h);
                        catId = new Integer(str[0]).intValue();
                        ownerId = new Integer(str[1]).intValue();
                        title = h.get("TITLE").toString();
                        svF.setAttachmentsAndUrl("");
                        if ((h.get("ATTACHMENTS") != null && h.get("ATTACHMENTS").equals("AVAILABLE"))) {
                            svF.setAttachmentsAndUrl("available");
                        }
                        record = "full";
                        recNo = "1";
                        session.removeAttribute("OnlySingleRec");
                    }
                    if (session.getAttribute("HostItemDisplay") != null && session.getAttribute("HostItemDisplay").equals("false")) {
                        session.removeAttribute("HostItemDisplay");
                    }
                    session.setAttribute("Title", title);
                    java.util.Hashtable hash1 = opacUt.getDetailsForSingleCatalogueRecord(catId, ownerId);
                    vecThisPage.addElement(String.valueOf(catId));
                    vecThisPage.addElement(String.valueOf(ownerId));
                    svF.setAttachmentsAndUrl("");
                    if (hash1.get("ATTACHMENTS") != null && hash1.get("ATTACHMENTS").toString().equals("AVAILABLE")) {
                        svF.setAttachmentsAndUrl("available");
                    }
                    svF.setRecordNo(recNo);
                    session.setAttribute("record", record);
                    java.util.Vector vecCO = (java.util.Vector) session.getAttribute("CatAndOwner");
                    svF.setCatCur(catId);
                    svF.setOwnerCur(ownerId);
                    svF.setPrevExists("no");
                    svF.setNextExists("no");
                    if (vecCO != null) {
                        for (int j = 0; j < vecCO.size(); j = j + 4) {
                            int c = new Integer(vecCO.elementAt(j).toString()).intValue();
                            int o = new Integer(vecCO.elementAt(j + 1).toString()).intValue();
                            if (c == catId && o == ownerId) {
                                if (j != 0) {
                                    int catPrev = new Integer(vecCO.elementAt(j - 4).toString()).intValue();
                                    int ownerPrev = new Integer(vecCO.elementAt(j - 3).toString()).intValue();
                                    svF.setCatPrev(catPrev);
                                    svF.setOwnerPrev(ownerPrev);
                                    svF.setTitlePrev(vecCO.elementAt(j - 2).toString());
                                    svF.setRecPrev(vecCO.elementAt(j - 1).toString());
                                    svF.setPrevExists("yes");
                                }
                                if (j < vecCO.size() - 4) {
                                    int catNext = new Integer(vecCO.elementAt(j + 4).toString()).intValue();
                                    int ownerNext = new Integer(vecCO.elementAt(j + 5).toString()).intValue();
                                    svF.setCatNext(catNext);
                                    svF.setOwnerNext(ownerNext);
                                    svF.setTitleNext(vecCO.elementAt(j + 6).toString());
                                    svF.setRecNext(vecCO.elementAt(j + 7).toString());
                                    svF.setNextExists("yes");
                                }
                            }
                        }
                    }
                    String str[] = (String[]) hash1.get("Biblo_Mat");
                    int bib_id = new Integer(str[0]).intValue();
                    int mat_id = new Integer(str[1]).intValue();
                    aportal.view.RecordView rv = new aportal.view.DesignFactory().getCorView(bib_id, mat_id, record);
                    String type = "";
                    if (bib_id == 3 && mat_id == 1) {
                        type = "Book";
                    } else if (bib_id == 4 && mat_id == 1) {
                        type = "Serial";
                    } else if (bib_id == 1 && mat_id == 1) {
                        type = "Book Chapter";
                    } else if (bib_id == 2 && mat_id == 1) {
                        type = "Serial Article";
                    } else {
                        type = ejb.bprocess.util.TypeDefinition.getInstance().getTypeDefinition(String.valueOf(bib_id), String.valueOf(mat_id));
                    }
                    java.util.Hashtable hMono = (java.util.Hashtable) hash1.get("MonoGraphRecords");
                    java.util.Hashtable h4 = rv.getView(hash1);
                    h4.put("Type", type);
                    Hashtable ht = (Hashtable) h4.get("NoLink");
                    if (ht != null && ht.get("URLS_856") != null) {
                        Vector urls856 = (Vector) ht.get("URLS_856");
                        if (urls856.size() > 0) {
                            Hashtable linksAndText = new Hashtable();
                            Hashtable url856 = new Hashtable();
                            for (int i = 0; i < urls856.size(); i += 2) {
                                url856.put(urls856.elementAt(i), urls856.elementAt(i + 1));
                            }
                            linksAndText.put("URL", url856);
                            h4.put("URLS_856", linksAndText);
                        }
                    }
                    try {
                        String sessionid = request.getSession().getId();
                        ejb.bprocess.holdings.HoldingsStatement holdingsStatement = ((ejb.bprocess.holdings.HoldingsStatementHome) ejb.bprocess.util.HomeFactory.getInstance().getRemoteHome("HoldingsStatement")).create();
                        java.util.Vector vecLib = new java.util.Vector();
                        vecLib.addElement("1");
                        if (session.getAttribute("Libraries") != null) {
                            vecLib = (java.util.Vector) session.getAttribute("Libraries");
                        }
                        String libIds = "";
                        for (int p = 0; p < vecLib.size(); p++) {
                            if (p != 0) {
                                libIds += ",";
                            }
                            String libName = vecLib.elementAt(p).toString();
                            Session session1 = DBConnector.getInstance().getSession();
                            libIds += ejb.bprocess.util.Utility.getInstance(session1).getLibraryId(libName);
                            session1.close();
                        }
                        request.setAttribute("catRecId", String.valueOf(catId));
                        request.setAttribute("ownLibId", String.valueOf(ownerId));
                        request.setAttribute("libIds", String.valueOf(libIds));
                        Hashtable onerecordattach = new Hashtable();
                        JSONObject jsonCatOwnId = new JSONObject().put("Id", catId).put("LibId", ownerId);
                        ejb.bprocess.opac.SearchCatalogue searchCatAttach = ((ejb.bprocess.opac.SearchCatalogueHome) ejb.bprocess.util.HomeFactory.getInstance().getRemoteHome("SearchCatalogue")).create();
                        String strAttach = searchCatAttach.getAttachmentDetails(jsonCatOwnId.toString());
                        if (!strAttach.equals("")) {
                            JSONObject jsonAttach = new JSONObject(strAttach);
                            if (jsonAttach != null) {
                                if (!jsonAttach.isNull("BookCover")) {
                                    ArrayList albookcover = new ArrayList();
                                    JSONArray jsonarr = (JSONArray) jsonAttach.get("BookCover");
                                    if (jsonarr != null) {
                                        for (int j = 0; j < jsonarr.length(); j++) {
                                            albookcover.add(jsonarr.getString(j));
                                        }
                                        onerecordattach.put("BookCover", albookcover);
                                    }
                                }
                                if (!jsonAttach.isNull("TOC")) {
                                    ArrayList alTOC = new ArrayList();
                                    JSONArray jsonarr = (JSONArray) jsonAttach.get("TOC");
                                    if (jsonarr != null) {
                                        for (int j = 0; j < jsonarr.length(); j++) {
                                            alTOC.add(jsonarr.getString(j));
                                        }
                                        onerecordattach.put("TOC", alTOC);
                                    }
                                }
                                if (!jsonAttach.isNull("Preview")) {
                                    ArrayList alPreview = new ArrayList();
                                    JSONArray jsonarr = (JSONArray) jsonAttach.get("Preview");
                                    if (jsonarr != null) {
                                        for (int j = 0; j < jsonarr.length(); j++) {
                                            alPreview.add(jsonarr.getString(j));
                                        }
                                        onerecordattach.put("Preview", alPreview);
                                    }
                                }
                                if (!jsonAttach.isNull("FullView")) {
                                    ArrayList alFullView = new ArrayList();
                                    JSONArray jsonarr = (JSONArray) jsonAttach.get("FullView");
                                    if (jsonarr != null) {
                                        for (int j = 0; j < jsonarr.length(); j++) {
                                            alFullView.add(jsonarr.getString(j));
                                        }
                                        onerecordattach.put("FullView", alFullView);
                                    }
                                }
                                if (!jsonAttach.isNull("Attachment")) {
                                    ArrayList alAttachment = new ArrayList();
                                    JSONArray jsonarr = (JSONArray) jsonAttach.get("Attachment");
                                    if (jsonarr != null) {
                                        for (int j = 0; j < jsonarr.length(); j++) {
                                            alAttachment.add(jsonarr.getString(j));
                                        }
                                        onerecordattach.put("Attachment", alAttachment);
                                    }
                                }
                                if (onerecordattach != null && !onerecordattach.isEmpty()) {
                                    h4.put("dAttachment", onerecordattach);
                                }
                            }
                        }
                        svF.setHashSing(h4);
                        System.out.println("hash tabel values*************************");
                        Enumeration enumx = h4.keys();
                        while (enumx.hasMoreElements()) {
                            String key = enumx.nextElement().toString();
                            System.out.println("Key: " + key + "-----value: " + h4.get(key));
                        }
                        System.out.println("********************************************");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } else if (svF.getExportRec() != null && svF.getExportRec().equals("export")) {
            svF.setExportRec(null);
            vecThisPage = (java.util.Vector) session.getAttribute("SingleViewExport");
            String format = svF.getSf();
            if (format.equals("marc")) {
                String marc = opacUt.getDetailsForMultiRecordViewMARC(vecThisPage);
                svF.setDisplayFormat(marc);
                session.setAttribute("RecordDisplay", marc);
                forward = "RecordFormat";
            } else if (format.equals("marcXml")) {
                String marcXML = opacUt.getDetailsForMultiRecordViewMARCXML(vecThisPage);
                svF.setDisplayFormat(marcXML);
                response.setContentType("text/xml");
                session.setAttribute("RecordDisplay", marcXML);
                forward = "RecordFormat";
            } else if (format.equals("mods")) {
                String mods = opacUt.getDetailsForMultiRecordViewMODS(vecThisPage);
                svF.setDisplayFormat(mods);
                session.setAttribute("RecordDisplay", mods);
                forward = "RecordFormat";
            } else if (format.equals("dc")) {
                String dc = opacUt.getDetailsForMultiRecordViewDublinCore(vecThisPage);
                svF.setDisplayFormat(dc);
                session.setAttribute("RecordDisplay", dc);
                forward = "RecordFormat";
            } else if (format.equals("agris")) {
                String agr = opacUt.getDetailsForMultiRecordViewAgris(vecThisPage);
                svF.setDisplayFormat(agr);
                session.setAttribute("RecordDisplay", agr);
                forward = "RecordFormat";
            } else if (format.equals("text")) {
                java.util.Vector vecTextDis = new java.util.Vector();
                for (int i2 = 0; i2 < vecThisPage.size(); i2 = i2 + 2) {
                    java.util.Hashtable hash1 = opacUt.getDetailsForSingleCatalogueRecord(new Integer(vecThisPage.elementAt(i2).toString()).intValue(), new Integer(vecThisPage.elementAt(i2 + 1).toString()).intValue());
                    aportal.view.ISBDView fullView = new aportal.view.ISBDView();
                    java.util.Hashtable hashCit = fullView.getView(hash1);
                    vecTextDis.addElement(hashCit);
                    forward = "RecordFormatText";
                }
                session.setAttribute("RecordTextDisplay", vecTextDis);
                if (svF.getPs() != null && svF.getPs().equals("email")) {
                    boolean flag = false;
                    if (svF.getEmail() != null && !(svF.getEmail().equals(""))) {
                        String emailId = svF.getEmail();
                        try {
                            String sessionid = request.getSession().getId();
                            java.net.URL url = new java.net.URL("http://localhost:" + request.getServerPort() + "/newgenlibctxt/jsp/aportal/cataloguing/RecordDisplayText.jsp;jsessionid=" + sessionid);
                            java.net.URLConnection urlCon = url.openConnection();
                            java.io.InputStream is = urlCon.getInputStream();
                            String htmlContent = "";
                            java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is));
                            String line = "";
                            while ((line = br.readLine()) != null) {
                                htmlContent = htmlContent + line;
                            }
                            String[] emailids = { emailId };
                            int status = SendEmail.getInstance().sendMail(emailids, "OPAC results", htmlContent, "html");
                            if (status == 0) flag = true; else flag = false;
                        } catch (Exception exp) {
                            exp.printStackTrace();
                        }
                    }
                    String mailMessage = "The selected records have been successfully mailed to " + svF.getEmail();
                    if (flag == false) {
                        mailMessage = "<h4><p>The selected records could not be mailed to " + svF.getEmail() + "&nbsp; These might be the possible reasons.</p></h4>" + "<h5><ol> <li>The email id entered is not a valid one</font></li>" + "<li>The email id domain might not be in the list of allowed  recipient&nbsp; hosts</li>" + "<li>There might a error in connectivity to the mail server</li></ol></h5>" + "<h4><p>Please contact the  Network Administrator </p></h4>";
                    }
                    session.setAttribute("MailStatus", mailMessage);
                    forward = "SendEmail";
                }
            }
        }
        String version = ejb.bprocess.util.StaticValues.getInstance().getVersion();
        if (version != null && !version.equals("")) {
            svF.setVersion(version);
        }
        if (session.getAttribute("ClassNoForwarded") != null) {
            session.removeAttribute("ClassNoForwarded");
        }
        return mapping.findForward(forward);
    }
```

## f73c5234-036

**A**

```java
private void sendFile(File file, HttpServletResponse response) throws IOException {
        response.setContentLength((int) file.length());
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            IOUtils.copy(inputStream, response.getOutputStream());
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
    }
```

**B**

```java
public void display(WebPage page, HttpServletRequest req, HttpServletResponse resp) throws DisplayException {
        page.getDisplayInitialiser().initDisplay(new HttpRequestDisplayContext(req), req);
        StreamProvider is = (StreamProvider) req.getAttribute(INPUTSTREAM_KEY);
        if (is == null) {
            throw new IllegalStateException("No OutputStreamDisplayHandlerXML.InputStream found in request attribute" + " OutputStreamDisplayHandlerXML.INPUTSTREAM_KEY");
        }
        resp.setContentType(is.getMimeType());
        resp.setHeader("Content-Disposition", "attachment;filename=" + is.getName());
        try {
            InputStream in = is.getInputStream();
            OutputStream out = resp.getOutputStream();
            if (in != null) {
                IOUtils.copy(in, out);
            }
            is.write(resp.getOutputStream());
            resp.flushBuffer();
        } catch (IOException e) {
            throw new DisplayException("Error writing input stream to response", e);
        }
    }
```

## f73c5234-037

**A**

```java
public void putFile(CompoundName file, FileInputStream fileInput) throws IOException {
        File fullDir = new File(REMOTE_BASE_DIR.getCanonicalPath());
        for (int i = 0; i < file.size() - 1; i++) fullDir = new File(fullDir, file.get(i));
        fullDir.mkdirs();
        File outputFile = new File(fullDir, file.get(file.size() - 1));
        FileOutputStream outStream = new FileOutputStream(outputFile);
        for (int byteIn = fileInput.read(); byteIn != -1; byteIn = fileInput.read()) outStream.write(byteIn);
        fileInput.close();
        outStream.close();
    }
```

**B**

```java
public static void createZipFromDataset(String localResourceId, File dataset, File metadata) {
        CommunicationLogger.warning("System entered ZipFactory");
        try {
            String tmpDir = System.getProperty("java.io.tmpdir");
            String outFilename = tmpDir + "/" + localResourceId + ".zip";
            CommunicationLogger.warning("File name: " + outFilename);
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));
            byte[] buf = new byte[1024];
            FileInputStream in = new FileInputStream(dataset);
            out.putNextEntry(new ZipEntry(dataset.getName()));
            int len;
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            in = new FileInputStream(metadata);
            out.putNextEntry(new ZipEntry(metadata.getName()));
            while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
            out.closeEntry();
            in.close();
            out.close();
        } catch (IOException e) {
            System.out.println("IO EXCEPTION: " + e.getMessage());
        }
    }
```

## f73c5234-038

**A**

```java
private void copyFile(File sourceFile, File targetFile) {
        beNice();
        dispatchEvent(SynchronizationEventType.FileCopy, sourceFile, targetFile);
        File temporaryFile = new File(targetFile.getPath().concat(".jnstemp"));
        while (temporaryFile.exists()) {
            try {
                beNice();
                temporaryFile.delete();
                beNice();
            } catch (Exception ex) {
            }
        }
        try {
            if (targetFile.exists()) {
                targetFile.delete();
            }
            FileInputStream fis = new FileInputStream(sourceFile);
            FileOutputStream fos = new FileOutputStream(temporaryFile);
            byte[] buffer = new byte[204800];
            int readBytes = 0;
            int counter = 0;
            while ((readBytes = fis.read(buffer)) != -1) {
                counter++;
                updateStatus("... processing fragment " + String.valueOf(counter));
                fos.write(buffer, 0, readBytes);
            }
            fis.close();
            fos.close();
            temporaryFile.renameTo(targetFile);
            temporaryFile.setLastModified(sourceFile.lastModified());
            targetFile.setLastModified(sourceFile.lastModified());
        } catch (IOException e) {
            Exception dispatchedException = new Exception("ERROR: Copy File( " + sourceFile.getPath() + ", " + targetFile.getPath() + " )");
            dispatchEvent(dispatchedException, sourceFile, targetFile);
        }
        dispatchEvent(SynchronizationEventType.FileCopyDone, sourceFile, targetFile);
    }
```

**B**

```java
@Override
    public ISource writeTo(ISource output) throws ResourceException {
        try {
            Document doc = getParent().getDocument();
            Nodes places = doc.query(getPosition().getXpath());
            if (places.size() == 0) {
                places = doc.query("//html");
            }
            if (places.size() > 0 && places.get(0) instanceof Element) {
                Element target = (Element) places.get(0);
                List<URL> urls = getResourceURLs();
                if (getType() == EType.TEXT) {
                    Element tag = getHeaderTag();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    UtilIO.writeAllTo(urls, out);
                    String content = out.toString();
                    out.close();
                    tag.appendChild(content);
                    if (getPosition().getPlace() == EPlace.START) {
                        target.insertChild(tag, 0);
                    } else {
                        target.appendChild(tag);
                    }
                } else {
                    for (URL url : urls) {
                        String file = url.toString();
                        String name = file.substring(file.lastIndexOf("/") + 1) + "_res_" + (serialNumber++);
                        Element tag = getHeaderTag(output, name);
                        File resFile = getFile(output, name);
                        if (!resFile.getParentFile().exists()) {
                            if (!resFile.getParentFile().mkdirs()) {
                                throw new ResourceException("Could not create resource directory '" + resFile.getParent() + "'.");
                            }
                        }
                        UtilIO.writeToClose(url.openStream(), new FileOutputStream(resFile));
                        if (getPosition().getPlace() == EPlace.START) {
                            target.insertChild(tag, 0);
                        } else {
                            target.appendChild(tag);
                        }
                    }
                }
            } else {
                throw new ResourceException("Head element not found.");
            }
        } catch (IOException e) {
            throw new ResourceException(e);
        } catch (SourceException e) {
            throw new ResourceException(e);
        }
        return output;
    }
```

## f73c5234-039

**A**

```java
public static void copyFile(File src, File dest, boolean preserveFileDate) throws IOException {
        if (src.exists() && src.isDirectory()) {
            throw new IOException("source file exists but is a directory");
        }
        if (dest.exists() && dest.isDirectory()) {
            dest = new File(dest, src.getName());
        }
        if (!dest.exists()) {
            dest.createNewFile();
        }
        FileChannel srcCH = null;
        FileChannel destCH = null;
        try {
            srcCH = new FileInputStream(src).getChannel();
            destCH = new FileOutputStream(dest).getChannel();
            destCH.transferFrom(srcCH, 0, srcCH.size());
        } finally {
            closeQuietly(srcCH);
            closeQuietly(destCH);
        }
        if (src.length() != dest.length()) {
            throw new IOException("Failed to copy full contents from '" + src + "' to '" + dest + "'");
        }
        if (preserveFileDate) {
            dest.setLastModified(src.lastModified());
        }
    }
```

**B**

```java
public static void copyFile(File src, File dest, boolean force) throws IOException, InterruptedIOException {
        if (dest.exists()) {
            if (force) {
                dest.delete();
            } else {
                throw new IOException("Cannot overwrite existing file!");
            }
        }
        byte[] buffer = new byte[5 * 1024 * 1024];
        int read = 0;
        InputStream in = null;
        OutputStream out = null;
        try {
            in = new BufferedInputStream(new FileInputStream(src));
            out = new BufferedOutputStream(new FileOutputStream(dest));
            while (true) {
                read = in.read(buffer);
                if (read == -1) {
                    break;
                }
                out.write(buffer, 0, read);
            }
        } finally {
            buffer = null;
            if (in != null) {
                try {
                    in.close();
                } finally {
                    if (out != null) {
                        out.close();
                    }
                }
            }
        }
    }
```

## f73c5234-040

**A**

```java
PackageFileImpl(PackageDirectoryImpl dir, String name, InputStream data) throws IOException {
        this.dir = dir;
        this.name = name;
        this.updates = dir.getUpdates();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        IOUtils.copy(data, stream);
        updates.setNewData(getFullName(), stream.toByteArray());
        stream.close();
    }
```

**B**

```java
public String fileUpload(final ResourceType type, final String currentFolder, final String fileName, final InputStream inputStream) throws InvalidCurrentFolderException, WriteException {
        String absolutePath = getRealUserFilesAbsolutePath(RequestCycleHandler.getUserFilesAbsolutePath(ThreadLocalData.getRequest()));
        File typeDir = getOrCreateResourceTypeDir(absolutePath, type);
        File currentDir = new File(typeDir, currentFolder);
        if (!currentDir.exists() || !currentDir.isDirectory()) throw new InvalidCurrentFolderException();
        File newFile = new File(currentDir, fileName);
        File fileToSave = UtilsFile.getUniqueFile(newFile.getAbsoluteFile());
        try {
            IOUtils.copyLarge(inputStream, new FileOutputStream(fileToSave));
        } catch (IOException e) {
            throw new WriteException();
        }
        return fileToSave.getName();
    }
```

## f73c5234-041

**A**

```java
public void getZipFiles(String filename) {
        try {
            String destinationname = "c:\\mods\\peu\\";
            byte[] buf = new byte[1024];
            ZipInputStream zipinputstream = null;
            ZipEntry zipentry;
            zipinputstream = new ZipInputStream(new FileInputStream(filename));
            zipentry = zipinputstream.getNextEntry();
            while (zipentry != null) {
                String entryName = zipentry.getName();
                System.out.println("entryname " + entryName);
                int n;
                FileOutputStream fileoutputstream;
                File newFile = new File(entryName);
                String directory = newFile.getParent();
                if (directory == null) {
                    if (newFile.isDirectory()) break;
                }
                fileoutputstream = new FileOutputStream(destinationname + entryName);
                while ((n = zipinputstream.read(buf, 0, 1024)) > -1) fileoutputstream.write(buf, 0, n);
                fileoutputstream.close();
                zipinputstream.closeEntry();
                zipentry = zipinputstream.getNextEntry();
            }
            zipinputstream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
```

**B**

```java
@SuppressWarnings("unchecked")
    public static void unzip(String input, String output) {
        try {
            if (!output.endsWith("/")) output = output + "/";
            ZipFile zip = new ZipFile(input);
            Enumeration entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                if (entry.isDirectory()) {
                    FileUtils.forceMkdir(new File(output + entry.getName()));
                } else {
                    FileOutputStream out = new FileOutputStream(output + entry.getName());
                    IOUtils.copy(zip.getInputStream(entry), out);
                    IOUtils.closeQuietly(out);
                }
            }
        } catch (Exception e) {
            log.error("�����ҵ��ļ�:" + output, e);
            throw new RuntimeException("�����ҵ��ļ�:" + output, e);
        }
    }
```

## f73c5234-042

**A**

```java
public static String md5Encode16(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes("utf-8"));
            byte b[] = md.digest();
            int i;
            StringBuilder buf = new StringBuilder("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0) i += 256;
                if (i < 16) buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            return buf.toString().substring(8, 24);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(e);
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException(e);
        }
    }
```

**B**

```java
private String getAuthUrlString(String account, String password) throws IOException, NoSuchAlgorithmException {
        Map<String, String> dict = retrieveLoginPage();
        if (dict == null) {
            return null;
        }
        StringBuilder url = new StringBuilder("/config/login?login=");
        url.append(account);
        url.append("&passwd=");
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        md5.update(password.getBytes(), 0, password.length());
        byte[] result = md5.digest();
        for (int i = 0; i < 16; i++) {
            url.append(StringUtil.toHex2(result[i]));
        }
        String md5chal = dict.get(".challenge");
        md5 = MessageDigest.getInstance("MD5");
        md5.update(md5chal.getBytes(), 0, md5chal.length());
        result = md5.digest();
        for (int i = 0; i < 16; i++) {
            url.append(StringUtil.toHex2(result[i]));
        }
        Iterator<String> j = dict.keySet().iterator();
        while (j.hasNext()) {
            String key = j.next();
            String value = dict.get(key);
            if (!key.equals("passwd")) {
                if (key.equals(".save") || key.equals(".js")) {
                    url.append("&" + key + "=1");
                } else if (key.equals(".challenge")) {
                    url.append("&" + key + "=" + value);
                } else {
                    String u = URLEncoder.encode(value, "UTF-8");
                    url.append("&" + key + "=" + u);
                }
            }
        }
        url.append("&");
        url.append(".hash=1");
        url.append("&");
        url.append(".md5=1");
        return url.toString();
    }
```

## f73c5234-043

**A**

```java
public ChatClient registerPlayer(int playerId, String playerLogin) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.reset();
        md.update(playerLogin.getBytes("UTF-8"), 0, playerLogin.length());
        byte[] accountToken = md.digest();
        byte[] token = generateToken(accountToken);
        ChatClient chatClient = new ChatClient(playerId, token);
        players.put(playerId, chatClient);
        return chatClient;
    }
```

**B**

```java
public static String getDigestResponse(String user, String password, String method, String requri, String authstr) {
        String realm = "";
        String nonce = "";
        String opaque = "";
        String algorithm = "";
        String qop = "";
        StringBuffer digest = new StringBuffer();
        String cnonce;
        String noncecount;
        String pAuthStr = authstr;
        int ptr = 0;
        String response = "";
        int i = 0;
        StringTokenizer st = new StringTokenizer(pAuthStr, ",");
        StringTokenizer stprob = null;
        String str = null;
        String key = null;
        String value = null;
        Properties probs = new Properties();
        while (st.hasMoreTokens()) {
            String nextToken = st.nextToken();
            stprob = new StringTokenizer(nextToken, "=");
            key = stprob.nextToken();
            value = stprob.nextToken();
            if (value.charAt(0) == '"' || value.charAt(0) == '\'') {
                value = value.substring(1, value.length() - 1);
            }
            probs.put(key, value);
        }
        digest.append("Digest username=\"" + user + "\", ");
        digest.append("realm=\"");
        digest.append(probs.getProperty("realm"));
        digest.append("\", ");
        digest.append("nonce=\"");
        digest.append(probs.getProperty("nonce"));
        digest.append("\", ");
        digest.append("uri=\"" + requri + "\", ");
        cnonce = "abcdefghi";
        noncecount = "00000001";
        String toDigest = user + ":" + realm + ":" + password;
        byte[] digestbuffer = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(toDigest.getBytes());
            digestbuffer = md.digest();
        } catch (Exception e) {
            System.err.println("Error creating digest request: " + e);
            return null;
        }
        digest.append("qop=\"auth\", ");
        digest.append("cnonce=\"" + cnonce + "\", ");
        digest.append("nc=" + noncecount + ", ");
        digest.append("response=\"" + response + "\"");
        if (probs.getProperty("opaque") != null) {
            digest.append(", opaque=\"" + probs.getProperty("opaque") + "\"");
        }
        System.out.println("SipProtocol: Digest calculated.");
        return digest.toString();
    }
```

## f73c5234-044

**A**

```java
public boolean refresh() {
        try {
            synchronized (text) {
                stream = (new URL(url)).openStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                String line;
                StringBuilder sb = new StringBuilder();
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                    sb.append("\n");
                }
                text = sb.toString();
            }
            price = 0;
            date = null;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (stream != null) try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return true;
    }
```

**B**

```java
@Override
        protected final Boolean doInBackground(Void... v) {
            Bitmap bmp = ((BitmapDrawable) ((ImageView) findViewById(R.id.post_img)).getDrawable()).getBitmap();
            HttpURLConnection con;
            try {
                URL url = new URL(POST_URL);
                con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("Accept-Language", "multipart/form-data");
                con.setRequestProperty("X-RAW", "true");
            } catch (MalformedURLException e) {
                e.printStackTrace();
                finish();
                return false;
            } catch (IOException e) {
                e.printStackTrace();
                finish();
                return false;
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            bmp.compress(CompressFormat.JPEG, 100, bos);
            OutputStream os = null;
            try {
                os = con.getOutputStream();
                os.write(bos.toByteArray());
                os.flush();
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
                try {
                    os.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                return false;
            }
            InputStream is = null;
            BufferedReader reader;
            try {
                is = con.getInputStream();
                reader = new BufferedReader(new InputStreamReader(is));
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
                try {
                    is.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                return false;
            }
            String s;
            try {
                while ((s = reader.readLine()) != null) {
                    Log.v(TAG, s);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return true;
        }
```

## f73c5234-045

**A**

```java
public String getCipherString(String source) throws CadenaNoCifradaException {
        String encryptedSource = null;
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("SHA-1");
            byte[] sha1hash = new byte[40];
            md.update(source.getBytes(encoding), 0, source.length());
            sha1hash = md.digest();
            encryptedSource = convertToHex(sha1hash);
        } catch (Exception e) {
            throw new CadenaNoCifradaException(e);
        }
        return encryptedSource;
    }
```

**B**

```java
private void createProperty(String objectID, String value, String propertyID, Long userID) throws JspTagException {
        ClassProperty classProperty = new ClassProperty(new Long(propertyID));
        String newValue = value;
        if (classProperty.getName().equals("Password")) {
            try {
                MessageDigest crypt = MessageDigest.getInstance("MD5");
                crypt.update(value.getBytes());
                byte digest[] = crypt.digest();
                StringBuffer hexString = new StringBuffer();
                for (int i = 0; i < digest.length; i++) {
                    hexString.append(hexDigit(digest[i]));
                }
                newValue = hexString.toString();
                crypt.reset();
            } catch (NoSuchAlgorithmException e) {
                System.err.println("jspShop: Could not get instance of MD5 algorithm. Please fix this!" + e.getMessage());
                e.printStackTrace();
                throw new JspTagException("Error crypting password!: " + e.getMessage());
            }
        }
        Properties properties = new Properties(new Long(objectID), userID);
        try {
            Property property = properties.create(new Long(propertyID), newValue);
            pageContext.setAttribute(getId(), property);
        } catch (CreateException e) {
            throw new JspTagException("Could not create PropertyValue, CreateException: " + e.getMessage());
        }
    }
```

## f73c5234-046

**A**

```java
public static void copyFile(String source, String dest) throws IOException {
        FileChannel in = null, out = null;
        try {
            in = new FileInputStream(new File(source)).getChannel();
            out = new FileOutputStream(new File(dest)).getChannel();
            in.transferTo(0, in.size(), out);
        } finally {
            if (in != null) in.close();
            if (out != null) out.close();
        }
    }
```

**B**

```java
private void extractSourceFiles(String jar) {
        JarInputStream in = null;
        BufferedOutputStream out = null;
        try {
            in = new JarInputStream(new FileInputStream(getProjectFile(jar)));
            JarEntry item;
            byte buffer[] = new byte[4096];
            int buflength;
            while ((item = in.getNextJarEntry()) != null) if (item.getName().startsWith(PREFIX) && (!item.getName().endsWith("/"))) {
                out = new BufferedOutputStream(new FileOutputStream(new File(dest, getFileName(item))));
                while ((buflength = in.read(buffer)) != -1) out.write(buffer, 0, buflength);
                howmany++;
                out.flush();
                out.close();
                out = null;
            }
        } catch (IOException ex) {
            System.out.println("Unable to parse file " + jar + ", reason: " + ex.getMessage());
        } finally {
            try {
                if (in != null) in.close();
            } catch (IOException ex) {
            }
            try {
                if (out != null) out.close();
            } catch (IOException ex) {
            }
        }
    }
```

## f73c5234-047

**A**

```java
public void run() {
            try {
                File outDir = new File(outDirTextField.getText());
                if (!outDir.exists()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "The chosen directory does not exist!", "Directory Not Found Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                if (!outDir.isDirectory()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "The chosen file is not a directory!", "Not a Directory Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                if (!outDir.canWrite()) {
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            JOptionPane.showMessageDialog(UnpackWizard.this, "Cannot write to the chosen directory!", "Directory Not Writeable Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
                File archiveDir = new File("foo.bar").getAbsoluteFile().getParentFile();
                URL baseUrl = UnpackWizard.class.getClassLoader().getResource(UnpackWizard.class.getName().replaceAll("\\.", "/") + ".class");
                if (baseUrl.getProtocol().equals("jar")) {
                    String jarPath = baseUrl.getPath();
                    jarPath = jarPath.substring(0, jarPath.indexOf('!'));
                    if (jarPath.startsWith("file:")) {
                        try {
                            archiveDir = new File(new URI(jarPath)).getAbsoluteFile().getParentFile();
                        } catch (URISyntaxException e1) {
                            e1.printStackTrace(System.err);
                        }
                    }
                }
                SortedMap<Integer, String> inputFileNames = new TreeMap<Integer, String>();
                for (Entry<Object, Object> anEntry : indexProperties.entrySet()) {
                    String key = anEntry.getKey().toString();
                    if (key.startsWith("archive file ")) {
                        inputFileNames.put(Integer.parseInt(key.substring("archive file ".length())), anEntry.getValue().toString());
                    }
                }
                byte[] buff = new byte[64 * 1024];
                try {
                    long bytesToWrite = 0;
                    long bytesReported = 0;
                    long bytesWritten = 0;
                    for (String aFileName : inputFileNames.values()) {
                        File aFile = new File(archiveDir, aFileName);
                        if (aFile.exists()) {
                            if (aFile.isFile()) {
                                bytesToWrite += aFile.length();
                            } else {
                                final File wrongFile = aFile;
                                SwingUtilities.invokeLater(new Runnable() {

                                    public void run() {
                                        JOptionPane.showMessageDialog(UnpackWizard.this, "File \"" + wrongFile.getAbsolutePath() + "\" is not a standard file!", "Non Standard File Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                });
                                return;
                            }
                        } else {
                            final File wrongFile = aFile;
                            SwingUtilities.invokeLater(new Runnable() {

                                public void run() {
                                    JOptionPane.showMessageDialog(UnpackWizard.this, "File \"" + wrongFile.getAbsolutePath() + "\" does not exist!", "File Not Found Error", JOptionPane.ERROR_MESSAGE);
                                }
                            });
                            return;
                        }
                    }
                    MultiFileInputStream mfis = new MultiFileInputStream(archiveDir, inputFileNames.values().toArray(new String[inputFileNames.size()]));
                    TarArchiveInputStream tis = new TarArchiveInputStream(new BufferedInputStream(mfis));
                    TarArchiveEntry tarEntry = tis.getNextTarEntry();
                    while (tarEntry != null) {
                        File outFile = new File(outDir.getAbsolutePath() + "/" + tarEntry.getName());
                        if (outFile.exists()) {
                            final File wrongFile = outFile;
                            SwingUtilities.invokeLater(new Runnable() {

                                public void run() {
                                    JOptionPane.showMessageDialog(UnpackWizard.this, "Was about to write out file \"" + wrongFile.getAbsolutePath() + "\" but it already " + "exists.\nPlease [re]move existing files out of the way " + "and try again.", "File Not Found Error", JOptionPane.ERROR_MESSAGE);
                                }
                            });
                            return;
                        }
                        if (tarEntry.isDirectory()) {
                            outFile.getAbsoluteFile().mkdirs();
                        } else {
                            outFile.getAbsoluteFile().getParentFile().mkdirs();
                            OutputStream os = new BufferedOutputStream(new FileOutputStream(outFile));
                            int len = tis.read(buff, 0, buff.length);
                            while (len != -1) {
                                os.write(buff, 0, len);
                                bytesWritten += len;
                                if (bytesWritten - bytesReported > (10 * 1024 * 1024)) {
                                    bytesReported = bytesWritten;
                                    final int progress = (int) (bytesReported * 100 / bytesToWrite);
                                    SwingUtilities.invokeLater(new Runnable() {

                                        @Override
                                        public void run() {
                                            progressBar.setValue(progress);
                                        }
                                    });
                                }
                                len = tis.read(buff, 0, buff.length);
                            }
                            os.close();
                        }
                        tarEntry = tis.getNextTarEntry();
                    }
                    long expectedCrc = 0;
                    try {
                        expectedCrc = Long.parseLong(indexProperties.getProperty("CRC32", "0"));
                    } catch (NumberFormatException e) {
                        System.err.println("Error while obtaining the expected CRC");
                        e.printStackTrace(System.err);
                    }
                    if (mfis.getCRC() == expectedCrc) {
                        SwingUtilities.invokeLater(new Runnable() {

                            @Override
                            public void run() {
                                progressBar.setValue(0);
                                JOptionPane.showMessageDialog(UnpackWizard.this, "Extraction completed successfully!", "Done!", JOptionPane.INFORMATION_MESSAGE);
                            }
                        });
                        return;
                    } else {
                        System.err.println("CRC Error: was expecting " + expectedCrc + " but got " + mfis.getCRC());
                        SwingUtilities.invokeLater(new Runnable() {

                            public void run() {
                                progressBar.setValue(0);
                                JOptionPane.showMessageDialog(UnpackWizard.this, "CRC Error: the data extracted does not have the expected CRC!\n" + "You should probably delete the extracted files, as they are " + "likely to be invalid.", "CRC Error", JOptionPane.ERROR_MESSAGE);
                            }
                        });
                        return;
                    }
                } catch (final IOException e) {
                    e.printStackTrace(System.err);
                    SwingUtilities.invokeLater(new Runnable() {

                        public void run() {
                            progressBar.setValue(0);
                            JOptionPane.showMessageDialog(UnpackWizard.this, "Input/Output Error: " + e.getLocalizedMessage(), "Input/Output Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                    return;
                }
            } finally {
                SwingUtilities.invokeLater(new Runnable() {

                    public void run() {
                        progressBar.setValue(0);
                        setEnabled(true);
                    }
                });
            }
        }
```

**B**

```java
public static boolean saveMap(LWMap map, boolean saveAs, boolean export) {
        Log.info("saveMap: " + map);
        GUI.activateWaitCursor();
        if (map == null) return false;
        File file = map.getFile();
        int response = -1;
        if (map.getSaveFileModelVersion() == 0) {
            final Object[] defaultOrderButtons = { VueResources.getString("saveaction.saveacopy"), VueResources.getString("saveaction.save") };
            Object[] messageObject = { map.getLabel() };
            response = VueUtil.option(VUE.getDialogParent(), VueResources.getFormatMessage(messageObject, "dialog.saveaction.message"), VueResources.getFormatMessage(messageObject, "dialog.saveaction.title"), JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, defaultOrderButtons, VueResources.getString("saveaction.saveacopy"));
        }
        if (response == 0) {
            saveAs = true;
        }
        if ((saveAs || file == null) && !export) {
            file = ActionUtil.selectFile("Save Map", null);
        } else if (export) {
            file = ActionUtil.selectFile("Export Map", "export");
        }
        if (file == null) {
            try {
                return false;
            } finally {
                GUI.clearWaitCursor();
            }
        }
        try {
            Log.info("saveMap: target[" + file + "]");
            final String name = file.getName().toLowerCase();
            if (name.endsWith(".rli.xml")) {
                new IMSResourceList().convert(map, file);
            } else if (name.endsWith(".xml") || name.endsWith(".vue")) {
                ActionUtil.marshallMap(file, map);
            } else if (name.endsWith(".jpeg") || name.endsWith(".jpg")) ImageConversion.createActiveMapJpeg(file, VueResources.getDouble("imageExportFactor")); else if (name.endsWith(".png")) ImageConversion.createActiveMapPng(file, VueResources.getDouble("imageExportFactor")); else if (name.endsWith(".svg")) SVGConversion.createSVG(file); else if (name.endsWith(".pdf")) {
                PresentationNotes.createMapAsPDF(file);
            } else if (name.endsWith(".zip")) {
                Vector resourceVector = new Vector();
                Iterator i = map.getAllDescendents(LWComponent.ChildKind.PROPER).iterator();
                while (i.hasNext()) {
                    LWComponent component = (LWComponent) i.next();
                    System.out.println("Component:" + component + " has resource:" + component.hasResource());
                    if (component.hasResource() && (component.getResource() instanceof URLResource)) {
                        URLResource resource = (URLResource) component.getResource();
                        try {
                            if (resource.isLocalFile()) {
                                String spec = resource.getSpec();
                                System.out.println(resource.getSpec());
                                Vector row = new Vector();
                                row.add(new Boolean(true));
                                row.add(resource);
                                row.add(new Long(file.length()));
                                row.add("Ready");
                                resourceVector.add(row);
                            }
                        } catch (Exception ex) {
                            System.out.println("Publisher.setLocalResourceVector: Resource " + resource.getSpec() + ex);
                            ex.printStackTrace();
                        }
                    }
                }
                File savedCMap = PublishUtil.createZip(map, resourceVector);
                InputStream istream = new BufferedInputStream(new FileInputStream(savedCMap));
                OutputStream ostream = new BufferedOutputStream(new FileOutputStream(file));
                int fileLength = (int) savedCMap.length();
                byte bytes[] = new byte[fileLength];
                try {
                    while (istream.read(bytes, 0, fileLength) != -1) ostream.write(bytes, 0, fileLength);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    istream.close();
                    ostream.close();
                }
            } else if (name.endsWith(".html")) {
                HtmlOutputDialog hod = new HtmlOutputDialog();
                hod.setVisible(true);
                if (hod.getReturnVal() > 0) new ImageMap().createImageMap(file, hod.getScale(), hod.getFormat());
            } else if (name.endsWith(".rdf")) {
                edu.tufts.vue.rdf.RDFIndex index = new edu.tufts.vue.rdf.RDFIndex();
                String selectionType = VueResources.getString("rdf.export.selection");
                if (selectionType.equals("ALL")) {
                    Iterator<LWMap> maps = VUE.getLeftTabbedPane().getAllMaps();
                    while (maps.hasNext()) {
                        index.index(maps.next());
                    }
                } else if (selectionType.equals("ACTIVE")) {
                    index.index(VUE.getActiveMap());
                } else {
                    index.index(VUE.getActiveMap());
                }
                FileWriter writer = new FileWriter(file);
                index.write(writer);
                writer.close();
            } else if (name.endsWith(VueUtil.VueArchiveExtension)) {
                Archive.writeArchive(map, file);
            } else {
                Log.warn("Unknown save type for filename extension: " + name);
                return false;
            }
            Log.debug("Save completed for " + file);
            if (!VUE.isApplet()) {
                VueFrame frame = (VueFrame) VUE.getMainWindow();
                String title = VUE.getName() + ": " + name;
                frame.setTitle(title);
            }
            if (name.endsWith(".vue")) {
                RecentlyOpenedFilesManager rofm = RecentlyOpenedFilesManager.getInstance();
                rofm.updateRecentlyOpenedFiles(file.getAbsolutePath());
            }
            return true;
        } catch (Throwable t) {
            Log.error("Exception attempting to save file " + file + ": " + t);
            Throwable e = t;
            if (t.getCause() != null) e = t.getCause();
            if (e instanceof java.io.FileNotFoundException) {
                Log.error("Save Failed: " + e);
            } else {
                Log.error("Save failed for \"" + file + "\"; ", e);
            }
            if (e != t) Log.error("Exception attempting to save file " + file + ": " + e);
            VueUtil.alert(String.format(Locale.getDefault(), VueResources.getString("saveaction.savemap.error") + "\"%s\";\n" + VueResources.getString("saveaction.targetfiel") + "\n\n" + VueResources.getString("saveaction.problem"), map.getLabel(), file, Util.formatLines(e.toString(), 80)), "Problem Saving Map");
        } finally {
            GUI.invokeAfterAWT(new Runnable() {

                public void run() {
                    GUI.clearWaitCursor();
                }
            });
        }
        return false;
    }
```

## f73c5234-048

**A**

```java
public static Checksum checksum(File file, Checksum checksum) throws IOException {
        if (file.isDirectory()) {
            throw new IllegalArgumentException("Checksums can't be computed on directories");
        }
        InputStream in = null;
        try {
            in = new CheckedInputStream(new FileInputStream(file), checksum);
            IOUtils.copy(in, new OutputStream() {

                @Override
                public void write(byte[] b, int off, int len) {
                }

                @Override
                public void write(int b) {
                }

                @Override
                public void write(byte[] b) throws IOException {
                }
            });
        } finally {
            IOUtils.closeQuietly(in);
        }
        return checksum;
    }
```

**B**

```java
public static void readAsFile(String fileName, String url) {
        BufferedInputStream in = null;
        BufferedOutputStream out = null;
        URLConnection conn = null;
        try {
            conn = new URL(url).openConnection();
            conn.setDoInput(true);
            in = new BufferedInputStream(conn.getInputStream());
            out = new BufferedOutputStream(new FileOutputStream(fileName));
            int b;
            while ((b = in.read()) != -1) {
                out.write(b);
            }
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
        } finally {
            if (null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                }
            }
            if (null != out) {
                try {
                    out.flush();
                    out.close();
                } catch (IOException e) {
                }
            }
        }
    }
```

## f73c5234-049

**A**

```java
public static File copyFile(String path) {
        File src = new File(path);
        File dest = new File(src.getName());
        try {
            if (!dest.exists()) {
                dest.createNewFile();
            }
            FileChannel source = new FileInputStream(src).getChannel();
            FileChannel destination = new FileOutputStream(dest).getChannel();
            destination.transferFrom(source, 0, source.size());
            source.close();
            destination.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }
```

**B**

```java
public void copyFile(String source_name, String dest_name) throws IOException {
        File source_file = new File(source_name);
        File destination_file = new File(dest_name);
        Reader source = null;
        Writer destination = null;
        char[] buffer;
        int bytes_read;
        try {
            if (!source_file.exists() || !source_file.isFile()) throw new FileCopyException("FileCopy: no such source file: " + source_name);
            if (!source_file.canRead()) throw new FileCopyException("FileCopy: source file " + "is unreadable: " + source_name);
            if (destination_file.exists()) {
                if (destination_file.isFile()) {
                    DataInputStream in = new DataInputStream(System.in);
                    String response;
                    if (!destination_file.canWrite()) throw new FileCopyException("FileCopy: destination " + "file is unwriteable: " + dest_name);
                } else {
                    throw new FileCopyException("FileCopy: destination " + "is not a file: " + dest_name);
                }
            } else {
                File parentdir = parent(destination_file);
                if (!parentdir.exists()) throw new FileCopyException("FileCopy: destination " + "directory doesn't exist: " + dest_name);
                if (!parentdir.canWrite()) throw new FileCopyException("FileCopy: destination " + "directory is unwriteable: " + dest_name);
            }
            source = new BufferedReader(new FileReader(source_file));
            destination = new BufferedWriter(new FileWriter(destination_file));
            buffer = new char[1024];
            while (true) {
                bytes_read = source.read(buffer, 0, 1024);
                if (bytes_read == -1) break;
                destination.write(buffer, 0, bytes_read);
            }
        } finally {
            if (source != null) {
                try {
                    source.close();
                } catch (IOException e) {
                    ;
                }
            }
            if (destination != null) {
                try {
                    destination.close();
                } catch (IOException e) {
                    ;
                }
            }
        }
    }
```

## f73c5234-050

**A**

```java
public static void copyFile(File in, File out) {
        try {
            FileChannel sourceChannel = new FileInputStream(in).getChannel();
            FileChannel destinationChannel = new FileOutputStream(out).getChannel();
            sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
            sourceChannel.close();
            destinationChannel.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
```

**B**

```java
public String copyImages(Document doc, String sXML, String newPath, String tagName, String itemName) {
        NodeList nl = null;
        Node n = null;
        NamedNodeMap nnp = null;
        Node nsrc = null;
        URL url = null;
        String sFilename = "";
        String sNewPath = "";
        int index;
        String sOldPath = "";
        try {
            nl = doc.getElementsByTagName(tagName);
            for (int i = 0; i < nl.getLength(); i++) {
                n = nl.item(i);
                nnp = n.getAttributes();
                nsrc = nnp.getNamedItem(itemName);
                String sTemp = nsrc.getTextContent();
                url = new URL("file", "localhost", sTemp);
                sOldPath = url.getPath();
                sOldPath = sOldPath.replace('/', File.separatorChar);
                int indexFirstSlash = sOldPath.indexOf(File.separatorChar);
                String sSourcePath;
                if (itemName.equals("data")) sSourcePath = sOldPath; else sSourcePath = sOldPath.substring(indexFirstSlash + 1);
                index = sOldPath.lastIndexOf(File.separatorChar);
                sFilename = sOldPath.substring(index + 1);
                sNewPath = newPath + sFilename;
                FileChannel in = null;
                FileChannel out = null;
                try {
                    in = new FileInputStream(sSourcePath).getChannel();
                    out = new FileOutputStream(sNewPath).getChannel();
                    long size = in.size();
                    MappedByteBuffer buf = in.map(FileChannel.MapMode.READ_ONLY, 0, size);
                    out.write(buf);
                } finally {
                    if (in != null) in.close();
                    if (out != null) out.close();
                }
                sXML = sXML.replace(nsrc.getTextContent(), sFilename);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sXML;
    }
```
